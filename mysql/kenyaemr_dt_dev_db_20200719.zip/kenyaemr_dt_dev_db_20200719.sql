/*
SQLyog Community v11.2 (64 bit)
MySQL - 5.6.45-log : Database - kenyaemr_datatools
*********************************************************************
*/

/*!40101 SET NAMES utf8 */;

/*!40101 SET SQL_MODE=''*/;

/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
/*Table structure for table `client_trace` */

DROP TABLE IF EXISTS `client_trace`;

CREATE TABLE `client_trace` (
  `id` int(11) DEFAULT NULL,
  `uuid` char(38) DEFAULT NULL,
  `date_created` date DEFAULT NULL,
  `encounter_date` datetime DEFAULT NULL,
  `client_id` int(11) DEFAULT NULL,
  `contact_type` varchar(255) DEFAULT NULL,
  `status` varchar(255) DEFAULT NULL,
  `unique_patient_no` varchar(255) DEFAULT NULL,
  `facility_linked_to` varchar(255) DEFAULT NULL,
  `health_worker_handed_to` varchar(255) DEFAULT NULL,
  `remarks` varchar(255) DEFAULT NULL,
  `appointment_date` datetime DEFAULT NULL,
  `voided` int(11) DEFAULT NULL,
  KEY `client_id` (`client_id`),
  KEY `date_created` (`date_created`),
  CONSTRAINT `client_trace_ibfk_1` FOREIGN KEY (`client_id`) REFERENCES `patient_contact` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Table structure for table `etl_covid_19_case_enrolment` */

DROP TABLE IF EXISTS `etl_covid_19_case_enrolment`;

CREATE TABLE `etl_covid_19_case_enrolment` (
  `uuid` char(38) DEFAULT NULL,
  `encounter_id` int(11) NOT NULL,
  `visit_id` int(11) DEFAULT NULL,
  `patient_id` int(11) NOT NULL,
  `location_id` int(11) DEFAULT NULL,
  `visit_date` date DEFAULT NULL,
  `encounter_date` date DEFAULT NULL,
  `encounter_provider` int(11) DEFAULT NULL,
  `date_created` date DEFAULT NULL,
  `sub_county` varchar(255) DEFAULT NULL,
  `county` varchar(255) DEFAULT NULL,
  `detection_point` varchar(255) DEFAULT NULL,
  `date_detected` date DEFAULT NULL,
  `onset_symptoms_date` date DEFAULT NULL,
  `symptomatic` varchar(10) DEFAULT NULL,
  `fever` varchar(50) DEFAULT NULL,
  `cough` varchar(10) DEFAULT NULL,
  `runny_nose` varchar(10) DEFAULT NULL,
  `diarrhoea` varchar(10) DEFAULT NULL,
  `headache` varchar(10) DEFAULT NULL,
  `muscular_pain` varchar(10) DEFAULT NULL,
  `abdominal_pain` varchar(10) DEFAULT NULL,
  `general_weakness` varchar(10) DEFAULT NULL,
  `sore_throat` varchar(10) DEFAULT NULL,
  `shortness_breath` varchar(10) DEFAULT NULL,
  `vomiting` varchar(10) DEFAULT NULL,
  `confusion` varchar(10) DEFAULT NULL,
  `chest_pain` varchar(10) DEFAULT NULL,
  `joint_pain` varchar(10) DEFAULT NULL,
  `other_symptom` varchar(10) DEFAULT NULL,
  `specify_symptoms` varchar(255) DEFAULT NULL,
  `temperature` varchar(10) DEFAULT NULL,
  `pharyngeal_exudate` varchar(10) DEFAULT NULL,
  `tachypnea` varchar(10) DEFAULT NULL,
  `abnormal_xray` varchar(10) DEFAULT NULL,
  `coma` varchar(10) DEFAULT NULL,
  `conjuctival_injection` varchar(10) DEFAULT NULL,
  `abnormal_lung_auscultation` varchar(10) DEFAULT NULL,
  `seizures` varchar(10) DEFAULT NULL,
  `pregnancy_status` varchar(10) DEFAULT NULL,
  `trimester` varchar(10) DEFAULT NULL,
  `underlying_condition` varchar(10) DEFAULT NULL,
  `cardiovascular_dse_hypertension` varchar(10) DEFAULT NULL,
  `diabetes` varchar(10) DEFAULT NULL,
  `liver_disease` varchar(10) DEFAULT NULL,
  `chronic_neurological_neuromascular_dse` varchar(10) DEFAULT NULL,
  `post_partum` varchar(10) DEFAULT NULL,
  `immunodeficiency` varchar(10) DEFAULT NULL,
  `renal_disease` varchar(10) DEFAULT NULL,
  `chronic_lung_disease` varchar(10) DEFAULT NULL,
  `malignancy` varchar(10) DEFAULT NULL,
  `occupation` varchar(10) DEFAULT NULL,
  `other_signs` varchar(10) DEFAULT NULL,
  `specify_signs` varchar(255) DEFAULT NULL,
  `admitted_to_hospital` varchar(10) DEFAULT NULL,
  `date_of_first_admission` date DEFAULT NULL,
  `hospital_name` varchar(255) DEFAULT NULL,
  `date_of_isolation` date DEFAULT NULL,
  `patient_ventilated` varchar(10) DEFAULT NULL,
  `health_status_at_reporting` varchar(255) DEFAULT NULL,
  `date_of_death` date DEFAULT NULL,
  `recently_travelled` varchar(10) DEFAULT NULL,
  `country_recently_travelled` varchar(100) DEFAULT NULL,
  `city_recently_travelled` varchar(100) DEFAULT NULL,
  `recently_visited_health_facility` varchar(10) DEFAULT NULL,
  `recent_contact_with_infected_person` varchar(10) DEFAULT NULL,
  `recent_contact_with_confirmed_person` varchar(10) DEFAULT NULL,
  `recent_contact_setting` varchar(200) DEFAULT NULL,
  `recent_visit_to_animal_market` varchar(10) DEFAULT NULL,
  `animal_market_name` varchar(200) DEFAULT NULL,
  `voided` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Table structure for table `laboratory_extract` */

DROP TABLE IF EXISTS `laboratory_extract`;

CREATE TABLE `laboratory_extract` (
  `uuid` char(38) NOT NULL,
  `encounter_id` int(11) DEFAULT NULL,
  `patient_id` int(11) NOT NULL,
  `location_id` int(11) DEFAULT NULL,
  `visit_date` date DEFAULT NULL,
  `visit_id` int(11) DEFAULT NULL,
  `lab_test` varchar(25) CHARACTER SET utf8 DEFAULT NULL,
  `urgency` varchar(50) DEFAULT NULL,
  `test_result` varchar(180) DEFAULT NULL,
  `date_created` date DEFAULT NULL,
  `created_by` int(11) DEFAULT NULL,
  KEY `patient_id` (`patient_id`),
  KEY `visit_date` (`visit_date`),
  KEY `lab_test` (`lab_test`),
  KEY `test_result` (`test_result`),
  CONSTRAINT `laboratory_extract_ibfk_1` FOREIGN KEY (`patient_id`) REFERENCES `patient_demographics` (`patient_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Table structure for table `patient_contact` */

DROP TABLE IF EXISTS `patient_contact`;

CREATE TABLE `patient_contact` (
  `id` int(11) NOT NULL DEFAULT '0',
  `uuid` char(38) DEFAULT NULL,
  `date_created` date DEFAULT NULL,
  `first_name` varchar(255) DEFAULT NULL,
  `middle_name` varchar(255) DEFAULT NULL,
  `last_name` varchar(255) DEFAULT NULL,
  `sex` varchar(50) DEFAULT NULL,
  `birth_date` datetime DEFAULT NULL,
  `physical_address` varchar(255) DEFAULT NULL,
  `phone_contact` varchar(255) DEFAULT NULL,
  `patient_related_to` int(11) DEFAULT NULL,
  `patient_id` int(11) DEFAULT NULL,
  `relationship_type` varchar(20) CHARACTER SET utf8 DEFAULT NULL,
  `appointment_date` datetime DEFAULT NULL,
  `baseline_hiv_status` varchar(255) DEFAULT NULL,
  `ipv_outcome` varchar(255) DEFAULT NULL,
  `marital_status` varchar(18) CHARACTER SET utf8 DEFAULT NULL,
  `living_with_patient` varchar(18) CHARACTER SET utf8 DEFAULT NULL,
  `pns_approach` varchar(17) CHARACTER SET utf8 DEFAULT NULL,
  `contact_listing_decline_reason` varchar(255) DEFAULT NULL,
  `consented_contact_listing` varchar(7) CHARACTER SET utf8 DEFAULT NULL,
  `voided` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `patient_related_to` (`patient_related_to`),
  KEY `date_created` (`date_created`),
  CONSTRAINT `patient_contact_ibfk_1` FOREIGN KEY (`patient_related_to`) REFERENCES `patient_demographics` (`patient_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Table structure for table `patient_demographics` */

DROP TABLE IF EXISTS `patient_demographics`;

CREATE TABLE `patient_demographics` (
  `patient_id` int(11) NOT NULL,
  `given_name` varchar(255) DEFAULT NULL,
  `middle_name` varchar(255) DEFAULT NULL,
  `family_name` varchar(255) DEFAULT NULL,
  `Gender` varchar(10) DEFAULT NULL,
  `DOB` date DEFAULT NULL,
  `national_id_no` varchar(50) DEFAULT NULL,
  `unique_patient_no` varchar(50) DEFAULT NULL,
  `patient_clinic_number` varchar(15) DEFAULT NULL,
  `Tb_no` varchar(50) DEFAULT NULL,
  `district_reg_no` varchar(50) DEFAULT NULL,
  `hei_no` varchar(50) DEFAULT NULL,
  `phone_number` varchar(50) DEFAULT NULL,
  `birth_place` varchar(50) DEFAULT NULL,
  `citizenship` varchar(50) DEFAULT NULL,
  `email_address` varchar(100) DEFAULT NULL,
  `next_of_kin` varchar(255) DEFAULT NULL,
  `next_of_kin_relationship` varchar(100) DEFAULT NULL,
  `marital_status` varchar(50) DEFAULT NULL,
  `education_level` varchar(50) DEFAULT NULL,
  `dead` varchar(3) CHARACTER SET utf8 NOT NULL DEFAULT '',
  `death_date` date DEFAULT NULL,
  `voided` int(11) DEFAULT NULL,
  PRIMARY KEY (`patient_id`),
  KEY `Gender` (`Gender`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Table structure for table `patient_program_discontinuation` */

DROP TABLE IF EXISTS `patient_program_discontinuation`;

CREATE TABLE `patient_program_discontinuation` (
  `patient_id` int(11) NOT NULL,
  `uuid` char(38) DEFAULT NULL,
  `visit_id` int(11) DEFAULT NULL,
  `visit_date` datetime DEFAULT NULL,
  `program_uuid` char(38) DEFAULT NULL,
  `program_name` varchar(50) DEFAULT NULL,
  `encounter_id` int(11) NOT NULL,
  `discontinuation_reason` varchar(23) CHARACTER SET utf8 DEFAULT NULL,
  `date_died` date DEFAULT NULL,
  `transfer_facility` varchar(100) DEFAULT NULL,
  `transfer_date` date DEFAULT NULL,
  KEY `patient_id` (`patient_id`),
  KEY `visit_date` (`visit_date`),
  KEY `discontinuation_reason` (`discontinuation_reason`),
  CONSTRAINT `patient_program_discontinuation_ibfk_1` FOREIGN KEY (`patient_id`) REFERENCES `patient_demographics` (`patient_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Table structure for table `person_address` */

DROP TABLE IF EXISTS `person_address`;

CREATE TABLE `person_address` (
  `uuid` char(38) NOT NULL,
  `patient_id` int(11) NOT NULL,
  `county` varchar(100) DEFAULT NULL,
  `sub_county` varchar(100) DEFAULT NULL,
  `location` varchar(100) DEFAULT NULL,
  `ward` varchar(100) DEFAULT NULL,
  `sub_location` varchar(100) DEFAULT NULL,
  `village` varchar(100) DEFAULT NULL,
  `postal_address` varchar(100) DEFAULT NULL,
  `land_mark` varchar(100) DEFAULT NULL,
  `voided` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Table structure for table `triage` */

DROP TABLE IF EXISTS `triage`;

CREATE TABLE `triage` (
  `uuid` char(38) DEFAULT NULL,
  `patient_id` int(11) NOT NULL,
  `visit_id` int(11) DEFAULT NULL,
  `visit_date` date DEFAULT NULL,
  `location_id` int(11) DEFAULT NULL,
  `encounter_id` int(11) NOT NULL,
  `encounter_provider` int(11) DEFAULT NULL,
  `date_created` date DEFAULT NULL,
  `visit_reason` varchar(255) DEFAULT NULL,
  `weight` double DEFAULT NULL,
  `height` double DEFAULT NULL,
  `systolic_pressure` double DEFAULT NULL,
  `diastolic_pressure` double DEFAULT NULL,
  `temperature` double DEFAULT NULL,
  `pulse_rate` double DEFAULT NULL,
  `respiratory_rate` double DEFAULT NULL,
  `oxygen_saturation` double DEFAULT NULL,
  `muac` double DEFAULT NULL,
  `nutritional_status` varchar(27) CHARACTER SET utf8 DEFAULT NULL,
  `last_menstrual_period` date DEFAULT NULL,
  `voided` int(11) DEFAULT NULL,
  KEY `patient_id` (`patient_id`),
  KEY `visit_date` (`visit_date`),
  CONSTRAINT `triage_ibfk_1` FOREIGN KEY (`patient_id`) REFERENCES `patient_demographics` (`patient_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;
