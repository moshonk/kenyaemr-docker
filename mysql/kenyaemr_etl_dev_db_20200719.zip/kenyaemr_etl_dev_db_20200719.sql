/*
SQLyog Community v11.2 (64 bit)
MySQL - 5.6.45-log : Database - kenyaemr_etl
*********************************************************************
*/

/*!40101 SET NAMES utf8 */;

/*!40101 SET SQL_MODE=''*/;

/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
/*Table structure for table `etl_current_in_care` */

DROP TABLE IF EXISTS `etl_current_in_care`;

CREATE TABLE `etl_current_in_care` (
  `visit_date` date DEFAULT NULL,
  `patient_id` int(11) NOT NULL,
  `dob` date DEFAULT NULL,
  `Gender` varchar(10) DEFAULT NULL,
  `enroll_date` date DEFAULT NULL,
  `latest_vis_date` date DEFAULT NULL,
  `latest_tca` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `unique_patient_no` varchar(50) DEFAULT NULL,
  `date_discontinued` datetime DEFAULT NULL,
  `disc_patient` int(11),
  `started_on_drugs` int(11),
  KEY `enroll_date` (`enroll_date`),
  KEY `latest_vis_date` (`latest_vis_date`),
  KEY `latest_tca` (`latest_tca`),
  KEY `started_on_drugs` (`started_on_drugs`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Table structure for table `etl_drug_event` */

DROP TABLE IF EXISTS `etl_drug_event`;

CREATE TABLE `etl_drug_event` (
  `uuid` char(38) NOT NULL,
  `patient_id` int(11) NOT NULL,
  `date_started` date DEFAULT NULL,
  `regimen` varchar(100) DEFAULT NULL,
  `regimen_name` varchar(100) DEFAULT NULL,
  `regimen_line` varchar(50) DEFAULT NULL,
  `discontinued` int(11) DEFAULT NULL,
  `regimen_discontinued` varchar(255) DEFAULT NULL,
  `date_discontinued` date DEFAULT NULL,
  `reason_discontinued` int(11) DEFAULT NULL,
  `reason_discontinued_other` varchar(100) DEFAULT NULL,
  `voided` int(11) DEFAULT NULL,
  PRIMARY KEY (`uuid`),
  KEY `patient_id` (`patient_id`),
  KEY `date_started` (`date_started`),
  KEY `date_discontinued` (`date_discontinued`),
  KEY `patient_id_2` (`patient_id`,`date_started`),
  CONSTRAINT `etl_drug_event_ibfk_1` FOREIGN KEY (`patient_id`) REFERENCES `etl_patient_demographics` (`patient_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Table structure for table `etl_hei_enrollment` */

DROP TABLE IF EXISTS `etl_hei_enrollment`;

CREATE TABLE `etl_hei_enrollment` (
  `uuid` char(38) DEFAULT NULL,
  `patient_id` int(11) NOT NULL,
  `visit_id` int(11) DEFAULT NULL,
  `visit_date` date DEFAULT NULL,
  `location_id` int(11) DEFAULT NULL,
  `provider` int(11) DEFAULT NULL,
  `encounter_id` int(11) NOT NULL,
  `child_exposed` int(11) DEFAULT NULL,
  `hei_id_number` varchar(50) DEFAULT NULL,
  `spd_number` varchar(50) DEFAULT NULL,
  `birth_weight` double DEFAULT NULL,
  `gestation_at_birth` double DEFAULT NULL,
  `date_first_seen` date DEFAULT NULL,
  `birth_notification_number` varchar(50) DEFAULT NULL,
  `birth_certificate_number` varchar(50) DEFAULT NULL,
  `need_for_special_care` int(11) DEFAULT NULL,
  `reason_for_special_care` int(11) DEFAULT NULL,
  `referral_source` int(11) DEFAULT NULL,
  `transfer_in` int(11) DEFAULT NULL,
  `transfer_in_date` date DEFAULT NULL,
  `facility_transferred_from` varchar(50) DEFAULT NULL,
  `district_transferred_from` varchar(50) DEFAULT NULL,
  `date_first_enrolled_in_hei_care` date DEFAULT NULL,
  `arv_prophylaxis` int(11) DEFAULT NULL,
  `mother_breastfeeding` int(11) DEFAULT NULL,
  `mother_on_NVP_during_breastfeeding` int(11) DEFAULT NULL,
  `TB_contact_history_in_household` int(11) DEFAULT NULL,
  `infant_mother_link` int(11) DEFAULT NULL,
  `mother_alive` int(11) DEFAULT NULL,
  `mother_on_pmtct_drugs` int(11) DEFAULT NULL,
  `mother_on_drug` int(11) DEFAULT NULL,
  `mother_on_art_at_infant_enrollment` int(11) DEFAULT NULL,
  `mother_drug_regimen` int(11) DEFAULT NULL,
  `parent_ccc_number` varchar(50) DEFAULT NULL,
  `mode_of_delivery` int(11) DEFAULT NULL,
  `place_of_delivery` int(11) DEFAULT NULL,
  `exit_date` date DEFAULT NULL,
  `exit_reason` int(11) DEFAULT NULL,
  `hiv_status_at_exit` int(11) DEFAULT NULL,
  PRIMARY KEY (`encounter_id`),
  UNIQUE KEY `unique_uuid` (`uuid`),
  KEY `visit_date` (`visit_date`),
  KEY `encounter_id` (`encounter_id`),
  KEY `patient_id` (`patient_id`),
  KEY `transfer_in` (`transfer_in`),
  KEY `child_exposed` (`child_exposed`),
  KEY `need_for_special_care` (`need_for_special_care`),
  KEY `reason_for_special_care` (`reason_for_special_care`),
  KEY `referral_source` (`referral_source`),
  KEY `transfer_in_2` (`transfer_in`),
  CONSTRAINT `etl_hei_enrollment_ibfk_1` FOREIGN KEY (`patient_id`) REFERENCES `etl_patient_demographics` (`patient_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Table structure for table `etl_hei_follow_up_visit` */

DROP TABLE IF EXISTS `etl_hei_follow_up_visit`;

CREATE TABLE `etl_hei_follow_up_visit` (
  `uuid` char(38) DEFAULT NULL,
  `provider` int(11) DEFAULT NULL,
  `patient_id` int(11) NOT NULL,
  `visit_id` int(11) DEFAULT NULL,
  `visit_date` date DEFAULT NULL,
  `location_id` int(11) DEFAULT NULL,
  `encounter_id` int(11) NOT NULL,
  `weight` double DEFAULT NULL,
  `height` double DEFAULT NULL,
  `infant_feeding` int(11) DEFAULT NULL,
  `tb_assessment_outcome` int(11) DEFAULT NULL,
  `social_smile_milestone` int(11) DEFAULT NULL,
  `head_control_milestone` int(11) DEFAULT NULL,
  `response_to_sound_milestone` int(11) DEFAULT NULL,
  `hand_extension_milestone` int(11) DEFAULT NULL,
  `sitting_milestone` int(11) DEFAULT NULL,
  `walking_milestone` int(11) DEFAULT NULL,
  `standing_milestone` int(11) DEFAULT NULL,
  `talking_milestone` int(11) DEFAULT NULL,
  `review_of_systems_developmental` int(11) DEFAULT NULL,
  `dna_pcr_sample_date` date DEFAULT NULL,
  `dna_pcr_contextual_status` int(11) DEFAULT NULL,
  `dna_pcr_result` int(11) DEFAULT NULL,
  `dna_pcr_dbs_sample_code` varchar(100) DEFAULT NULL,
  `dna_pcr_results_date` date DEFAULT NULL,
  `first_antibody_sample_date` date DEFAULT NULL,
  `first_antibody_result` int(11) DEFAULT NULL,
  `first_antibody_dbs_sample_code` varchar(100) DEFAULT NULL,
  `first_antibody_result_date` date DEFAULT NULL,
  `final_antibody_sample_date` date DEFAULT NULL,
  `final_antibody_result` int(11) DEFAULT NULL,
  `final_antibody_dbs_sample_code` varchar(100) DEFAULT NULL,
  `final_antibody_result_date` date DEFAULT NULL,
  `tetracycline_ointment_given` int(11) DEFAULT NULL,
  `pupil_examination` int(11) DEFAULT NULL,
  `sight_examination` int(11) DEFAULT NULL,
  `squint` int(11) DEFAULT NULL,
  `deworming_drug` int(11) DEFAULT NULL,
  `dosage` int(11) DEFAULT NULL,
  `unit` varchar(100) DEFAULT NULL,
  `next_appointment_date` date DEFAULT NULL,
  PRIMARY KEY (`encounter_id`),
  UNIQUE KEY `unique_uuid` (`uuid`),
  KEY `visit_date` (`visit_date`),
  KEY `encounter_id` (`encounter_id`),
  KEY `patient_id` (`patient_id`),
  KEY `infant_feeding` (`infant_feeding`),
  CONSTRAINT `etl_hei_follow_up_visit_ibfk_1` FOREIGN KEY (`patient_id`) REFERENCES `etl_patient_demographics` (`patient_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Table structure for table `etl_hiv_enrollment` */

DROP TABLE IF EXISTS `etl_hiv_enrollment`;

CREATE TABLE `etl_hiv_enrollment` (
  `uuid` char(38) DEFAULT NULL,
  `patient_id` int(11) NOT NULL,
  `visit_id` int(11) DEFAULT NULL,
  `visit_date` date DEFAULT NULL,
  `location_id` int(11) DEFAULT NULL,
  `encounter_id` int(11) NOT NULL,
  `encounter_provider` int(11) DEFAULT NULL,
  `patient_type` int(11) DEFAULT NULL,
  `date_first_enrolled_in_care` date DEFAULT NULL,
  `entry_point` int(11) DEFAULT NULL,
  `transfer_in_date` date DEFAULT NULL,
  `facility_transferred_from` varchar(50) DEFAULT NULL,
  `district_transferred_from` varchar(50) DEFAULT NULL,
  `date_started_art_at_transferring_facility` date DEFAULT NULL,
  `date_confirmed_hiv_positive` date DEFAULT NULL,
  `facility_confirmed_hiv_positive` varchar(200) DEFAULT NULL,
  `arv_status` int(11) DEFAULT NULL,
  `name_of_treatment_supporter` varchar(50) DEFAULT NULL,
  `relationship_of_treatment_supporter` int(11) DEFAULT NULL,
  `treatment_supporter_telephone` varchar(50) DEFAULT NULL,
  `treatment_supporter_address` varchar(100) DEFAULT NULL,
  `date_of_discontinuation` datetime DEFAULT NULL,
  `discontinuation_reason` int(11) DEFAULT NULL,
  `date_created` date DEFAULT NULL,
  `voided` int(11) DEFAULT NULL,
  PRIMARY KEY (`encounter_id`),
  UNIQUE KEY `unique_uuid` (`uuid`),
  KEY `patient_id` (`patient_id`),
  KEY `visit_id` (`visit_id`),
  KEY `visit_date` (`visit_date`),
  KEY `date_started_art_at_transferring_facility` (`date_started_art_at_transferring_facility`),
  KEY `arv_status` (`arv_status`),
  KEY `date_confirmed_hiv_positive` (`date_confirmed_hiv_positive`),
  KEY `entry_point` (`entry_point`),
  KEY `transfer_in_date` (`transfer_in_date`),
  KEY `date_first_enrolled_in_care` (`date_first_enrolled_in_care`),
  KEY `entry_point_2` (`entry_point`,`transfer_in_date`,`visit_date`,`patient_id`),
  CONSTRAINT `etl_hiv_enrollment_ibfk_1` FOREIGN KEY (`patient_id`) REFERENCES `etl_patient_demographics` (`patient_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Table structure for table `etl_hts_referral_and_linkage` */

DROP TABLE IF EXISTS `etl_hts_referral_and_linkage`;

CREATE TABLE `etl_hts_referral_and_linkage` (
  `patient_id` int(11) NOT NULL,
  `visit_id` int(11) DEFAULT NULL,
  `encounter_id` int(11) NOT NULL,
  `encounter_uuid` char(32) NOT NULL,
  `encounter_location` int(11) NOT NULL,
  `creator` int(11) NOT NULL,
  `date_created` date NOT NULL,
  `visit_date` date DEFAULT NULL,
  `tracing_type` varchar(50) DEFAULT NULL,
  `tracing_status` varchar(10) DEFAULT NULL,
  `ccc_number` int(11) DEFAULT NULL,
  `facility_linked_to` varchar(50) DEFAULT NULL,
  `provider_handed_to` varchar(50) DEFAULT NULL,
  `voided` int(11) DEFAULT NULL,
  PRIMARY KEY (`encounter_id`),
  KEY `patient_id` (`patient_id`),
  KEY `visit_date` (`visit_date`),
  KEY `tracing_type` (`tracing_type`),
  KEY `tracing_status` (`tracing_status`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Table structure for table `etl_hts_test` */

DROP TABLE IF EXISTS `etl_hts_test`;

CREATE TABLE `etl_hts_test` (
  `patient_id` int(11) NOT NULL,
  `visit_id` int(11) DEFAULT NULL,
  `encounter_id` int(11) NOT NULL,
  `encounter_uuid` char(32) NOT NULL,
  `encounter_location` int(11) NOT NULL,
  `creator` int(11) NOT NULL,
  `date_created` date NOT NULL,
  `visit_date` date DEFAULT NULL,
  `test_type` int(11) DEFAULT NULL,
  `population_type` varchar(50) DEFAULT NULL,
  `key_population_type` varchar(50) DEFAULT NULL,
  `ever_tested_for_hiv` varchar(10) DEFAULT NULL,
  `months_since_last_test` int(11) DEFAULT NULL,
  `patient_disabled` varchar(50) DEFAULT NULL,
  `disability_type` varchar(50) DEFAULT NULL,
  `patient_consented` varchar(50) DEFAULT NULL,
  `client_tested_as` varchar(50) DEFAULT NULL,
  `test_strategy` varchar(50) DEFAULT NULL,
  `test_1_kit_name` varchar(50) DEFAULT NULL,
  `test_1_kit_lot_no` varchar(50) DEFAULT NULL,
  `test_1_kit_expiry` date DEFAULT NULL,
  `test_1_result` varchar(50) DEFAULT NULL,
  `test_2_kit_name` varchar(50) DEFAULT NULL,
  `test_2_kit_lot_no` varchar(50) DEFAULT NULL,
  `test_2_kit_expiry` date DEFAULT NULL,
  `test_2_result` varchar(50) DEFAULT NULL,
  `final_test_result` varchar(50) DEFAULT NULL,
  `patient_given_result` varchar(50) DEFAULT NULL,
  `couple_discordant` varchar(100) DEFAULT NULL,
  `tb_screening` varchar(20) DEFAULT NULL,
  `patient_had_hiv_self_test` varchar(50) DEFAULT NULL,
  `remarks` varchar(50) DEFAULT NULL,
  `voided` int(11) DEFAULT NULL,
  PRIMARY KEY (`encounter_id`),
  KEY `patient_id` (`patient_id`),
  KEY `visit_id` (`visit_id`),
  KEY `tb_screening` (`tb_screening`),
  KEY `visit_date` (`visit_date`),
  KEY `population_type` (`population_type`),
  KEY `test_type` (`test_type`),
  KEY `final_test_result` (`final_test_result`),
  KEY `couple_discordant` (`couple_discordant`),
  KEY `test_1_kit_name` (`test_1_kit_name`),
  KEY `test_2_kit_name` (`test_2_kit_name`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Table structure for table `etl_ipt_follow_up` */

DROP TABLE IF EXISTS `etl_ipt_follow_up`;

CREATE TABLE `etl_ipt_follow_up` (
  `uuid` char(38) DEFAULT NULL,
  `provider` int(11) DEFAULT NULL,
  `patient_id` int(11) NOT NULL,
  `visit_id` int(11) DEFAULT NULL,
  `visit_date` date DEFAULT NULL,
  `location_id` int(11) DEFAULT NULL,
  `encounter_id` int(11) NOT NULL,
  `ipt_due_date` date DEFAULT NULL,
  `date_collected_ipt` date DEFAULT NULL,
  `hepatotoxity` int(11) DEFAULT NULL,
  `peripheral_neuropathy` int(11) DEFAULT NULL,
  `rash` int(11) DEFAULT NULL,
  `adherence` int(11) DEFAULT NULL,
  `outcome` int(11) DEFAULT NULL,
  `date_of_outcome` date DEFAULT NULL,
  `discontinuation_reason` int(11) DEFAULT NULL,
  `action_taken` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`encounter_id`),
  UNIQUE KEY `unique_uuid` (`uuid`),
  KEY `visit_date` (`visit_date`),
  KEY `visit_date_2` (`visit_date`,`discontinuation_reason`),
  KEY `encounter_id` (`encounter_id`),
  KEY `patient_id` (`patient_id`),
  KEY `ipt_due_date` (`ipt_due_date`),
  KEY `date_collected_ipt` (`date_collected_ipt`),
  KEY `hepatotoxity` (`hepatotoxity`),
  KEY `peripheral_neuropathy` (`peripheral_neuropathy`),
  KEY `rash` (`rash`),
  KEY `adherence` (`adherence`),
  KEY `outcome` (`outcome`),
  KEY `discontinuation_reason` (`discontinuation_reason`),
  CONSTRAINT `etl_ipt_follow_up_ibfk_1` FOREIGN KEY (`patient_id`) REFERENCES `etl_patient_demographics` (`patient_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Table structure for table `etl_ipt_screening` */

DROP TABLE IF EXISTS `etl_ipt_screening`;

CREATE TABLE `etl_ipt_screening` (
  `uuid` char(38) DEFAULT NULL,
  `provider` int(11) DEFAULT NULL,
  `patient_id` int(11) NOT NULL,
  `visit_id` int(11) DEFAULT NULL,
  `visit_date` date DEFAULT NULL,
  `location_id` int(11) DEFAULT NULL,
  `encounter_id` int(11) NOT NULL,
  `yellow_urine` int(11) DEFAULT NULL,
  `numbness` int(11) DEFAULT NULL,
  `yellow_eyes` int(11) DEFAULT NULL,
  `abdominal_tenderness` int(11) DEFAULT NULL,
  `ipt_started` int(11) DEFAULT NULL,
  PRIMARY KEY (`encounter_id`),
  UNIQUE KEY `unique_uuid` (`uuid`),
  KEY `visit_date` (`visit_date`),
  KEY `patient_id` (`patient_id`),
  KEY `visit_date_2` (`visit_date`,`ipt_started`,`patient_id`),
  KEY `ipt_started` (`ipt_started`,`visit_date`),
  KEY `encounter_id` (`encounter_id`),
  KEY `ipt_started_2` (`ipt_started`),
  CONSTRAINT `etl_ipt_screening_ibfk_1` FOREIGN KEY (`patient_id`) REFERENCES `etl_patient_demographics` (`patient_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Table structure for table `etl_laboratory_extract` */

DROP TABLE IF EXISTS `etl_laboratory_extract`;

CREATE TABLE `etl_laboratory_extract` (
  `uuid` char(38) NOT NULL,
  `encounter_id` int(11) DEFAULT NULL,
  `patient_id` int(11) NOT NULL,
  `location_id` int(11) DEFAULT NULL,
  `visit_date` date DEFAULT NULL,
  `visit_id` int(11) DEFAULT NULL,
  `lab_test` varchar(200) DEFAULT NULL,
  `test_result` varchar(200) DEFAULT NULL,
  `date_test_requested` date DEFAULT NULL,
  `date_test_result_received` date DEFAULT NULL,
  `test_requested_by` int(11) DEFAULT NULL,
  `date_created` date DEFAULT NULL,
  `created_by` int(11) DEFAULT NULL,
  PRIMARY KEY (`uuid`),
  KEY `visit_date` (`visit_date`),
  KEY `encounter_id` (`encounter_id`),
  KEY `patient_id` (`patient_id`),
  KEY `lab_test` (`lab_test`),
  KEY `test_result` (`test_result`),
  CONSTRAINT `etl_laboratory_extract_ibfk_1` FOREIGN KEY (`patient_id`) REFERENCES `etl_patient_demographics` (`patient_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Table structure for table `etl_last_month_newly_enrolled_in_care` */

DROP TABLE IF EXISTS `etl_last_month_newly_enrolled_in_care`;

CREATE TABLE `etl_last_month_newly_enrolled_in_care` (
  `patient_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Table structure for table `etl_last_month_newly_on_art` */

DROP TABLE IF EXISTS `etl_last_month_newly_on_art`;

CREATE TABLE `etl_last_month_newly_on_art` (
  `patient_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Table structure for table `etl_mch_antenatal_visit` */

DROP TABLE IF EXISTS `etl_mch_antenatal_visit`;

CREATE TABLE `etl_mch_antenatal_visit` (
  `uuid` char(38) DEFAULT NULL,
  `patient_id` int(11) NOT NULL,
  `visit_id` int(11) DEFAULT NULL,
  `visit_date` date DEFAULT NULL,
  `location_id` int(11) DEFAULT NULL,
  `encounter_id` int(11) NOT NULL,
  `provider` int(11) DEFAULT NULL,
  `temperature` double DEFAULT NULL,
  `pulse_rate` double DEFAULT NULL,
  `systolic_bp` double DEFAULT NULL,
  `diastolic_bp` double DEFAULT NULL,
  `respiratory_rate` double DEFAULT NULL,
  `oxygen_saturation` int(11) DEFAULT NULL,
  `weight` double DEFAULT NULL,
  `height` double DEFAULT NULL,
  `muac` double DEFAULT NULL,
  `hemoglobin` double DEFAULT NULL,
  `pallor` int(11) DEFAULT NULL,
  `maturity` int(11) DEFAULT NULL,
  `fundal_height` double DEFAULT NULL,
  `fetal_presentation` int(11) DEFAULT NULL,
  `lie` int(11) DEFAULT NULL,
  `fetal_heart_rate` int(11) DEFAULT NULL,
  `fetal_movement` int(11) DEFAULT NULL,
  `who_stage` int(11) DEFAULT NULL,
  `cd4` int(11) DEFAULT NULL,
  `arv_status` int(11) DEFAULT NULL,
  `urine_microscopy` varchar(100) DEFAULT NULL,
  `urinary_albumin` int(11) DEFAULT NULL,
  `glucose_measurement` int(11) DEFAULT NULL,
  `urine_ph` int(11) DEFAULT NULL,
  `urine_gravity` int(11) DEFAULT NULL,
  `urine_nitrite_test` int(11) DEFAULT NULL,
  `urine_leukocyte_esterace_test` int(11) DEFAULT NULL,
  `urinary_ketone` int(11) DEFAULT NULL,
  `urine_bile_salt_test` int(11) DEFAULT NULL,
  `urine_bile_pigment_test` int(11) DEFAULT NULL,
  `urine_colour` int(11) DEFAULT NULL,
  `urine_turbidity` int(11) DEFAULT NULL,
  `urine_dipstick_for_blood` int(11) DEFAULT NULL,
  PRIMARY KEY (`encounter_id`),
  UNIQUE KEY `unique_uuid` (`uuid`),
  KEY `visit_date` (`visit_date`),
  KEY `encounter_id` (`encounter_id`),
  KEY `patient_id` (`patient_id`),
  KEY `who_stage` (`who_stage`),
  KEY `cd4` (`cd4`),
  KEY `arv_status` (`arv_status`),
  CONSTRAINT `etl_mch_antenatal_visit_ibfk_1` FOREIGN KEY (`patient_id`) REFERENCES `etl_patient_demographics` (`patient_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Table structure for table `etl_mch_enrollment` */

DROP TABLE IF EXISTS `etl_mch_enrollment`;

CREATE TABLE `etl_mch_enrollment` (
  `uuid` char(38) DEFAULT NULL,
  `patient_id` int(11) NOT NULL,
  `visit_id` int(11) DEFAULT NULL,
  `visit_date` date DEFAULT NULL,
  `location_id` int(11) DEFAULT NULL,
  `encounter_id` int(11) NOT NULL,
  `anc_number` varchar(50) DEFAULT NULL,
  `gravida` int(11) DEFAULT NULL,
  `parity` int(11) DEFAULT NULL,
  `parity_abortion` int(11) DEFAULT NULL,
  `lmp` date DEFAULT NULL,
  `lmp_estimated` int(11) DEFAULT NULL,
  `edd_ultrasound` date DEFAULT NULL,
  `blood_group` int(11) DEFAULT NULL,
  `serology` int(11) DEFAULT NULL,
  `tb_screening` int(11) DEFAULT NULL,
  `bs_for_mps` int(11) DEFAULT NULL,
  `hiv_status` int(11) DEFAULT NULL,
  `hiv_test_date` date DEFAULT NULL,
  `partner_hiv_status` int(11) DEFAULT NULL,
  `partner_hiv_test_date` date DEFAULT NULL,
  `urine_microscopy` varchar(100) DEFAULT NULL,
  `urinary_albumin` int(11) DEFAULT NULL,
  `glucose_measurement` int(11) DEFAULT NULL,
  `urine_ph` int(11) DEFAULT NULL,
  `urine_gravity` int(11) DEFAULT NULL,
  `urine_nitrite_test` int(11) DEFAULT NULL,
  `urine_leukocyte_esterace_test` int(11) DEFAULT NULL,
  `urinary_ketone` int(11) DEFAULT NULL,
  `urine_bile_salt_test` int(11) DEFAULT NULL,
  `urine_bile_pigment_test` int(11) DEFAULT NULL,
  `urine_colour` int(11) DEFAULT NULL,
  `urine_turbidity` int(11) DEFAULT NULL,
  `urine_dipstick_for_blood` int(11) DEFAULT NULL,
  `date_of_discontinuation` datetime DEFAULT NULL,
  `discontinuation_reason` int(11) DEFAULT NULL,
  PRIMARY KEY (`encounter_id`),
  UNIQUE KEY `unique_uuid` (`uuid`),
  KEY `visit_date` (`visit_date`),
  KEY `encounter_id` (`encounter_id`),
  KEY `patient_id` (`patient_id`),
  KEY `tb_screening` (`tb_screening`),
  KEY `hiv_status` (`hiv_status`),
  KEY `hiv_test_date` (`hiv_test_date`),
  KEY `partner_hiv_status` (`partner_hiv_status`),
  CONSTRAINT `etl_mch_enrollment_ibfk_1` FOREIGN KEY (`patient_id`) REFERENCES `etl_patient_demographics` (`patient_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Table structure for table `etl_mch_postnatal_visit` */

DROP TABLE IF EXISTS `etl_mch_postnatal_visit`;

CREATE TABLE `etl_mch_postnatal_visit` (
  `uuid` char(38) DEFAULT NULL,
  `patient_id` int(11) NOT NULL,
  `visit_id` int(11) DEFAULT NULL,
  `visit_date` date DEFAULT NULL,
  `location_id` int(11) DEFAULT NULL,
  `encounter_id` int(11) NOT NULL,
  `provider` int(11) DEFAULT NULL,
  `temperature` double DEFAULT NULL,
  `pulse_rate` double DEFAULT NULL,
  `systolic_bp` double DEFAULT NULL,
  `diastolic_bp` double DEFAULT NULL,
  `respiratory_rate` double DEFAULT NULL,
  `oxygen_saturation` int(11) DEFAULT NULL,
  `weight` double DEFAULT NULL,
  `height` double DEFAULT NULL,
  `muac` double DEFAULT NULL,
  `hemoglobin` double DEFAULT NULL,
  `arv_status` int(11) DEFAULT NULL,
  `general_condition` int(11) DEFAULT NULL,
  `breast` int(11) DEFAULT NULL,
  `cs_scar` int(11) DEFAULT NULL,
  `gravid_uterus` int(11) DEFAULT NULL,
  `episiotomy` int(11) DEFAULT NULL,
  `lochia` int(11) DEFAULT NULL,
  `mother_hiv_status` int(11) DEFAULT NULL,
  `condition_of_baby` int(11) DEFAULT NULL,
  `baby_feeding_method` int(11) DEFAULT NULL,
  `umblical_cord` int(11) DEFAULT NULL,
  `baby_immunization_started` int(11) DEFAULT NULL,
  `family_planning_counseling` int(11) DEFAULT NULL,
  `uterus_examination` varchar(100) DEFAULT NULL,
  `uterus_cervix_examination` varchar(100) DEFAULT NULL,
  `vaginal_examination` varchar(100) DEFAULT NULL,
  `parametrial_examination` varchar(100) DEFAULT NULL,
  `external_genitalia_examination` varchar(100) DEFAULT NULL,
  `ovarian_examination` varchar(100) DEFAULT NULL,
  `pelvic_lymph_node_exam` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`encounter_id`),
  UNIQUE KEY `unique_uuid` (`uuid`),
  KEY `visit_date` (`visit_date`),
  KEY `encounter_id` (`encounter_id`),
  KEY `patient_id` (`patient_id`),
  KEY `arv_status` (`arv_status`),
  KEY `mother_hiv_status` (`mother_hiv_status`),
  KEY `arv_status_2` (`arv_status`),
  CONSTRAINT `etl_mch_postnatal_visit_ibfk_1` FOREIGN KEY (`patient_id`) REFERENCES `etl_patient_demographics` (`patient_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Table structure for table `etl_mchs_delivery` */

DROP TABLE IF EXISTS `etl_mchs_delivery`;

CREATE TABLE `etl_mchs_delivery` (
  `uuid` char(38) DEFAULT NULL,
  `provider` int(11) DEFAULT NULL,
  `patient_id` int(11) NOT NULL,
  `visit_id` int(11) DEFAULT NULL,
  `visit_date` date DEFAULT NULL,
  `location_id` int(11) DEFAULT NULL,
  `encounter_id` int(11) NOT NULL,
  `data_entry_date` date DEFAULT NULL,
  `duration_of_pregnancy` double DEFAULT NULL,
  `mode_of_delivery` int(11) DEFAULT NULL,
  `date_of_delivery` date DEFAULT NULL,
  `blood_loss` int(11) DEFAULT NULL,
  `condition_of_mother` varchar(100) DEFAULT NULL,
  `apgar_score_1min` double DEFAULT NULL,
  `apgar_score_5min` double DEFAULT NULL,
  `apgar_score_10min` double DEFAULT NULL,
  `resuscitation_done` int(11) DEFAULT NULL,
  `place_of_delivery` int(11) DEFAULT NULL,
  `delivery_assistant` int(11) DEFAULT NULL,
  `counseling_on_infant_feeding` int(11) DEFAULT NULL,
  `counseling_on_exclusive_breastfeeding` int(11) DEFAULT NULL,
  `counseling_on_infant_feeding_for_hiv_infected` int(11) DEFAULT NULL,
  `mother_decision` int(11) DEFAULT NULL,
  PRIMARY KEY (`encounter_id`),
  UNIQUE KEY `unique_uuid` (`uuid`),
  KEY `visit_date` (`visit_date`),
  KEY `encounter_id` (`encounter_id`),
  KEY `patient_id` (`patient_id`),
  CONSTRAINT `etl_mchs_delivery_ibfk_1` FOREIGN KEY (`patient_id`) REFERENCES `etl_patient_demographics` (`patient_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Table structure for table `etl_missed_appointments` */

DROP TABLE IF EXISTS `etl_missed_appointments`;

CREATE TABLE `etl_missed_appointments` (
  `id` int(11) NOT NULL,
  `patient_id` int(11) NOT NULL,
  `last_tca_date` date DEFAULT NULL,
  `last_visit_date` date DEFAULT NULL,
  `last_encounter_type` varchar(100) DEFAULT NULL,
  `days_since_last_visit` int(11) DEFAULT NULL,
  `date_table_created` date DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `patient_id` (`patient_id`),
  CONSTRAINT `etl_missed_appointments_ibfk_1` FOREIGN KEY (`patient_id`) REFERENCES `etl_patient_demographics` (`patient_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Table structure for table `etl_patient_demographics` */

DROP TABLE IF EXISTS `etl_patient_demographics`;

CREATE TABLE `etl_patient_demographics` (
  `patient_id` int(11) NOT NULL,
  `given_name` varchar(50) DEFAULT NULL,
  `middle_name` varchar(50) DEFAULT NULL,
  `family_name` varchar(50) DEFAULT NULL,
  `Gender` varchar(10) DEFAULT NULL,
  `DOB` date DEFAULT NULL,
  `national_id_no` varchar(50) DEFAULT NULL,
  `unique_patient_no` varchar(50) DEFAULT NULL,
  `patient_clinic_number` varchar(15) DEFAULT NULL,
  `Tb_no` varchar(50) DEFAULT NULL,
  `district_reg_no` varchar(50) DEFAULT NULL,
  `hei_no` varchar(50) DEFAULT NULL,
  `phone_number` varchar(50) DEFAULT NULL,
  `birth_place` varchar(50) DEFAULT NULL,
  `citizenship` varchar(50) DEFAULT NULL,
  `email_address` varchar(50) DEFAULT NULL,
  `next_of_kin` varchar(100) DEFAULT NULL,
  `next_of_kin_phone` varchar(20) DEFAULT NULL,
  `next_of_kin_relationship` varchar(50) DEFAULT NULL,
  `marital_status` varchar(50) DEFAULT NULL,
  `education_level` varchar(50) DEFAULT NULL,
  `dead` int(11) DEFAULT NULL,
  `death_date` date DEFAULT NULL,
  `voided` int(11) DEFAULT NULL,
  PRIMARY KEY (`patient_id`),
  KEY `patient_id` (`patient_id`),
  KEY `Gender` (`Gender`),
  KEY `unique_patient_no` (`unique_patient_no`),
  KEY `DOB` (`DOB`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Table structure for table `etl_patient_hiv_followup` */

DROP TABLE IF EXISTS `etl_patient_hiv_followup`;

CREATE TABLE `etl_patient_hiv_followup` (
  `uuid` char(38) DEFAULT NULL,
  `encounter_id` int(11) NOT NULL,
  `patient_id` int(11) NOT NULL,
  `location_id` int(11) DEFAULT NULL,
  `visit_date` date DEFAULT NULL,
  `visit_id` int(11) DEFAULT NULL,
  `encounter_provider` int(11) DEFAULT NULL,
  `date_created` date DEFAULT NULL,
  `visit_scheduled` int(11) DEFAULT NULL,
  `person_present` int(11) DEFAULT NULL,
  `weight` double DEFAULT NULL,
  `systolic_pressure` double DEFAULT NULL,
  `diastolic_pressure` double DEFAULT NULL,
  `height` double DEFAULT NULL,
  `temperature` double DEFAULT NULL,
  `pulse_rate` double DEFAULT NULL,
  `respiratory_rate` double DEFAULT NULL,
  `oxygen_saturation` double DEFAULT NULL,
  `muac` double DEFAULT NULL,
  `nutritional_status` int(11) DEFAULT NULL,
  `population_type` int(11) DEFAULT NULL,
  `key_population_type` int(11) DEFAULT NULL,
  `who_stage` int(11) DEFAULT NULL,
  `presenting_complaints` int(11) DEFAULT NULL,
  `clinical_notes` varchar(200) DEFAULT NULL,
  `on_anti_tb_drugs` int(11) DEFAULT NULL,
  `on_ipt` int(11) DEFAULT NULL,
  `ever_on_ipt` int(11) DEFAULT NULL,
  `spatum_smear_ordered` int(11) DEFAULT NULL,
  `chest_xray_ordered` int(11) DEFAULT NULL,
  `genexpert_ordered` int(11) DEFAULT NULL,
  `spatum_smear_result` int(11) DEFAULT NULL,
  `chest_xray_result` int(11) DEFAULT NULL,
  `genexpert_result` int(11) DEFAULT NULL,
  `referral` int(11) DEFAULT NULL,
  `clinical_tb_diagnosis` int(11) DEFAULT NULL,
  `contact_invitation` int(11) DEFAULT NULL,
  `evaluated_for_ipt` int(11) DEFAULT NULL,
  `has_known_allergies` int(11) DEFAULT NULL,
  `has_chronic_illnesses_cormobidities` int(11) DEFAULT NULL,
  `has_adverse_drug_reaction` int(11) DEFAULT NULL,
  `substitution_first_line_regimen_date` date DEFAULT NULL,
  `substitution_first_line_regimen_reason` int(11) DEFAULT NULL,
  `substitution_second_line_regimen_date` date DEFAULT NULL,
  `substitution_second_line_regimen_reason` int(11) DEFAULT NULL,
  `second_line_regimen_change_date` date DEFAULT NULL,
  `second_line_regimen_change_reason` int(11) DEFAULT NULL,
  `pregnancy_status` int(11) DEFAULT NULL,
  `wants_pregnancy` int(11) DEFAULT NULL,
  `pregnancy_outcome` int(11) DEFAULT NULL,
  `anc_number` varchar(50) DEFAULT NULL,
  `expected_delivery_date` date DEFAULT NULL,
  `last_menstrual_period` date DEFAULT NULL,
  `gravida` int(11) DEFAULT NULL,
  `parity` int(11) DEFAULT NULL,
  `full_term_pregnancies` int(11) DEFAULT NULL,
  `abortion_miscarriages` int(11) DEFAULT NULL,
  `family_planning_status` int(11) DEFAULT NULL,
  `family_planning_method` int(11) DEFAULT NULL,
  `reason_not_using_family_planning` int(11) DEFAULT NULL,
  `tb_status` int(11) DEFAULT NULL,
  `tb_treatment_no` varchar(50) DEFAULT NULL,
  `ctx_adherence` int(11) DEFAULT NULL,
  `ctx_dispensed` int(11) DEFAULT NULL,
  `dapsone_adherence` int(11) DEFAULT NULL,
  `dapsone_dispensed` int(11) DEFAULT NULL,
  `inh_dispensed` int(11) DEFAULT NULL,
  `arv_adherence` int(11) DEFAULT NULL,
  `poor_arv_adherence_reason` int(11) DEFAULT NULL,
  `poor_arv_adherence_reason_other` varchar(200) DEFAULT NULL,
  `pwp_disclosure` int(11) DEFAULT NULL,
  `pwp_partner_tested` int(11) DEFAULT NULL,
  `condom_provided` int(11) DEFAULT NULL,
  `screened_for_sti` int(11) DEFAULT NULL,
  `cacx_screening` int(11) DEFAULT NULL,
  `sti_partner_notification` int(11) DEFAULT NULL,
  `at_risk_population` int(11) DEFAULT NULL,
  `system_review_finding` int(11) DEFAULT NULL,
  `next_appointment_date` date DEFAULT NULL,
  `next_appointment_reason` int(11) DEFAULT NULL,
  `differentiated_care` int(11) DEFAULT NULL,
  `stability` int(11) DEFAULT NULL,
  `voided` int(11) DEFAULT NULL,
  PRIMARY KEY (`encounter_id`),
  UNIQUE KEY `unique_uuid` (`uuid`),
  KEY `visit_date` (`visit_date`),
  KEY `encounter_id` (`encounter_id`),
  KEY `patient_id` (`patient_id`),
  KEY `patient_id_2` (`patient_id`,`visit_date`),
  KEY `who_stage` (`who_stage`),
  KEY `pregnancy_status` (`pregnancy_status`),
  KEY `pregnancy_outcome` (`pregnancy_outcome`),
  KEY `family_planning_status` (`family_planning_status`),
  KEY `family_planning_method` (`family_planning_method`),
  KEY `tb_status` (`tb_status`),
  KEY `condom_provided` (`condom_provided`),
  KEY `ctx_dispensed` (`ctx_dispensed`),
  KEY `inh_dispensed` (`inh_dispensed`),
  KEY `at_risk_population` (`at_risk_population`),
  KEY `population_type` (`population_type`),
  KEY `key_population_type` (`key_population_type`),
  KEY `on_anti_tb_drugs` (`on_anti_tb_drugs`),
  KEY `on_ipt` (`on_ipt`),
  KEY `ever_on_ipt` (`ever_on_ipt`),
  KEY `differentiated_care` (`differentiated_care`),
  KEY `visit_date_2` (`visit_date`,`patient_id`),
  KEY `visit_date_3` (`visit_date`,`condom_provided`),
  KEY `visit_date_4` (`visit_date`,`family_planning_method`),
  CONSTRAINT `etl_patient_hiv_followup_ibfk_1` FOREIGN KEY (`patient_id`) REFERENCES `etl_patient_demographics` (`patient_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Table structure for table `etl_patient_program_discontinuation` */

DROP TABLE IF EXISTS `etl_patient_program_discontinuation`;

CREATE TABLE `etl_patient_program_discontinuation` (
  `uuid` char(38) DEFAULT NULL,
  `patient_id` int(11) NOT NULL,
  `visit_id` int(11) DEFAULT NULL,
  `visit_date` datetime DEFAULT NULL,
  `location_id` int(11) DEFAULT NULL,
  `program_uuid` char(38) DEFAULT NULL,
  `program_name` varchar(50) DEFAULT NULL,
  `encounter_id` int(11) NOT NULL,
  `discontinuation_reason` int(11) DEFAULT NULL,
  `date_died` date DEFAULT NULL,
  `transfer_facility` varchar(50) DEFAULT NULL,
  `transfer_date` date DEFAULT NULL,
  PRIMARY KEY (`encounter_id`),
  UNIQUE KEY `unique_uuid` (`uuid`),
  KEY `visit_date` (`visit_date`),
  KEY `visit_date_2` (`visit_date`,`program_name`,`patient_id`),
  KEY `visit_date_3` (`visit_date`,`patient_id`),
  KEY `encounter_id` (`encounter_id`),
  KEY `patient_id` (`patient_id`),
  KEY `discontinuation_reason` (`discontinuation_reason`),
  KEY `date_died` (`date_died`),
  KEY `transfer_date` (`transfer_date`),
  CONSTRAINT `etl_patient_program_discontinuation_ibfk_1` FOREIGN KEY (`patient_id`) REFERENCES `etl_patient_demographics` (`patient_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Table structure for table `etl_patients_booked_today` */

DROP TABLE IF EXISTS `etl_patients_booked_today`;

CREATE TABLE `etl_patients_booked_today` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `patient_id` int(11) NOT NULL,
  `last_visit_date` date DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `patient_id` (`patient_id`),
  CONSTRAINT `etl_patients_booked_today_ibfk_1` FOREIGN KEY (`patient_id`) REFERENCES `etl_patient_demographics` (`patient_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Table structure for table `etl_pharmacy_extract` */

DROP TABLE IF EXISTS `etl_pharmacy_extract`;

CREATE TABLE `etl_pharmacy_extract` (
  `obs_group_id` int(11) NOT NULL,
  `uuid` char(38) DEFAULT NULL,
  `patient_id` int(11) NOT NULL,
  `location_id` int(11) DEFAULT NULL,
  `visit_date` date DEFAULT NULL,
  `visit_id` int(11) DEFAULT NULL,
  `encounter_id` int(11) DEFAULT NULL,
  `encounter_name` varchar(100) DEFAULT NULL,
  `drug` int(11) DEFAULT NULL,
  `is_arv` int(11) DEFAULT NULL,
  `is_ctx` int(11) DEFAULT NULL,
  `is_dapsone` int(11) DEFAULT NULL,
  `drug_name` varchar(100) DEFAULT NULL,
  `dose` int(11) DEFAULT NULL,
  `unit` int(11) DEFAULT NULL,
  `frequency` int(11) DEFAULT NULL,
  `duration` int(11) DEFAULT NULL,
  `duration_units` varchar(20) DEFAULT NULL,
  `duration_in_days` int(11) DEFAULT NULL,
  `prescription_provider` varchar(50) DEFAULT NULL,
  `dispensing_provider` varchar(50) DEFAULT NULL,
  `regimen` varchar(50) DEFAULT NULL,
  `adverse_effects` varchar(100) DEFAULT NULL,
  `date_of_refill` date DEFAULT NULL,
  `date_created` date DEFAULT NULL,
  `voided` int(11) DEFAULT NULL,
  `date_voided` date DEFAULT NULL,
  PRIMARY KEY (`obs_group_id`),
  UNIQUE KEY `unique_uuid` (`uuid`),
  KEY `visit_date` (`visit_date`),
  KEY `encounter_id` (`encounter_id`),
  KEY `patient_id` (`patient_id`),
  KEY `drug` (`drug`),
  KEY `is_arv` (`is_arv`),
  CONSTRAINT `etl_pharmacy_extract_ibfk_1` FOREIGN KEY (`patient_id`) REFERENCES `etl_patient_demographics` (`patient_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Table structure for table `etl_script_status` */

DROP TABLE IF EXISTS `etl_script_status`;

CREATE TABLE `etl_script_status` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `script_name` varchar(50) DEFAULT NULL,
  `start_time` datetime DEFAULT NULL,
  `stop_time` datetime DEFAULT NULL,
  `error` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `stop_time` (`stop_time`),
  KEY `start_time` (`start_time`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

/*Table structure for table `etl_tb_enrollment` */

DROP TABLE IF EXISTS `etl_tb_enrollment`;

CREATE TABLE `etl_tb_enrollment` (
  `uuid` char(38) DEFAULT NULL,
  `patient_id` int(11) NOT NULL,
  `visit_id` int(11) DEFAULT NULL,
  `visit_date` date DEFAULT NULL,
  `location_id` int(11) DEFAULT NULL,
  `encounter_id` int(11) NOT NULL,
  `provider` int(11) DEFAULT NULL,
  `date_treatment_started` date DEFAULT NULL,
  `district` varchar(50) DEFAULT NULL,
  `district_registration_number` varchar(20) DEFAULT NULL,
  `referred_by` int(11) DEFAULT NULL,
  `referral_date` date DEFAULT NULL,
  `date_transferred_in` date DEFAULT NULL,
  `facility_transferred_from` varchar(50) DEFAULT NULL,
  `district_transferred_from` varchar(50) DEFAULT NULL,
  `date_first_enrolled_in_tb_care` date DEFAULT NULL,
  `weight` double DEFAULT NULL,
  `height` double DEFAULT NULL,
  `treatment_supporter` varchar(100) DEFAULT NULL,
  `relation_to_patient` int(11) DEFAULT NULL,
  `treatment_supporter_address` varchar(100) DEFAULT NULL,
  `treatment_supporter_phone_contact` varchar(100) DEFAULT NULL,
  `disease_classification` int(11) DEFAULT NULL,
  `patient_classification` int(11) DEFAULT NULL,
  `pulmonary_smear_result` int(11) DEFAULT NULL,
  `has_extra_pulmonary_pleurial_effusion` int(11) DEFAULT NULL,
  `has_extra_pulmonary_milliary` int(11) DEFAULT NULL,
  `has_extra_pulmonary_lymph_node` int(11) DEFAULT NULL,
  `has_extra_pulmonary_menengitis` int(11) DEFAULT NULL,
  `has_extra_pulmonary_skeleton` int(11) DEFAULT NULL,
  `has_extra_pulmonary_abdominal` int(11) DEFAULT NULL,
  `has_extra_pulmonary_other` varchar(100) DEFAULT NULL,
  `treatment_outcome` int(11) DEFAULT NULL,
  `treatment_outcome_date` date DEFAULT NULL,
  `date_of_discontinuation` datetime DEFAULT NULL,
  `discontinuation_reason` int(11) DEFAULT NULL,
  PRIMARY KEY (`encounter_id`),
  UNIQUE KEY `unique_uuid` (`uuid`),
  KEY `visit_date` (`visit_date`),
  KEY `encounter_id` (`encounter_id`),
  KEY `patient_id` (`patient_id`),
  KEY `disease_classification` (`disease_classification`),
  KEY `patient_classification` (`patient_classification`),
  KEY `pulmonary_smear_result` (`pulmonary_smear_result`),
  KEY `date_first_enrolled_in_tb_care` (`date_first_enrolled_in_tb_care`),
  CONSTRAINT `etl_tb_enrollment_ibfk_1` FOREIGN KEY (`patient_id`) REFERENCES `etl_patient_demographics` (`patient_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Table structure for table `etl_tb_follow_up_visit` */

DROP TABLE IF EXISTS `etl_tb_follow_up_visit`;

CREATE TABLE `etl_tb_follow_up_visit` (
  `uuid` char(38) DEFAULT NULL,
  `provider` int(11) DEFAULT NULL,
  `patient_id` int(11) NOT NULL,
  `visit_id` int(11) DEFAULT NULL,
  `visit_date` date DEFAULT NULL,
  `location_id` int(11) DEFAULT NULL,
  `encounter_id` int(11) NOT NULL,
  `spatum_test` int(11) DEFAULT NULL,
  `spatum_result` int(11) DEFAULT NULL,
  `result_serial_number` varchar(20) DEFAULT NULL,
  `quantity` double DEFAULT NULL,
  `date_test_done` date DEFAULT NULL,
  `bacterial_colonie_growth` int(11) DEFAULT NULL,
  `number_of_colonies` double DEFAULT NULL,
  `resistant_s` int(11) DEFAULT NULL,
  `resistant_r` int(11) DEFAULT NULL,
  `resistant_inh` int(11) DEFAULT NULL,
  `resistant_e` int(11) DEFAULT NULL,
  `sensitive_s` int(11) DEFAULT NULL,
  `sensitive_r` int(11) DEFAULT NULL,
  `sensitive_inh` int(11) DEFAULT NULL,
  `sensitive_e` int(11) DEFAULT NULL,
  `test_date` date DEFAULT NULL,
  `hiv_status` int(11) DEFAULT NULL,
  `next_appointment_date` date DEFAULT NULL,
  PRIMARY KEY (`encounter_id`),
  UNIQUE KEY `unique_uuid` (`uuid`),
  KEY `visit_date` (`visit_date`),
  KEY `encounter_id` (`encounter_id`),
  KEY `patient_id` (`patient_id`),
  KEY `hiv_status` (`hiv_status`),
  CONSTRAINT `etl_tb_follow_up_visit_ibfk_1` FOREIGN KEY (`patient_id`) REFERENCES `etl_patient_demographics` (`patient_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Table structure for table `etl_tb_screening` */

DROP TABLE IF EXISTS `etl_tb_screening`;

CREATE TABLE `etl_tb_screening` (
  `uuid` char(38) DEFAULT NULL,
  `provider` int(11) DEFAULT NULL,
  `patient_id` int(11) NOT NULL,
  `visit_id` int(11) DEFAULT NULL,
  `visit_date` date DEFAULT NULL,
  `location_id` int(11) DEFAULT NULL,
  `encounter_id` int(11) NOT NULL,
  `cough_for_2wks_or_more` int(11) DEFAULT NULL,
  `confirmed_tb_contact` int(11) DEFAULT NULL,
  `fever_for_2wks_or_more` int(11) DEFAULT NULL,
  `noticeable_weight_loss` int(11) DEFAULT NULL,
  `night_sweat_for_2wks_or_more` int(11) DEFAULT NULL,
  `resulting_tb_status` int(11) DEFAULT NULL,
  `tb_treatment_start_date` date DEFAULT NULL,
  `notes` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`encounter_id`),
  UNIQUE KEY `unique_uuid` (`uuid`),
  KEY `visit_date` (`visit_date`),
  KEY `encounter_id` (`encounter_id`),
  KEY `patient_id` (`patient_id`),
  KEY `cough_for_2wks_or_more` (`cough_for_2wks_or_more`),
  KEY `confirmed_tb_contact` (`confirmed_tb_contact`),
  KEY `noticeable_weight_loss` (`noticeable_weight_loss`),
  KEY `night_sweat_for_2wks_or_more` (`night_sweat_for_2wks_or_more`),
  KEY `resulting_tb_status` (`resulting_tb_status`),
  CONSTRAINT `etl_tb_screening_ibfk_1` FOREIGN KEY (`patient_id`) REFERENCES `etl_patient_demographics` (`patient_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;
