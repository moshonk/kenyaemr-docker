/*
SQLyog Community v11.2 (64 bit)
MySQL - 5.6.45-log : Database - kenyaemr_etl
*********************************************************************
*/

/*!40101 SET NAMES utf8 */;

/*!40101 SET SQL_MODE=''*/;

/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
/*Table structure for table `etl_art_preparation` */

DROP TABLE IF EXISTS `etl_art_preparation`;

CREATE TABLE `etl_art_preparation` (
  `uuid` char(38) DEFAULT NULL,
  `patient_id` int(11) NOT NULL,
  `visit_id` int(11) DEFAULT NULL,
  `visit_date` date DEFAULT NULL,
  `location_id` int(11) DEFAULT NULL,
  `encounter_id` int(11) NOT NULL,
  `provider` int(11) DEFAULT NULL,
  `understands_hiv_art_benefits` varchar(10) DEFAULT NULL,
  `screened_negative_substance_abuse` varchar(10) DEFAULT NULL,
  `screened_negative_psychiatric_illness` varchar(10) DEFAULT NULL,
  `HIV_status_disclosure` varchar(10) DEFAULT NULL,
  `trained_drug_admin` varchar(10) DEFAULT NULL,
  `informed_drug_side_effects` varchar(10) DEFAULT NULL,
  `caregiver_committed` varchar(10) DEFAULT NULL,
  `adherance_barriers_identified` varchar(10) DEFAULT NULL,
  `caregiver_location_contacts_known` varchar(10) DEFAULT NULL,
  `ready_to_start_art` varchar(10) DEFAULT NULL,
  `identified_drug_time` varchar(10) DEFAULT NULL,
  `treatment_supporter_engaged` varchar(10) DEFAULT NULL,
  `support_grp_meeting_awareness` varchar(10) DEFAULT NULL,
  `enrolled_in_reminder_system` varchar(10) DEFAULT NULL,
  `other_support_systems` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`encounter_id`),
  UNIQUE KEY `unique_uuid` (`uuid`),
  KEY `patient_id` (`patient_id`),
  KEY `visit_date` (`visit_date`),
  KEY `encounter_id` (`encounter_id`),
  KEY `ready_to_start_art` (`ready_to_start_art`),
  CONSTRAINT `etl_art_preparation_ibfk_1` FOREIGN KEY (`patient_id`) REFERENCES `etl_patient_demographics` (`patient_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `etl_art_preparation` */

/*Table structure for table `etl_ccc_defaulter_tracing` */

DROP TABLE IF EXISTS `etl_ccc_defaulter_tracing`;

CREATE TABLE `etl_ccc_defaulter_tracing` (
  `uuid` char(38) DEFAULT NULL,
  `provider` int(11) DEFAULT NULL,
  `patient_id` int(11) NOT NULL,
  `visit_id` int(11) DEFAULT NULL,
  `visit_date` date DEFAULT NULL,
  `location_id` int(11) DEFAULT NULL,
  `encounter_id` int(11) NOT NULL,
  `tracing_type` int(11) DEFAULT NULL,
  `tracing_outcome` int(11) DEFAULT NULL,
  `attempt_number` int(11) DEFAULT NULL,
  `is_final_trace` int(11) DEFAULT NULL,
  `true_status` int(11) DEFAULT NULL,
  `cause_of_death` int(11) DEFAULT NULL,
  `comments` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`encounter_id`),
  UNIQUE KEY `unique_uuid` (`uuid`),
  KEY `visit_date` (`visit_date`),
  KEY `encounter_id` (`encounter_id`),
  KEY `patient_id` (`patient_id`),
  KEY `true_status` (`true_status`),
  KEY `cause_of_death` (`cause_of_death`),
  KEY `tracing_type` (`tracing_type`),
  CONSTRAINT `etl_ccc_defaulter_tracing_ibfk_1` FOREIGN KEY (`patient_id`) REFERENCES `etl_patient_demographics` (`patient_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `etl_ccc_defaulter_tracing` */

/*Table structure for table `etl_cervical_cancer_screening` */

DROP TABLE IF EXISTS `etl_cervical_cancer_screening`;

CREATE TABLE `etl_cervical_cancer_screening` (
  `uuid` char(38) DEFAULT NULL,
  `encounter_id` int(11) NOT NULL,
  `encounter_provider` int(11) DEFAULT NULL,
  `patient_id` int(11) NOT NULL,
  `visit_id` int(11) DEFAULT NULL,
  `visit_date` date DEFAULT NULL,
  `location_id` int(11) DEFAULT NULL,
  `date_created` date DEFAULT NULL,
  `screening_number` int(11) DEFAULT NULL,
  `screening_method` varchar(255) DEFAULT NULL,
  `screening_result` varchar(255) DEFAULT NULL,
  `previous_screening_method` varchar(255) DEFAULT NULL,
  `previous_screening_date` date DEFAULT NULL,
  `previous_screening_result` varchar(255) DEFAULT NULL,
  `encounter_type` varchar(255) DEFAULT NULL,
  `voided` int(11) DEFAULT NULL,
  PRIMARY KEY (`encounter_id`),
  UNIQUE KEY `unique_uuid` (`uuid`),
  KEY `visit_date` (`visit_date`),
  KEY `screening_number` (`screening_number`),
  KEY `patient_id` (`patient_id`),
  KEY `patient_id_2` (`patient_id`,`visit_date`),
  CONSTRAINT `etl_cervical_cancer_screening_ibfk_1` FOREIGN KEY (`patient_id`) REFERENCES `etl_patient_demographics` (`patient_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `etl_cervical_cancer_screening` */

/*Table structure for table `etl_client_trace` */

DROP TABLE IF EXISTS `etl_client_trace`;

CREATE TABLE `etl_client_trace` (
  `id` int(11) DEFAULT NULL,
  `uuid` char(38) DEFAULT NULL,
  `date_created` date DEFAULT NULL,
  `encounter_date` datetime DEFAULT NULL,
  `client_id` int(11) DEFAULT NULL,
  `contact_type` varchar(255) DEFAULT NULL,
  `status` varchar(255) DEFAULT NULL,
  `unique_patient_no` varchar(255) DEFAULT NULL,
  `facility_linked_to` varchar(255) DEFAULT NULL,
  `health_worker_handed_to` varchar(255) DEFAULT NULL,
  `remarks` varchar(255) DEFAULT NULL,
  `appointment_date` datetime DEFAULT NULL,
  `voided` int(11) DEFAULT NULL,
  UNIQUE KEY `unique_uuid` (`uuid`),
  KEY `client_id` (`client_id`),
  KEY `date_created` (`date_created`),
  KEY `id` (`id`),
  KEY `id_2` (`id`,`date_created`),
  CONSTRAINT `etl_client_trace_ibfk_1` FOREIGN KEY (`client_id`) REFERENCES `etl_patient_contact` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `etl_client_trace` */

/*Table structure for table `etl_covid_19_enrolment` */

DROP TABLE IF EXISTS `etl_covid_19_enrolment`;

CREATE TABLE `etl_covid_19_enrolment` (
  `uuid` char(38) DEFAULT NULL,
  `encounter_id` int(11) NOT NULL,
  `visit_id` int(11) DEFAULT NULL,
  `patient_id` int(11) NOT NULL,
  `location_id` int(11) DEFAULT NULL,
  `visit_date` date DEFAULT NULL,
  `encounter_provider` int(11) DEFAULT NULL,
  `date_created` date DEFAULT NULL,
  `sub_county` varchar(255) DEFAULT NULL,
  `county` varchar(255) DEFAULT NULL,
  `detection_point` varchar(255) DEFAULT NULL,
  `date_detected` date DEFAULT NULL,
  `onset_symptoms_date` date DEFAULT NULL,
  `asymptomatic` varchar(10) DEFAULT NULL,
  `admitted_to_hospital` varchar(10) DEFAULT NULL,
  `date_of_first_admission` date DEFAULT NULL,
  `hospital_name` varchar(255) DEFAULT NULL,
  `date_of_isolation` date DEFAULT NULL,
  `patient_ventilated` varchar(10) DEFAULT NULL,
  `health_status_at_reporting` varchar(255) DEFAULT NULL,
  `date_of_death` date DEFAULT NULL,
  `recently_travelled` varchar(10) DEFAULT NULL,
  `country_recently_travelled` varchar(100) DEFAULT NULL,
  `city_recently_travelled` varchar(100) DEFAULT NULL,
  `recently_visited_health_facility` varchar(10) DEFAULT NULL,
  `recent_contact_with_infected_person` varchar(10) DEFAULT NULL,
  `recent_contact_with_confirmed_person` varchar(10) DEFAULT NULL,
  `recent_contact_setting` varchar(200) DEFAULT NULL,
  `recent_visit_to_animal_market` varchar(10) DEFAULT NULL,
  `animal_market_name` varchar(200) DEFAULT NULL,
  `voided` int(11) DEFAULT NULL,
  PRIMARY KEY (`encounter_id`),
  UNIQUE KEY `unique_uuid` (`uuid`),
  KEY `visit_date` (`visit_date`),
  KEY `visit_id` (`visit_id`),
  KEY `encounter_id` (`encounter_id`),
  KEY `patient_id` (`patient_id`),
  KEY `patient_id_2` (`patient_id`,`visit_date`),
  CONSTRAINT `etl_covid_19_enrolment_ibfk_1` FOREIGN KEY (`patient_id`) REFERENCES `etl_patient_demographics` (`patient_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `etl_covid_19_enrolment` */

/*Table structure for table `etl_crossborder_mobility_screening` */

DROP TABLE IF EXISTS `etl_crossborder_mobility_screening`;

CREATE TABLE `etl_crossborder_mobility_screening` (
  `UUID` char(38) DEFAULT NULL,
  `provider` int(11) DEFAULT NULL,
  `patient_id` int(11) NOT NULL,
  `visit_id` int(11) DEFAULT NULL,
  `visit_date` date DEFAULT NULL,
  `location_id` int(11) DEFAULT NULL,
  `encounter_id` int(11) NOT NULL,
  `country` int(11) DEFAULT NULL,
  `site` int(11) DEFAULT NULL,
  `visit_type` int(11) DEFAULT NULL,
  `nationality` int(11) DEFAULT NULL,
  `target_population` int(11) DEFAULT NULL,
  `travelled_in_last_3_months` int(11) DEFAULT NULL,
  `travelled_in_last_6_months` int(11) DEFAULT NULL,
  `travelled_in_last_12_months` int(11) DEFAULT NULL,
  `length_of_last_travel` int(11) DEFAULT NULL,
  `frequency_of_travel` int(11) DEFAULT NULL,
  `service` int(11) DEFAULT NULL,
  PRIMARY KEY (`encounter_id`),
  UNIQUE KEY `unique_uuid` (`UUID`),
  KEY `visit_date` (`visit_date`),
  KEY `patient_id` (`patient_id`),
  KEY `visit_date_2` (`visit_date`,`patient_id`),
  KEY `encounter_id` (`encounter_id`),
  KEY `country` (`country`),
  CONSTRAINT `etl_crossborder_mobility_screening_ibfk_1` FOREIGN KEY (`patient_id`) REFERENCES `etl_patient_demographics` (`patient_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `etl_crossborder_mobility_screening` */

/*Table structure for table `etl_current_in_care` */

DROP TABLE IF EXISTS `etl_current_in_care`;

CREATE TABLE `etl_current_in_care` (
  `visit_date` date DEFAULT NULL,
  `patient_id` int(11) NOT NULL,
  `dob` date DEFAULT NULL,
  `Gender` varchar(10) DEFAULT NULL,
  `enroll_date` date DEFAULT NULL,
  `latest_vis_date` date DEFAULT NULL,
  `latest_tca` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `unique_patient_no` varchar(50) DEFAULT NULL,
  `date_discontinued` datetime DEFAULT NULL,
  `disc_patient` int(11),
  `started_on_drugs` int(11),
  KEY `enroll_date` (`enroll_date`),
  KEY `latest_vis_date` (`latest_vis_date`),
  KEY `latest_tca` (`latest_tca`),
  KEY `started_on_drugs` (`started_on_drugs`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `etl_current_in_care` */

/*Table structure for table `etl_default_facility_info` */

DROP TABLE IF EXISTS `etl_default_facility_info`;

CREATE TABLE `etl_default_facility_info` (
  `siteCode` mediumtext CHARACTER SET utf8,
  `FacilityName` varchar(255) CHARACTER SET utf8 DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `etl_default_facility_info` */

insert  into `etl_default_facility_info`(`siteCode`,`FacilityName`) values ('16157','Vihiga District Hosptial');

/*Table structure for table `etl_drug_event` */

DROP TABLE IF EXISTS `etl_drug_event`;

CREATE TABLE `etl_drug_event` (
  `uuid` char(38) NOT NULL,
  `patient_id` int(11) NOT NULL,
  `date_started` date DEFAULT NULL,
  `visit_date` date DEFAULT NULL,
  `provider` int(11) DEFAULT NULL,
  `encounter_id` int(11) NOT NULL,
  `program` varchar(50) DEFAULT NULL,
  `regimen` mediumtext,
  `regimen_name` varchar(100) DEFAULT NULL,
  `regimen_line` varchar(50) DEFAULT NULL,
  `discontinued` int(11) DEFAULT NULL,
  `regimen_discontinued` varchar(255) DEFAULT NULL,
  `date_discontinued` date DEFAULT NULL,
  `reason_discontinued` int(11) DEFAULT NULL,
  `reason_discontinued_other` varchar(100) DEFAULT NULL,
  `voided` int(11) DEFAULT NULL,
  PRIMARY KEY (`uuid`),
  KEY `patient_id` (`patient_id`),
  KEY `date_started` (`date_started`),
  KEY `date_discontinued` (`date_discontinued`),
  KEY `patient_id_2` (`patient_id`,`date_started`),
  CONSTRAINT `etl_drug_event_ibfk_1` FOREIGN KEY (`patient_id`) REFERENCES `etl_patient_demographics` (`patient_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `etl_drug_event` */

/*Table structure for table `etl_enhanced_adherence` */

DROP TABLE IF EXISTS `etl_enhanced_adherence`;

CREATE TABLE `etl_enhanced_adherence` (
  `uuid` char(38) DEFAULT NULL,
  `patient_id` int(11) NOT NULL,
  `visit_id` int(11) DEFAULT NULL,
  `visit_date` date DEFAULT NULL,
  `location_id` int(11) DEFAULT NULL,
  `encounter_id` int(11) NOT NULL,
  `provider` int(11) DEFAULT NULL,
  `session_number` int(11) DEFAULT NULL,
  `first_session_date` date DEFAULT NULL,
  `pill_count` int(11) DEFAULT NULL,
  `arv_adherence` varchar(50) DEFAULT NULL,
  `has_vl_results` varchar(10) DEFAULT NULL,
  `vl_results_suppressed` varchar(10) DEFAULT NULL,
  `vl_results_feeling` varchar(255) DEFAULT NULL,
  `cause_of_high_vl` varchar(255) DEFAULT NULL,
  `way_forward` varchar(255) DEFAULT NULL,
  `patient_hiv_knowledge` varchar(255) DEFAULT NULL,
  `patient_drugs_uptake` varchar(255) DEFAULT NULL,
  `patient_drugs_reminder_tools` varchar(255) DEFAULT NULL,
  `patient_drugs_uptake_during_travels` varchar(255) DEFAULT NULL,
  `patient_drugs_side_effects_response` varchar(255) DEFAULT NULL,
  `patient_drugs_uptake_most_difficult_times` varchar(255) DEFAULT NULL,
  `patient_drugs_daily_uptake_feeling` varchar(255) DEFAULT NULL,
  `patient_ambitions` varchar(255) DEFAULT NULL,
  `patient_has_people_to_talk` varchar(10) DEFAULT NULL,
  `patient_enlisting_social_support` varchar(255) DEFAULT NULL,
  `patient_income_sources` varchar(255) DEFAULT NULL,
  `patient_challenges_reaching_clinic` varchar(10) DEFAULT NULL,
  `patient_worried_of_accidental_disclosure` varchar(10) DEFAULT NULL,
  `patient_treated_differently` varchar(10) DEFAULT NULL,
  `stigma_hinders_adherence` varchar(10) DEFAULT NULL,
  `patient_tried_faith_healing` varchar(10) DEFAULT NULL,
  `patient_adherence_improved` varchar(10) DEFAULT NULL,
  `patient_doses_missed` varchar(10) DEFAULT NULL,
  `review_and_barriers_to_adherence` varchar(255) DEFAULT NULL,
  `other_referrals` varchar(10) DEFAULT NULL,
  `appointments_honoured` varchar(10) DEFAULT NULL,
  `referral_experience` varchar(255) DEFAULT NULL,
  `home_visit_benefit` varchar(10) DEFAULT NULL,
  `adherence_plan` varchar(255) DEFAULT NULL,
  `next_appointment_date` date DEFAULT NULL,
  PRIMARY KEY (`encounter_id`),
  UNIQUE KEY `unique_uuid` (`uuid`),
  KEY `patient_id` (`patient_id`),
  KEY `visit_date` (`visit_date`),
  KEY `encounter_id` (`encounter_id`),
  CONSTRAINT `etl_enhanced_adherence_ibfk_1` FOREIGN KEY (`patient_id`) REFERENCES `etl_patient_demographics` (`patient_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `etl_enhanced_adherence` */

/*Table structure for table `etl_hei_enrollment` */

DROP TABLE IF EXISTS `etl_hei_enrollment`;

CREATE TABLE `etl_hei_enrollment` (
  `serial_no` int(11) NOT NULL AUTO_INCREMENT,
  `uuid` char(38) DEFAULT NULL,
  `patient_id` int(11) NOT NULL,
  `visit_id` int(11) DEFAULT NULL,
  `visit_date` date DEFAULT NULL,
  `location_id` int(11) DEFAULT NULL,
  `provider` int(11) DEFAULT NULL,
  `encounter_id` int(11) NOT NULL,
  `child_exposed` int(11) DEFAULT NULL,
  `hei_id_number` varchar(50) DEFAULT NULL,
  `spd_number` varchar(50) DEFAULT NULL,
  `birth_weight` double DEFAULT NULL,
  `gestation_at_birth` double DEFAULT NULL,
  `date_first_seen` date DEFAULT NULL,
  `birth_notification_number` varchar(50) DEFAULT NULL,
  `birth_certificate_number` varchar(50) DEFAULT NULL,
  `need_for_special_care` int(11) DEFAULT NULL,
  `reason_for_special_care` int(11) DEFAULT NULL,
  `referral_source` int(11) DEFAULT NULL,
  `transfer_in` int(11) DEFAULT NULL,
  `transfer_in_date` date DEFAULT NULL,
  `facility_transferred_from` varchar(50) DEFAULT NULL,
  `district_transferred_from` varchar(50) DEFAULT NULL,
  `date_first_enrolled_in_hei_care` date DEFAULT NULL,
  `arv_prophylaxis` int(11) DEFAULT NULL,
  `mother_breastfeeding` int(11) DEFAULT NULL,
  `mother_on_NVP_during_breastfeeding` int(11) DEFAULT NULL,
  `TB_contact_history_in_household` int(11) DEFAULT NULL,
  `infant_mother_link` int(11) DEFAULT NULL,
  `mother_alive` int(11) DEFAULT NULL,
  `mother_on_pmtct_drugs` int(11) DEFAULT NULL,
  `mother_on_drug` int(11) DEFAULT NULL,
  `mother_on_art_at_infant_enrollment` int(11) DEFAULT NULL,
  `mother_drug_regimen` int(11) DEFAULT NULL,
  `infant_prophylaxis` int(11) DEFAULT NULL,
  `parent_ccc_number` varchar(50) DEFAULT NULL,
  `mode_of_delivery` int(11) DEFAULT NULL,
  `place_of_delivery` int(11) DEFAULT NULL,
  `birth_length` int(11) DEFAULT NULL,
  `birth_order` int(11) DEFAULT NULL,
  `health_facility_name` varchar(50) DEFAULT NULL,
  `date_of_birth_notification` date DEFAULT NULL,
  `date_of_birth_registration` date DEFAULT NULL,
  `birth_registration_place` varchar(50) DEFAULT NULL,
  `permanent_registration_serial` varchar(50) DEFAULT NULL,
  `mother_facility_registered` varchar(50) DEFAULT NULL,
  `exit_date` date DEFAULT NULL,
  `exit_reason` int(11) DEFAULT NULL,
  `hiv_status_at_exit` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`encounter_id`),
  UNIQUE KEY `unique_uuid` (`uuid`),
  KEY `visit_date` (`visit_date`),
  KEY `encounter_id` (`encounter_id`),
  KEY `patient_id` (`patient_id`),
  KEY `transfer_in` (`transfer_in`),
  KEY `child_exposed` (`child_exposed`),
  KEY `need_for_special_care` (`need_for_special_care`),
  KEY `reason_for_special_care` (`reason_for_special_care`),
  KEY `referral_source` (`referral_source`),
  KEY `transfer_in_2` (`transfer_in`),
  KEY `serial_no` (`serial_no`),
  CONSTRAINT `etl_hei_enrollment_ibfk_1` FOREIGN KEY (`patient_id`) REFERENCES `etl_patient_demographics` (`patient_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `etl_hei_enrollment` */

/*Table structure for table `etl_hei_follow_up_visit` */

DROP TABLE IF EXISTS `etl_hei_follow_up_visit`;

CREATE TABLE `etl_hei_follow_up_visit` (
  `uuid` char(38) DEFAULT NULL,
  `provider` int(11) DEFAULT NULL,
  `patient_id` int(11) NOT NULL,
  `visit_id` int(11) DEFAULT NULL,
  `visit_date` date DEFAULT NULL,
  `location_id` int(11) DEFAULT NULL,
  `encounter_id` int(11) NOT NULL,
  `weight` double DEFAULT NULL,
  `height` double DEFAULT NULL,
  `primary_caregiver` int(11) DEFAULT NULL,
  `infant_feeding` int(11) DEFAULT NULL,
  `tb_assessment_outcome` int(11) DEFAULT NULL,
  `social_smile_milestone` int(11) DEFAULT NULL,
  `head_control_milestone` int(11) DEFAULT NULL,
  `response_to_sound_milestone` int(11) DEFAULT NULL,
  `hand_extension_milestone` int(11) DEFAULT NULL,
  `sitting_milestone` int(11) DEFAULT NULL,
  `walking_milestone` int(11) DEFAULT NULL,
  `standing_milestone` int(11) DEFAULT NULL,
  `talking_milestone` int(11) DEFAULT NULL,
  `review_of_systems_developmental` int(11) DEFAULT NULL,
  `dna_pcr_sample_date` date DEFAULT NULL,
  `dna_pcr_contextual_status` int(11) DEFAULT NULL,
  `dna_pcr_result` int(11) DEFAULT NULL,
  `dna_pcr_dbs_sample_code` varchar(100) DEFAULT NULL,
  `dna_pcr_results_date` date DEFAULT NULL,
  `azt_given` int(11) DEFAULT NULL,
  `nvp_given` int(11) DEFAULT NULL,
  `ctx_given` int(11) DEFAULT NULL,
  `first_antibody_sample_date` date DEFAULT NULL,
  `first_antibody_result` int(11) DEFAULT NULL,
  `first_antibody_dbs_sample_code` varchar(100) DEFAULT NULL,
  `first_antibody_result_date` date DEFAULT NULL,
  `final_antibody_sample_date` date DEFAULT NULL,
  `final_antibody_result` int(11) DEFAULT NULL,
  `final_antibody_dbs_sample_code` varchar(100) DEFAULT NULL,
  `final_antibody_result_date` date DEFAULT NULL,
  `tetracycline_ointment_given` int(11) DEFAULT NULL,
  `pupil_examination` int(11) DEFAULT NULL,
  `sight_examination` int(11) DEFAULT NULL,
  `squint` int(11) DEFAULT NULL,
  `deworming_drug` int(11) DEFAULT NULL,
  `dosage` int(11) DEFAULT NULL,
  `unit` varchar(100) DEFAULT NULL,
  `next_appointment_date` date DEFAULT NULL,
  `comments` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`encounter_id`),
  UNIQUE KEY `unique_uuid` (`uuid`),
  KEY `patient_id` (`patient_id`),
  KEY `visit_date` (`visit_date`),
  KEY `encounter_id` (`encounter_id`),
  KEY `infant_feeding` (`infant_feeding`),
  CONSTRAINT `etl_hei_follow_up_visit_ibfk_1` FOREIGN KEY (`patient_id`) REFERENCES `etl_patient_demographics` (`patient_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `etl_hei_follow_up_visit` */

/*Table structure for table `etl_hei_immunization` */

DROP TABLE IF EXISTS `etl_hei_immunization`;

CREATE TABLE `etl_hei_immunization` (
  `encounter_id` int(11) NOT NULL,
  `patient_id` int(11) NOT NULL,
  `visit_date` date DEFAULT NULL,
  `date_created` date DEFAULT NULL,
  `created_by` int(11) DEFAULT NULL,
  `BCG` varchar(50) DEFAULT NULL,
  `OPV_birth` varchar(50) DEFAULT NULL,
  `OPV_1` varchar(50) DEFAULT NULL,
  `OPV_2` varchar(50) DEFAULT NULL,
  `OPV_3` varchar(50) DEFAULT NULL,
  `IPV` varchar(50) DEFAULT NULL,
  `DPT_Hep_B_Hib_1` varchar(50) DEFAULT NULL,
  `DPT_Hep_B_Hib_2` varchar(50) DEFAULT NULL,
  `DPT_Hep_B_Hib_3` varchar(50) DEFAULT NULL,
  `PCV_10_1` varchar(50) DEFAULT NULL,
  `PCV_10_2` varchar(50) DEFAULT NULL,
  `PCV_10_3` varchar(50) DEFAULT NULL,
  `ROTA_1` varchar(50) DEFAULT NULL,
  `ROTA_2` varchar(50) DEFAULT NULL,
  `Measles_rubella_1` varchar(50) DEFAULT NULL,
  `Measles_rubella_2` varchar(50) DEFAULT NULL,
  `Yellow_fever` varchar(50) DEFAULT NULL,
  `Measles_6_months` varchar(50) DEFAULT NULL,
  `VitaminA_6_months` varchar(50) DEFAULT NULL,
  `VitaminA_1_yr` varchar(50) DEFAULT NULL,
  `VitaminA_1_and_half_yr` varchar(50) DEFAULT NULL,
  `VitaminA_2_yr` varchar(50) DEFAULT NULL,
  `VitaminA_2_to_5_yr` varchar(50) DEFAULT NULL,
  `fully_immunized` date DEFAULT NULL,
  PRIMARY KEY (`encounter_id`),
  KEY `patient_id` (`patient_id`),
  KEY `visit_date` (`visit_date`),
  KEY `encounter_id` (`encounter_id`),
  CONSTRAINT `etl_hei_immunization_ibfk_1` FOREIGN KEY (`patient_id`) REFERENCES `etl_patient_demographics` (`patient_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `etl_hei_immunization` */

/*Table structure for table `etl_hiv_enrollment` */

DROP TABLE IF EXISTS `etl_hiv_enrollment`;

CREATE TABLE `etl_hiv_enrollment` (
  `uuid` char(38) DEFAULT NULL,
  `patient_id` int(11) NOT NULL,
  `visit_id` int(11) DEFAULT NULL,
  `visit_date` date DEFAULT NULL,
  `location_id` int(11) DEFAULT NULL,
  `encounter_id` int(11) NOT NULL,
  `encounter_provider` int(11) DEFAULT NULL,
  `patient_type` int(11) DEFAULT NULL,
  `date_first_enrolled_in_care` date DEFAULT NULL,
  `entry_point` int(11) DEFAULT NULL,
  `transfer_in_date` date DEFAULT NULL,
  `facility_transferred_from` varchar(255) DEFAULT NULL,
  `district_transferred_from` varchar(255) DEFAULT NULL,
  `date_started_art_at_transferring_facility` date DEFAULT NULL,
  `date_confirmed_hiv_positive` date DEFAULT NULL,
  `facility_confirmed_hiv_positive` varchar(255) DEFAULT NULL,
  `arv_status` int(11) DEFAULT NULL,
  `name_of_treatment_supporter` varchar(255) DEFAULT NULL,
  `relationship_of_treatment_supporter` int(11) DEFAULT NULL,
  `treatment_supporter_telephone` varchar(100) DEFAULT NULL,
  `treatment_supporter_address` varchar(100) DEFAULT NULL,
  `date_of_discontinuation` datetime DEFAULT NULL,
  `discontinuation_reason` int(11) DEFAULT NULL,
  `date_created` date DEFAULT NULL,
  `voided` int(11) DEFAULT NULL,
  PRIMARY KEY (`encounter_id`),
  UNIQUE KEY `unique_uuid` (`uuid`),
  KEY `patient_id` (`patient_id`),
  KEY `visit_id` (`visit_id`),
  KEY `visit_date` (`visit_date`),
  KEY `date_started_art_at_transferring_facility` (`date_started_art_at_transferring_facility`),
  KEY `arv_status` (`arv_status`),
  KEY `date_confirmed_hiv_positive` (`date_confirmed_hiv_positive`),
  KEY `entry_point` (`entry_point`),
  KEY `transfer_in_date` (`transfer_in_date`),
  KEY `date_first_enrolled_in_care` (`date_first_enrolled_in_care`),
  KEY `entry_point_2` (`entry_point`,`transfer_in_date`,`visit_date`,`patient_id`),
  CONSTRAINT `etl_hiv_enrollment_ibfk_1` FOREIGN KEY (`patient_id`) REFERENCES `etl_patient_demographics` (`patient_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `etl_hiv_enrollment` */

/*Table structure for table `etl_hts_linkage_tracing` */

DROP TABLE IF EXISTS `etl_hts_linkage_tracing`;

CREATE TABLE `etl_hts_linkage_tracing` (
  `uuid` char(38) DEFAULT NULL,
  `encounter_id` int(11) NOT NULL,
  `patient_id` int(11) NOT NULL,
  `location_id` int(11) DEFAULT NULL,
  `visit_date` date DEFAULT NULL,
  `encounter_provider` int(11) DEFAULT NULL,
  `date_created` date DEFAULT NULL,
  `tracing_type` int(11) DEFAULT NULL,
  `tracing_outcome` int(11) DEFAULT NULL,
  `reason_not_contacted` int(11) DEFAULT NULL,
  `voided` int(11) DEFAULT NULL,
  PRIMARY KEY (`encounter_id`),
  UNIQUE KEY `unique_uuid` (`uuid`),
  KEY `visit_date` (`visit_date`),
  KEY `encounter_id` (`encounter_id`),
  KEY `patient_id` (`patient_id`),
  KEY `tracing_type` (`tracing_type`),
  KEY `tracing_outcome` (`tracing_outcome`),
  KEY `reason_not_contacted` (`reason_not_contacted`),
  KEY `patient_id_2` (`patient_id`,`visit_date`),
  CONSTRAINT `etl_hts_linkage_tracing_ibfk_1` FOREIGN KEY (`patient_id`) REFERENCES `etl_patient_demographics` (`patient_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `etl_hts_linkage_tracing` */

/*Table structure for table `etl_hts_referral` */

DROP TABLE IF EXISTS `etl_hts_referral`;

CREATE TABLE `etl_hts_referral` (
  `patient_id` int(11) NOT NULL,
  `visit_id` int(11) DEFAULT NULL,
  `encounter_id` int(11) NOT NULL,
  `encounter_uuid` char(38) NOT NULL,
  `encounter_location` int(11) NOT NULL,
  `creator` int(11) NOT NULL,
  `date_created` date NOT NULL,
  `visit_date` date DEFAULT NULL,
  `facility_referred_to` varchar(50) DEFAULT NULL,
  `date_to_enrol` date DEFAULT NULL,
  `remarks` varchar(100) DEFAULT NULL,
  `voided` int(11) DEFAULT NULL,
  PRIMARY KEY (`encounter_id`),
  KEY `patient_id` (`patient_id`),
  KEY `visit_date` (`visit_date`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `etl_hts_referral` */

/*Table structure for table `etl_hts_referral_and_linkage` */

DROP TABLE IF EXISTS `etl_hts_referral_and_linkage`;

CREATE TABLE `etl_hts_referral_and_linkage` (
  `patient_id` int(11) NOT NULL,
  `visit_id` int(11) DEFAULT NULL,
  `encounter_id` int(11) NOT NULL,
  `encounter_uuid` char(38) NOT NULL,
  `encounter_location` int(11) NOT NULL,
  `creator` int(11) NOT NULL,
  `date_created` date NOT NULL,
  `visit_date` date DEFAULT NULL,
  `tracing_type` varchar(50) DEFAULT NULL,
  `tracing_status` varchar(100) DEFAULT NULL,
  `ccc_number` varchar(100) DEFAULT NULL,
  `facility_linked_to` varchar(100) DEFAULT NULL,
  `enrollment_date` date DEFAULT NULL,
  `art_start_date` date DEFAULT NULL,
  `provider_handed_to` varchar(100) DEFAULT NULL,
  `voided` int(11) DEFAULT NULL,
  PRIMARY KEY (`encounter_id`),
  KEY `patient_id` (`patient_id`),
  KEY `visit_date` (`visit_date`),
  KEY `tracing_type` (`tracing_type`),
  KEY `tracing_status` (`tracing_status`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `etl_hts_referral_and_linkage` */

/*Table structure for table `etl_hts_test` */

DROP TABLE IF EXISTS `etl_hts_test`;

CREATE TABLE `etl_hts_test` (
  `patient_id` int(11) NOT NULL,
  `visit_id` int(11) DEFAULT NULL,
  `encounter_id` int(11) NOT NULL,
  `encounter_uuid` char(38) NOT NULL,
  `encounter_location` int(11) NOT NULL,
  `creator` int(11) NOT NULL,
  `date_created` date NOT NULL,
  `visit_date` date DEFAULT NULL,
  `test_type` int(11) DEFAULT NULL,
  `population_type` varchar(50) DEFAULT NULL,
  `key_population_type` varchar(50) DEFAULT NULL,
  `ever_tested_for_hiv` varchar(10) DEFAULT NULL,
  `months_since_last_test` int(11) DEFAULT NULL,
  `patient_disabled` varchar(50) DEFAULT NULL,
  `disability_type` varchar(50) DEFAULT NULL,
  `patient_consented` varchar(50) DEFAULT NULL,
  `client_tested_as` varchar(50) DEFAULT NULL,
  `test_strategy` varchar(50) DEFAULT NULL,
  `hts_entry_point` varchar(50) DEFAULT NULL,
  `test_1_kit_name` varchar(50) DEFAULT NULL,
  `test_1_kit_lot_no` varchar(50) DEFAULT NULL,
  `test_1_kit_expiry` date DEFAULT NULL,
  `test_1_result` varchar(50) DEFAULT NULL,
  `test_2_kit_name` varchar(50) DEFAULT NULL,
  `test_2_kit_lot_no` varchar(50) DEFAULT NULL,
  `test_2_kit_expiry` date DEFAULT NULL,
  `test_2_result` varchar(50) DEFAULT NULL,
  `final_test_result` varchar(50) DEFAULT NULL,
  `patient_given_result` varchar(50) DEFAULT NULL,
  `couple_discordant` varchar(100) DEFAULT NULL,
  `tb_screening` varchar(20) DEFAULT NULL,
  `patient_had_hiv_self_test` varchar(50) DEFAULT NULL,
  `remarks` varchar(255) DEFAULT NULL,
  `voided` int(11) DEFAULT NULL,
  PRIMARY KEY (`encounter_id`),
  KEY `patient_id` (`patient_id`),
  KEY `visit_id` (`visit_id`),
  KEY `tb_screening` (`tb_screening`),
  KEY `visit_date` (`visit_date`),
  KEY `population_type` (`population_type`),
  KEY `test_type` (`test_type`),
  KEY `final_test_result` (`final_test_result`),
  KEY `couple_discordant` (`couple_discordant`),
  KEY `test_1_kit_name` (`test_1_kit_name`),
  KEY `test_2_kit_name` (`test_2_kit_name`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `etl_hts_test` */

/*Table structure for table `etl_ipt_follow_up` */

DROP TABLE IF EXISTS `etl_ipt_follow_up`;

CREATE TABLE `etl_ipt_follow_up` (
  `uuid` char(38) DEFAULT NULL,
  `patient_id` int(11) NOT NULL,
  `visit_id` int(11) DEFAULT NULL,
  `visit_date` date DEFAULT NULL,
  `location_id` int(11) DEFAULT NULL,
  `encounter_id` int(11) NOT NULL,
  `provider` int(11) DEFAULT NULL,
  `date_created` date NOT NULL,
  `ipt_due_date` date DEFAULT NULL,
  `date_collected_ipt` date DEFAULT NULL,
  `weight` double DEFAULT NULL,
  `hepatotoxity` varchar(100) DEFAULT NULL,
  `peripheral_neuropathy` varchar(100) DEFAULT NULL,
  `rash` varchar(100) DEFAULT NULL,
  `adherence` varchar(100) DEFAULT NULL,
  `action_taken` varchar(100) DEFAULT NULL,
  `voided` int(11) DEFAULT NULL,
  PRIMARY KEY (`encounter_id`),
  UNIQUE KEY `unique_uuid` (`uuid`),
  KEY `visit_date` (`visit_date`),
  KEY `encounter_id` (`encounter_id`),
  KEY `patient_id` (`patient_id`),
  KEY `hepatotoxity` (`hepatotoxity`),
  KEY `peripheral_neuropathy` (`peripheral_neuropathy`),
  KEY `rash` (`rash`),
  KEY `adherence` (`adherence`),
  CONSTRAINT `etl_ipt_follow_up_ibfk_1` FOREIGN KEY (`patient_id`) REFERENCES `etl_patient_demographics` (`patient_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `etl_ipt_follow_up` */

/*Table structure for table `etl_ipt_initiation` */

DROP TABLE IF EXISTS `etl_ipt_initiation`;

CREATE TABLE `etl_ipt_initiation` (
  `uuid` char(38) DEFAULT NULL,
  `encounter_id` int(11) NOT NULL,
  `patient_id` int(11) NOT NULL,
  `location_id` int(11) DEFAULT NULL,
  `visit_date` date DEFAULT NULL,
  `encounter_provider` int(11) DEFAULT NULL,
  `date_created` date DEFAULT NULL,
  `ipt_indication` int(11) DEFAULT NULL,
  `sub_county_reg_number` varchar(255) DEFAULT NULL,
  `sub_county_reg_date` date DEFAULT NULL,
  `voided` int(11) DEFAULT NULL,
  PRIMARY KEY (`encounter_id`),
  UNIQUE KEY `unique_uuid` (`uuid`),
  KEY `visit_date` (`visit_date`),
  KEY `encounter_id` (`encounter_id`),
  KEY `patient_id` (`patient_id`),
  KEY `patient_id_2` (`patient_id`,`visit_date`),
  CONSTRAINT `etl_ipt_initiation_ibfk_1` FOREIGN KEY (`patient_id`) REFERENCES `etl_patient_demographics` (`patient_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `etl_ipt_initiation` */

/*Table structure for table `etl_ipt_outcome` */

DROP TABLE IF EXISTS `etl_ipt_outcome`;

CREATE TABLE `etl_ipt_outcome` (
  `uuid` char(38) DEFAULT NULL,
  `encounter_id` int(11) NOT NULL,
  `patient_id` int(11) NOT NULL,
  `location_id` int(11) DEFAULT NULL,
  `visit_date` date DEFAULT NULL,
  `encounter_provider` int(11) DEFAULT NULL,
  `date_created` date DEFAULT NULL,
  `outcome` int(11) DEFAULT NULL,
  `voided` int(11) DEFAULT NULL,
  PRIMARY KEY (`encounter_id`),
  UNIQUE KEY `unique_uuid` (`uuid`),
  KEY `visit_date` (`visit_date`),
  KEY `encounter_id` (`encounter_id`),
  KEY `patient_id` (`patient_id`),
  KEY `outcome` (`outcome`),
  KEY `patient_id_2` (`patient_id`,`visit_date`),
  CONSTRAINT `etl_ipt_outcome_ibfk_1` FOREIGN KEY (`patient_id`) REFERENCES `etl_patient_demographics` (`patient_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `etl_ipt_outcome` */

/*Table structure for table `etl_ipt_screening` */

DROP TABLE IF EXISTS `etl_ipt_screening`;

CREATE TABLE `etl_ipt_screening` (
  `uuid` char(38) DEFAULT NULL,
  `provider` int(11) DEFAULT NULL,
  `patient_id` int(11) NOT NULL,
  `visit_id` int(11) DEFAULT NULL,
  `visit_date` date DEFAULT NULL,
  `location_id` int(11) DEFAULT NULL,
  `encounter_id` int(11) NOT NULL,
  `yellow_urine` int(11) DEFAULT NULL,
  `numbness` int(11) DEFAULT NULL,
  `yellow_eyes` int(11) DEFAULT NULL,
  `abdominal_tenderness` int(11) DEFAULT NULL,
  `ipt_started` int(11) DEFAULT NULL,
  PRIMARY KEY (`encounter_id`),
  UNIQUE KEY `unique_uuid` (`uuid`),
  KEY `visit_date` (`visit_date`),
  KEY `patient_id` (`patient_id`),
  KEY `visit_date_2` (`visit_date`,`ipt_started`,`patient_id`),
  KEY `ipt_started` (`ipt_started`,`visit_date`),
  KEY `encounter_id` (`encounter_id`),
  KEY `ipt_started_2` (`ipt_started`),
  CONSTRAINT `etl_ipt_screening_ibfk_1` FOREIGN KEY (`patient_id`) REFERENCES `etl_patient_demographics` (`patient_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `etl_ipt_screening` */

/*Table structure for table `etl_laboratory_extract` */

DROP TABLE IF EXISTS `etl_laboratory_extract`;

CREATE TABLE `etl_laboratory_extract` (
  `uuid` char(38) NOT NULL,
  `encounter_id` int(11) DEFAULT NULL,
  `patient_id` int(11) NOT NULL,
  `location_id` int(11) DEFAULT NULL,
  `visit_date` date DEFAULT NULL,
  `visit_id` int(11) DEFAULT NULL,
  `order_id` varchar(200) DEFAULT NULL,
  `lab_test` varchar(180) DEFAULT NULL,
  `urgency` varchar(50) DEFAULT NULL,
  `test_result` varchar(180) DEFAULT NULL,
  `date_test_requested` date DEFAULT NULL,
  `date_test_result_received` date DEFAULT NULL,
  `test_requested_by` int(11) DEFAULT NULL,
  `date_created` date DEFAULT NULL,
  `created_by` int(11) DEFAULT NULL,
  PRIMARY KEY (`uuid`),
  KEY `visit_date` (`visit_date`),
  KEY `encounter_id` (`encounter_id`),
  KEY `patient_id` (`patient_id`),
  KEY `lab_test` (`lab_test`),
  KEY `test_result` (`test_result`),
  CONSTRAINT `etl_laboratory_extract_ibfk_1` FOREIGN KEY (`patient_id`) REFERENCES `etl_patient_demographics` (`patient_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `etl_laboratory_extract` */

/*Table structure for table `etl_last_month_newly_enrolled_in_care` */

DROP TABLE IF EXISTS `etl_last_month_newly_enrolled_in_care`;

CREATE TABLE `etl_last_month_newly_enrolled_in_care` (
  `patient_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `etl_last_month_newly_enrolled_in_care` */

/*Table structure for table `etl_last_month_newly_on_art` */

DROP TABLE IF EXISTS `etl_last_month_newly_on_art`;

CREATE TABLE `etl_last_month_newly_on_art` (
  `patient_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `etl_last_month_newly_on_art` */

/*Table structure for table `etl_mch_antenatal_visit` */

DROP TABLE IF EXISTS `etl_mch_antenatal_visit`;

CREATE TABLE `etl_mch_antenatal_visit` (
  `uuid` char(38) DEFAULT NULL,
  `patient_id` int(11) NOT NULL,
  `visit_id` int(11) DEFAULT NULL,
  `visit_date` date DEFAULT NULL,
  `location_id` int(11) DEFAULT NULL,
  `encounter_id` int(11) NOT NULL,
  `provider` int(11) DEFAULT NULL,
  `anc_visit_number` int(11) DEFAULT NULL,
  `temperature` double DEFAULT NULL,
  `pulse_rate` double DEFAULT NULL,
  `systolic_bp` double DEFAULT NULL,
  `diastolic_bp` double DEFAULT NULL,
  `respiratory_rate` double DEFAULT NULL,
  `oxygen_saturation` int(11) DEFAULT NULL,
  `weight` double DEFAULT NULL,
  `height` double DEFAULT NULL,
  `muac` double DEFAULT NULL,
  `hemoglobin` double DEFAULT NULL,
  `breast_exam_done` int(11) DEFAULT NULL,
  `pallor` int(11) DEFAULT NULL,
  `maturity` int(11) DEFAULT NULL,
  `fundal_height` double DEFAULT NULL,
  `fetal_presentation` int(11) DEFAULT NULL,
  `lie` int(11) DEFAULT NULL,
  `fetal_heart_rate` int(11) DEFAULT NULL,
  `fetal_movement` int(11) DEFAULT NULL,
  `who_stage` int(11) DEFAULT NULL,
  `cd4` int(11) DEFAULT NULL,
  `viral_load` int(11) DEFAULT NULL,
  `ldl` int(11) DEFAULT NULL,
  `arv_status` int(11) DEFAULT NULL,
  `test_1_kit_name` varchar(50) DEFAULT NULL,
  `test_1_kit_lot_no` varchar(50) DEFAULT NULL,
  `test_1_kit_expiry` date DEFAULT NULL,
  `test_1_result` varchar(50) DEFAULT NULL,
  `test_2_kit_name` varchar(50) DEFAULT NULL,
  `test_2_kit_lot_no` varchar(50) DEFAULT NULL,
  `test_2_kit_expiry` date DEFAULT NULL,
  `test_2_result` varchar(50) DEFAULT NULL,
  `final_test_result` varchar(50) DEFAULT NULL,
  `patient_given_result` varchar(50) DEFAULT NULL,
  `partner_hiv_tested` int(11) DEFAULT NULL,
  `partner_hiv_status` int(11) DEFAULT NULL,
  `prophylaxis_given` int(11) DEFAULT NULL,
  `baby_azt_dispensed` int(11) DEFAULT NULL,
  `baby_nvp_dispensed` int(11) DEFAULT NULL,
  `TTT` varchar(50) DEFAULT NULL,
  `IPT_malaria` varchar(50) DEFAULT NULL,
  `iron_supplement` varchar(50) DEFAULT NULL,
  `deworming` varchar(50) DEFAULT NULL,
  `bed_nets` varchar(50) DEFAULT NULL,
  `urine_microscopy` varchar(100) DEFAULT NULL,
  `urinary_albumin` int(11) DEFAULT NULL,
  `glucose_measurement` int(11) DEFAULT NULL,
  `urine_ph` int(11) DEFAULT NULL,
  `urine_gravity` int(11) DEFAULT NULL,
  `urine_nitrite_test` int(11) DEFAULT NULL,
  `urine_leukocyte_esterace_test` int(11) DEFAULT NULL,
  `urinary_ketone` int(11) DEFAULT NULL,
  `urine_bile_salt_test` int(11) DEFAULT NULL,
  `urine_bile_pigment_test` int(11) DEFAULT NULL,
  `urine_colour` int(11) DEFAULT NULL,
  `urine_turbidity` int(11) DEFAULT NULL,
  `urine_dipstick_for_blood` int(11) DEFAULT NULL,
  `syphilis_test_status` int(11) DEFAULT NULL,
  `syphilis_treated_status` int(11) DEFAULT NULL,
  `bs_mps` int(11) DEFAULT NULL,
  `anc_exercises` int(11) DEFAULT NULL,
  `tb_screening` int(11) DEFAULT NULL,
  `cacx_screening` int(11) DEFAULT NULL,
  `cacx_screening_method` int(11) DEFAULT NULL,
  `has_other_illnes` int(11) DEFAULT NULL,
  `counselled` int(11) DEFAULT NULL,
  `referred_from` int(11) DEFAULT NULL,
  `referred_to` int(11) DEFAULT NULL,
  `next_appointment_date` date DEFAULT NULL,
  `clinical_notes` varchar(200) DEFAULT NULL,
  PRIMARY KEY (`encounter_id`),
  UNIQUE KEY `unique_uuid` (`uuid`),
  KEY `patient_id` (`patient_id`),
  KEY `visit_date` (`visit_date`),
  KEY `encounter_id` (`encounter_id`),
  KEY `who_stage` (`who_stage`),
  KEY `anc_visit_number` (`anc_visit_number`),
  KEY `final_test_result` (`final_test_result`),
  KEY `tb_screening` (`tb_screening`),
  KEY `syphilis_test_status` (`syphilis_test_status`),
  KEY `cacx_screening` (`cacx_screening`),
  KEY `next_appointment_date` (`next_appointment_date`),
  KEY `arv_status` (`arv_status`),
  CONSTRAINT `etl_mch_antenatal_visit_ibfk_1` FOREIGN KEY (`patient_id`) REFERENCES `etl_patient_demographics` (`patient_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `etl_mch_antenatal_visit` */

/*Table structure for table `etl_mch_enrollment` */

DROP TABLE IF EXISTS `etl_mch_enrollment`;

CREATE TABLE `etl_mch_enrollment` (
  `uuid` char(38) DEFAULT NULL,
  `patient_id` int(11) NOT NULL,
  `visit_id` int(11) DEFAULT NULL,
  `visit_date` date DEFAULT NULL,
  `location_id` int(11) DEFAULT NULL,
  `encounter_id` int(11) NOT NULL,
  `anc_number` varchar(50) DEFAULT NULL,
  `first_anc_visit_date` date DEFAULT NULL,
  `gravida` int(11) DEFAULT NULL,
  `parity` int(11) DEFAULT NULL,
  `parity_abortion` int(11) DEFAULT NULL,
  `age_at_menarche` int(11) DEFAULT NULL,
  `lmp` date DEFAULT NULL,
  `lmp_estimated` int(11) DEFAULT NULL,
  `edd_ultrasound` date DEFAULT NULL,
  `blood_group` int(11) DEFAULT NULL,
  `serology` int(11) DEFAULT NULL,
  `tb_screening` int(11) DEFAULT NULL,
  `bs_for_mps` int(11) DEFAULT NULL,
  `hiv_status` int(11) DEFAULT NULL,
  `hiv_test_date` date DEFAULT NULL,
  `partner_hiv_status` int(11) DEFAULT NULL,
  `partner_hiv_test_date` date DEFAULT NULL,
  `urine_microscopy` varchar(100) DEFAULT NULL,
  `urinary_albumin` int(11) DEFAULT NULL,
  `glucose_measurement` int(11) DEFAULT NULL,
  `urine_ph` int(11) DEFAULT NULL,
  `urine_gravity` int(11) DEFAULT NULL,
  `urine_nitrite_test` int(11) DEFAULT NULL,
  `urine_leukocyte_esterace_test` int(11) DEFAULT NULL,
  `urinary_ketone` int(11) DEFAULT NULL,
  `urine_bile_salt_test` int(11) DEFAULT NULL,
  `urine_bile_pigment_test` int(11) DEFAULT NULL,
  `urine_colour` int(11) DEFAULT NULL,
  `urine_turbidity` int(11) DEFAULT NULL,
  `urine_dipstick_for_blood` int(11) DEFAULT NULL,
  `date_of_discontinuation` datetime DEFAULT NULL,
  `discontinuation_reason` int(11) DEFAULT NULL,
  PRIMARY KEY (`encounter_id`),
  UNIQUE KEY `unique_uuid` (`uuid`),
  KEY `patient_id` (`patient_id`),
  KEY `visit_date` (`visit_date`),
  KEY `encounter_id` (`encounter_id`),
  KEY `tb_screening` (`tb_screening`),
  KEY `hiv_status` (`hiv_status`),
  KEY `hiv_test_date` (`hiv_test_date`),
  KEY `partner_hiv_status` (`partner_hiv_status`),
  CONSTRAINT `etl_mch_enrollment_ibfk_1` FOREIGN KEY (`patient_id`) REFERENCES `etl_patient_demographics` (`patient_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `etl_mch_enrollment` */

/*Table structure for table `etl_mch_postnatal_visit` */

DROP TABLE IF EXISTS `etl_mch_postnatal_visit`;

CREATE TABLE `etl_mch_postnatal_visit` (
  `uuid` char(38) DEFAULT NULL,
  `patient_id` int(11) NOT NULL,
  `visit_id` int(11) DEFAULT NULL,
  `visit_date` date DEFAULT NULL,
  `location_id` int(11) DEFAULT NULL,
  `encounter_id` int(11) NOT NULL,
  `provider` int(11) DEFAULT NULL,
  `pnc_register_no` varchar(50) DEFAULT NULL,
  `pnc_visit_no` int(11) DEFAULT NULL,
  `delivery_date` date DEFAULT NULL,
  `mode_of_delivery` int(11) DEFAULT NULL,
  `place_of_delivery` int(11) DEFAULT NULL,
  `temperature` double DEFAULT NULL,
  `pulse_rate` double DEFAULT NULL,
  `systolic_bp` double DEFAULT NULL,
  `diastolic_bp` double DEFAULT NULL,
  `respiratory_rate` double DEFAULT NULL,
  `oxygen_saturation` int(11) DEFAULT NULL,
  `weight` double DEFAULT NULL,
  `height` double DEFAULT NULL,
  `muac` double DEFAULT NULL,
  `hemoglobin` double DEFAULT NULL,
  `arv_status` int(11) DEFAULT NULL,
  `general_condition` int(11) DEFAULT NULL,
  `breast` int(11) DEFAULT NULL,
  `cs_scar` int(11) DEFAULT NULL,
  `gravid_uterus` int(11) DEFAULT NULL,
  `episiotomy` int(11) DEFAULT NULL,
  `lochia` int(11) DEFAULT NULL,
  `pallor` int(11) DEFAULT NULL,
  `pph` int(11) DEFAULT NULL,
  `mother_hiv_status` int(11) DEFAULT NULL,
  `condition_of_baby` int(11) DEFAULT NULL,
  `baby_feeding_method` int(11) DEFAULT NULL,
  `umblical_cord` int(11) DEFAULT NULL,
  `baby_immunization_started` int(11) DEFAULT NULL,
  `family_planning_counseling` int(11) DEFAULT NULL,
  `uterus_examination` varchar(100) DEFAULT NULL,
  `uterus_cervix_examination` varchar(100) DEFAULT NULL,
  `vaginal_examination` varchar(100) DEFAULT NULL,
  `parametrial_examination` varchar(100) DEFAULT NULL,
  `external_genitalia_examination` varchar(100) DEFAULT NULL,
  `ovarian_examination` varchar(100) DEFAULT NULL,
  `pelvic_lymph_node_exam` varchar(100) DEFAULT NULL,
  `test_1_kit_name` varchar(50) DEFAULT NULL,
  `test_1_kit_lot_no` varchar(50) DEFAULT NULL,
  `test_1_kit_expiry` date DEFAULT NULL,
  `test_1_result` varchar(50) DEFAULT NULL,
  `test_2_kit_name` varchar(50) DEFAULT NULL,
  `test_2_kit_lot_no` varchar(50) DEFAULT NULL,
  `test_2_kit_expiry` date DEFAULT NULL,
  `test_2_result` varchar(50) DEFAULT NULL,
  `final_test_result` varchar(50) DEFAULT NULL,
  `patient_given_result` varchar(50) DEFAULT NULL,
  `partner_hiv_tested` int(11) DEFAULT NULL,
  `partner_hiv_status` int(11) DEFAULT NULL,
  `prophylaxis_given` int(11) DEFAULT NULL,
  `baby_azt_dispensed` int(11) DEFAULT NULL,
  `baby_nvp_dispensed` int(11) DEFAULT NULL,
  `pnc_exercises` int(11) DEFAULT NULL,
  `maternal_condition` int(11) DEFAULT NULL,
  `iron_supplementation` int(11) DEFAULT NULL,
  `fistula_screening` int(11) DEFAULT NULL,
  `cacx_screening` int(11) DEFAULT NULL,
  `cacx_screening_method` int(11) DEFAULT NULL,
  `family_planning_status` int(11) DEFAULT NULL,
  `family_planning_method` int(11) DEFAULT NULL,
  `referred_from` int(11) DEFAULT NULL,
  `referred_to` int(11) DEFAULT NULL,
  `clinical_notes` varchar(200) DEFAULT NULL,
  PRIMARY KEY (`encounter_id`),
  UNIQUE KEY `unique_uuid` (`uuid`),
  KEY `visit_date` (`visit_date`),
  KEY `encounter_id` (`encounter_id`),
  KEY `patient_id` (`patient_id`),
  KEY `arv_status` (`arv_status`),
  KEY `mother_hiv_status` (`mother_hiv_status`),
  KEY `arv_status_2` (`arv_status`),
  CONSTRAINT `etl_mch_postnatal_visit_ibfk_1` FOREIGN KEY (`patient_id`) REFERENCES `etl_patient_demographics` (`patient_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `etl_mch_postnatal_visit` */

/*Table structure for table `etl_mchs_delivery` */

DROP TABLE IF EXISTS `etl_mchs_delivery`;

CREATE TABLE `etl_mchs_delivery` (
  `uuid` char(38) DEFAULT NULL,
  `provider` int(11) DEFAULT NULL,
  `patient_id` int(11) NOT NULL,
  `visit_id` int(11) DEFAULT NULL,
  `visit_date` date DEFAULT NULL,
  `location_id` int(11) DEFAULT NULL,
  `encounter_id` int(11) NOT NULL,
  `date_created` date DEFAULT NULL,
  `admission_number` varchar(50) DEFAULT NULL,
  `duration_of_pregnancy` double DEFAULT NULL,
  `mode_of_delivery` int(11) DEFAULT NULL,
  `date_of_delivery` datetime DEFAULT NULL,
  `blood_loss` int(11) DEFAULT NULL,
  `condition_of_mother` int(11) DEFAULT NULL,
  `apgar_score_1min` double DEFAULT NULL,
  `apgar_score_5min` double DEFAULT NULL,
  `apgar_score_10min` double DEFAULT NULL,
  `resuscitation_done` int(11) DEFAULT NULL,
  `place_of_delivery` int(11) DEFAULT NULL,
  `delivery_assistant` varchar(100) DEFAULT NULL,
  `counseling_on_infant_feeding` int(11) DEFAULT NULL,
  `counseling_on_exclusive_breastfeeding` int(11) DEFAULT NULL,
  `counseling_on_infant_feeding_for_hiv_infected` int(11) DEFAULT NULL,
  `mother_decision` int(11) DEFAULT NULL,
  `placenta_complete` int(11) DEFAULT NULL,
  `maternal_death_audited` int(11) DEFAULT NULL,
  `cadre` int(11) DEFAULT NULL,
  `delivery_complications` int(11) DEFAULT NULL,
  `coded_delivery_complications` int(11) DEFAULT NULL,
  `other_delivery_complications` varchar(100) DEFAULT NULL,
  `duration_of_labor` int(11) DEFAULT NULL,
  `baby_sex` int(11) DEFAULT NULL,
  `baby_condition` int(11) DEFAULT NULL,
  `teo_given` int(11) DEFAULT NULL,
  `birth_weight` int(11) DEFAULT NULL,
  `bf_within_one_hour` int(11) DEFAULT NULL,
  `birth_with_deformity` int(11) DEFAULT NULL,
  `test_1_kit_name` varchar(50) DEFAULT NULL,
  `test_1_kit_lot_no` varchar(50) DEFAULT NULL,
  `test_1_kit_expiry` date DEFAULT NULL,
  `test_1_result` varchar(50) DEFAULT NULL,
  `test_2_kit_name` varchar(50) DEFAULT NULL,
  `test_2_kit_lot_no` varchar(50) DEFAULT NULL,
  `test_2_kit_expiry` date DEFAULT NULL,
  `test_2_result` varchar(50) DEFAULT NULL,
  `final_test_result` varchar(50) DEFAULT NULL,
  `patient_given_result` varchar(50) DEFAULT NULL,
  `partner_hiv_tested` int(11) DEFAULT NULL,
  `partner_hiv_status` int(11) DEFAULT NULL,
  `prophylaxis_given` int(11) DEFAULT NULL,
  `baby_azt_dispensed` int(11) DEFAULT NULL,
  `baby_nvp_dispensed` int(11) DEFAULT NULL,
  `clinical_notes` varchar(200) DEFAULT NULL,
  PRIMARY KEY (`encounter_id`),
  UNIQUE KEY `unique_uuid` (`uuid`),
  KEY `patient_id` (`patient_id`),
  KEY `visit_date` (`visit_date`),
  KEY `encounter_id` (`encounter_id`),
  KEY `final_test_result` (`final_test_result`),
  KEY `baby_sex` (`baby_sex`),
  KEY `partner_hiv_tested` (`partner_hiv_tested`),
  KEY `partner_hiv_status` (`partner_hiv_status`),
  CONSTRAINT `etl_mchs_delivery_ibfk_1` FOREIGN KEY (`patient_id`) REFERENCES `etl_patient_demographics` (`patient_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `etl_mchs_delivery` */

/*Table structure for table `etl_mchs_discharge` */

DROP TABLE IF EXISTS `etl_mchs_discharge`;

CREATE TABLE `etl_mchs_discharge` (
  `uuid` char(38) DEFAULT NULL,
  `provider` int(11) DEFAULT NULL,
  `patient_id` int(11) NOT NULL,
  `visit_id` int(11) DEFAULT NULL,
  `visit_date` date DEFAULT NULL,
  `location_id` int(11) DEFAULT NULL,
  `encounter_id` int(11) NOT NULL,
  `date_created` date DEFAULT NULL,
  `counselled_on_feeding` int(11) DEFAULT NULL,
  `baby_status` int(11) DEFAULT NULL,
  `vitamin_A_dispensed` int(11) DEFAULT NULL,
  `birth_notification_number` int(50) DEFAULT NULL,
  `condition_of_mother` varchar(100) DEFAULT NULL,
  `discharge_date` date DEFAULT NULL,
  `referred_from` int(11) DEFAULT NULL,
  `referred_to` int(11) DEFAULT NULL,
  `clinical_notes` varchar(200) DEFAULT NULL,
  PRIMARY KEY (`encounter_id`),
  UNIQUE KEY `unique_uuid` (`uuid`),
  KEY `patient_id` (`patient_id`),
  KEY `visit_date` (`visit_date`),
  KEY `encounter_id` (`encounter_id`),
  KEY `baby_status` (`baby_status`),
  KEY `discharge_date` (`discharge_date`),
  CONSTRAINT `etl_mchs_discharge_ibfk_1` FOREIGN KEY (`patient_id`) REFERENCES `etl_patient_demographics` (`patient_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `etl_mchs_discharge` */

/*Table structure for table `etl_missed_appointments` */

DROP TABLE IF EXISTS `etl_missed_appointments`;

CREATE TABLE `etl_missed_appointments` (
  `id` int(11) NOT NULL,
  `patient_id` int(11) NOT NULL,
  `last_tca_date` date DEFAULT NULL,
  `last_visit_date` date DEFAULT NULL,
  `last_encounter_type` varchar(100) DEFAULT NULL,
  `days_since_last_visit` int(11) DEFAULT NULL,
  `date_table_created` date DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `patient_id` (`patient_id`),
  CONSTRAINT `etl_missed_appointments_ibfk_1` FOREIGN KEY (`patient_id`) REFERENCES `etl_patient_demographics` (`patient_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `etl_missed_appointments` */

/*Table structure for table `etl_otz_activity` */

DROP TABLE IF EXISTS `etl_otz_activity`;

CREATE TABLE `etl_otz_activity` (
  `uuid` char(38) DEFAULT NULL,
  `encounter_id` int(11) NOT NULL,
  `patient_id` int(11) NOT NULL,
  `location_id` int(11) DEFAULT NULL,
  `visit_date` date DEFAULT NULL,
  `encounter_provider` int(11) DEFAULT NULL,
  `date_created` date DEFAULT NULL,
  `orientation` varchar(11) DEFAULT NULL,
  `leadership` varchar(11) DEFAULT NULL,
  `participation` varchar(11) DEFAULT NULL,
  `treatment_literacy` varchar(11) DEFAULT NULL,
  `transition_to_adult_care` varchar(11) DEFAULT NULL,
  `making_decision_future` varchar(11) DEFAULT NULL,
  `srh` varchar(11) DEFAULT NULL,
  `beyond_third_ninety` varchar(11) DEFAULT NULL,
  `attended_support_group` varchar(11) DEFAULT NULL,
  `remarks` varchar(255) DEFAULT NULL,
  `voided` int(11) DEFAULT NULL,
  PRIMARY KEY (`encounter_id`),
  UNIQUE KEY `unique_uuid` (`uuid`),
  KEY `visit_date` (`visit_date`),
  KEY `encounter_id` (`encounter_id`),
  KEY `patient_id` (`patient_id`),
  KEY `patient_id_2` (`patient_id`,`visit_date`),
  CONSTRAINT `etl_otz_activity_ibfk_1` FOREIGN KEY (`patient_id`) REFERENCES `etl_patient_demographics` (`patient_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `etl_otz_activity` */

/*Table structure for table `etl_otz_enrollment` */

DROP TABLE IF EXISTS `etl_otz_enrollment`;

CREATE TABLE `etl_otz_enrollment` (
  `uuid` char(38) DEFAULT NULL,
  `encounter_id` int(11) NOT NULL,
  `patient_id` int(11) NOT NULL,
  `location_id` int(11) DEFAULT NULL,
  `visit_date` date DEFAULT NULL,
  `encounter_provider` int(11) DEFAULT NULL,
  `date_created` date DEFAULT NULL,
  `orientation` varchar(11) DEFAULT NULL,
  `leadership` varchar(11) DEFAULT NULL,
  `participation` varchar(11) DEFAULT NULL,
  `treatment_literacy` varchar(11) DEFAULT NULL,
  `transition_to_adult_care` varchar(11) DEFAULT NULL,
  `making_decision_future` varchar(11) DEFAULT NULL,
  `srh` varchar(11) DEFAULT NULL,
  `beyond_third_ninety` varchar(11) DEFAULT NULL,
  `transfer_in` varchar(11) DEFAULT NULL,
  `voided` int(11) DEFAULT NULL,
  PRIMARY KEY (`encounter_id`),
  UNIQUE KEY `unique_uuid` (`uuid`),
  KEY `visit_date` (`visit_date`),
  KEY `encounter_id` (`encounter_id`),
  KEY `patient_id` (`patient_id`),
  KEY `patient_id_2` (`patient_id`,`visit_date`),
  CONSTRAINT `etl_otz_enrollment_ibfk_1` FOREIGN KEY (`patient_id`) REFERENCES `etl_patient_demographics` (`patient_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `etl_otz_enrollment` */

/*Table structure for table `etl_ovc_enrolment` */

DROP TABLE IF EXISTS `etl_ovc_enrolment`;

CREATE TABLE `etl_ovc_enrolment` (
  `uuid` char(38) DEFAULT NULL,
  `encounter_id` int(11) NOT NULL,
  `patient_id` int(11) NOT NULL,
  `location_id` int(11) DEFAULT NULL,
  `visit_date` date DEFAULT NULL,
  `encounter_provider` int(11) DEFAULT NULL,
  `date_created` date DEFAULT NULL,
  `caregiver_enrolled_here` varchar(11) DEFAULT NULL,
  `caregiver_name` varchar(11) DEFAULT NULL,
  `caregiver_gender` varchar(255) DEFAULT NULL,
  `relationship_to_client` varchar(255) DEFAULT NULL,
  `caregiver_phone_number` varchar(255) DEFAULT NULL,
  `client_enrolled_cpims` varchar(11) DEFAULT NULL,
  `partner_offering_ovc` varchar(255) DEFAULT NULL,
  `voided` int(11) DEFAULT NULL,
  PRIMARY KEY (`encounter_id`),
  UNIQUE KEY `unique_uuid` (`uuid`),
  KEY `visit_date` (`visit_date`),
  KEY `encounter_id` (`encounter_id`),
  KEY `patient_id` (`patient_id`),
  KEY `patient_id_2` (`patient_id`,`visit_date`),
  CONSTRAINT `etl_ovc_enrolment_ibfk_1` FOREIGN KEY (`patient_id`) REFERENCES `etl_patient_demographics` (`patient_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `etl_ovc_enrolment` */

/*Table structure for table `etl_patient_contact` */

DROP TABLE IF EXISTS `etl_patient_contact`;

CREATE TABLE `etl_patient_contact` (
  `id` int(11) DEFAULT NULL,
  `uuid` char(38) DEFAULT NULL,
  `date_created` date DEFAULT NULL,
  `first_name` varchar(255) DEFAULT NULL,
  `middle_name` varchar(255) DEFAULT NULL,
  `last_name` varchar(255) DEFAULT NULL,
  `sex` varchar(50) DEFAULT NULL,
  `birth_date` datetime DEFAULT NULL,
  `physical_address` varchar(255) DEFAULT NULL,
  `phone_contact` varchar(255) DEFAULT NULL,
  `patient_related_to` int(11) DEFAULT NULL,
  `patient_id` int(11) DEFAULT NULL,
  `relationship_type` int(11) DEFAULT NULL,
  `appointment_date` datetime DEFAULT NULL,
  `baseline_hiv_status` varchar(255) DEFAULT NULL,
  `ipv_outcome` varchar(255) DEFAULT NULL,
  `marital_status` varchar(100) DEFAULT NULL,
  `living_with_patient` varchar(100) DEFAULT NULL,
  `pns_approach` varchar(100) DEFAULT NULL,
  `contact_listing_decline_reason` varchar(255) DEFAULT NULL,
  `consented_contact_listing` varchar(100) DEFAULT NULL,
  `voided` int(11) DEFAULT NULL,
  UNIQUE KEY `unique_uuid` (`uuid`),
  KEY `patient_related_to` (`patient_related_to`),
  KEY `date_created` (`date_created`),
  KEY `id` (`id`),
  KEY `id_2` (`id`,`date_created`),
  CONSTRAINT `etl_patient_contact_ibfk_1` FOREIGN KEY (`patient_related_to`) REFERENCES `etl_patient_demographics` (`patient_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `etl_patient_contact` */

/*Table structure for table `etl_patient_demographics` */

DROP TABLE IF EXISTS `etl_patient_demographics`;

CREATE TABLE `etl_patient_demographics` (
  `patient_id` int(11) NOT NULL,
  `given_name` varchar(255) DEFAULT NULL,
  `middle_name` varchar(255) DEFAULT NULL,
  `family_name` varchar(255) DEFAULT NULL,
  `Gender` varchar(10) DEFAULT NULL,
  `DOB` date DEFAULT NULL,
  `national_id_no` varchar(50) DEFAULT NULL,
  `unique_patient_no` varchar(50) DEFAULT NULL,
  `patient_clinic_number` varchar(15) DEFAULT NULL,
  `Tb_no` varchar(50) DEFAULT NULL,
  `district_reg_no` varchar(50) DEFAULT NULL,
  `hei_no` varchar(50) DEFAULT NULL,
  `phone_number` varchar(50) DEFAULT NULL,
  `birth_place` varchar(50) DEFAULT NULL,
  `citizenship` varchar(50) DEFAULT NULL,
  `email_address` varchar(100) DEFAULT NULL,
  `next_of_kin` varchar(255) DEFAULT NULL,
  `next_of_kin_phone` varchar(100) DEFAULT NULL,
  `next_of_kin_relationship` varchar(100) DEFAULT NULL,
  `marital_status` varchar(50) DEFAULT NULL,
  `education_level` varchar(50) DEFAULT NULL,
  `dead` int(11) DEFAULT NULL,
  `death_date` date DEFAULT NULL,
  `voided` int(11) DEFAULT NULL,
  PRIMARY KEY (`patient_id`),
  KEY `patient_id` (`patient_id`),
  KEY `Gender` (`Gender`),
  KEY `unique_patient_no` (`unique_patient_no`),
  KEY `DOB` (`DOB`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `etl_patient_demographics` */

insert  into `etl_patient_demographics`(`patient_id`,`given_name`,`middle_name`,`family_name`,`Gender`,`DOB`,`national_id_no`,`unique_patient_no`,`patient_clinic_number`,`Tb_no`,`district_reg_no`,`hei_no`,`phone_number`,`birth_place`,`citizenship`,`email_address`,`next_of_kin`,`next_of_kin_phone`,`next_of_kin_relationship`,`marital_status`,`education_level`,`dead`,`death_date`,`voided`) values (1,'Super','','User','M',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,0),(2,'Unknown',NULL,'Provider','F',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,0),(3,'manager',NULL,'upgrade','F',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'0788111111',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,0),(4,'John',NULL,'Doe','M','1978-01-01','1615700003',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Never married','None',0,NULL,0),(5,'Doe',NULL,'Jane','F','1988-06-15',NULL,NULL,'139390001',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Never married','College/university/polytechnic',0,NULL,0),(6,'Nagwalla','Simiyu','Sam','M','1997-06-15',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Never married','Primary school education',0,NULL,0),(7,'Mdoe','Juma','Swaleh','M','1968-06-15',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Never married','None',0,NULL,0),(8,'Jones','Kuloba','jermaine','M','1995-06-15',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Widowed','None',0,NULL,0),(9,'Bellingham','Majiwa','Jude','M','1998-06-15',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Never married','None',0,NULL,0),(10,'James','Kamande','Njuguna','M','1998-06-15',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Never married','Secondary school education',0,NULL,0),(11,'Rashid','Majid','Abdalla','M','1990-06-15','23415665',NULL,'1615700003',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Married','College/university/polytechnic',0,NULL,0),(12,'Dean','Smith','Robert','M','1968-06-15',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Never married','College/university/polytechnic',0,NULL,0),(13,'Emmanuel','Musee','Juma','M','1979-06-15','12364758',NULL,'1615700005',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,0),(14,'Victor','Agape','Ven','M','1975-06-15',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,0),(15,'Kagwe','Waziri','Mutahi','M','1986-06-15',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Widowed','Primary school education',0,NULL,0),(16,'Ross','Oju','Dianah','F','1955-06-15','25647890',NULL,'1615700006',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Never married','None',0,NULL,0),(17,'Frank','Mureithi','Njenga','M','1962-06-15','23452667',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Married','College/university/polytechnic',0,NULL,0),(18,'Nelson',NULL,'Mandela','M','1990-04-01',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,0),(19,'Wanyama',NULL,'Kelvin','M','1992-07-02',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,0),(20,'Janeth','Mwanziah','Nyokabi','F','1985-06-15',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Married','Primary school education',0,NULL,0),(21,'Lucas','Sossi','Radede','M','1978-01-02','23516326',NULL,'1615700008',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Married','Primary school education',0,NULL,0),(22,'Mberia','Makobu','Jones','M','1998-03-11',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Married','Secondary school education',0,NULL,0),(23,'Jones','Makovu','Mberia','M','1997-02-06',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Married','Primary school education',0,NULL,0),(24,'James','Kimani','Mworia','M','1979-07-01',NULL,NULL,'1615700010',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Married','Secondary school education',0,NULL,0),(25,'Jane',NULL,'Komu','F','1994-07-13',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,0),(26,'James',NULL,'Beglin','M','1987-06-01',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,0),(27,'Jairus',NULL,'Kambua','M','1997-07-01',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,0),(28,'John',NULL,'Gicheru','M','1990-07-01',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,0),(29,'Benjamin',NULL,'Mkapa','M','1999-10-02','1615700015',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,0);

/*Table structure for table `etl_patient_hiv_followup` */

DROP TABLE IF EXISTS `etl_patient_hiv_followup`;

CREATE TABLE `etl_patient_hiv_followup` (
  `uuid` char(38) DEFAULT NULL,
  `encounter_id` int(11) NOT NULL,
  `patient_id` int(11) NOT NULL,
  `location_id` int(11) DEFAULT NULL,
  `visit_date` date DEFAULT NULL,
  `visit_id` int(11) DEFAULT NULL,
  `encounter_provider` int(11) DEFAULT NULL,
  `date_created` date DEFAULT NULL,
  `visit_scheduled` int(11) DEFAULT NULL,
  `person_present` int(11) DEFAULT NULL,
  `weight` double DEFAULT NULL,
  `systolic_pressure` double DEFAULT NULL,
  `diastolic_pressure` double DEFAULT NULL,
  `height` double DEFAULT NULL,
  `temperature` double DEFAULT NULL,
  `pulse_rate` double DEFAULT NULL,
  `respiratory_rate` double DEFAULT NULL,
  `oxygen_saturation` double DEFAULT NULL,
  `muac` double DEFAULT NULL,
  `nutritional_status` int(11) DEFAULT NULL,
  `population_type` int(11) DEFAULT NULL,
  `key_population_type` int(11) DEFAULT NULL,
  `who_stage` int(11) DEFAULT NULL,
  `presenting_complaints` int(11) DEFAULT NULL,
  `clinical_notes` varchar(600) DEFAULT NULL,
  `on_anti_tb_drugs` int(11) DEFAULT NULL,
  `on_ipt` int(11) DEFAULT NULL,
  `ever_on_ipt` int(11) DEFAULT NULL,
  `spatum_smear_ordered` int(11) DEFAULT NULL,
  `chest_xray_ordered` int(11) DEFAULT NULL,
  `genexpert_ordered` int(11) DEFAULT NULL,
  `spatum_smear_result` int(11) DEFAULT NULL,
  `chest_xray_result` int(11) DEFAULT NULL,
  `genexpert_result` int(11) DEFAULT NULL,
  `referral` int(11) DEFAULT NULL,
  `clinical_tb_diagnosis` int(11) DEFAULT NULL,
  `contact_invitation` int(11) DEFAULT NULL,
  `evaluated_for_ipt` int(11) DEFAULT NULL,
  `has_known_allergies` int(11) DEFAULT NULL,
  `has_chronic_illnesses_cormobidities` int(11) DEFAULT NULL,
  `has_adverse_drug_reaction` int(11) DEFAULT NULL,
  `substitution_first_line_regimen_date` date DEFAULT NULL,
  `substitution_first_line_regimen_reason` int(11) DEFAULT NULL,
  `substitution_second_line_regimen_date` date DEFAULT NULL,
  `substitution_second_line_regimen_reason` int(11) DEFAULT NULL,
  `second_line_regimen_change_date` date DEFAULT NULL,
  `second_line_regimen_change_reason` int(11) DEFAULT NULL,
  `pregnancy_status` int(11) DEFAULT NULL,
  `wants_pregnancy` int(11) DEFAULT NULL,
  `pregnancy_outcome` int(11) DEFAULT NULL,
  `anc_number` varchar(50) DEFAULT NULL,
  `expected_delivery_date` date DEFAULT NULL,
  `last_menstrual_period` date DEFAULT NULL,
  `gravida` int(11) DEFAULT NULL,
  `parity` int(11) DEFAULT NULL,
  `full_term_pregnancies` int(11) DEFAULT NULL,
  `abortion_miscarriages` int(11) DEFAULT NULL,
  `family_planning_status` int(11) DEFAULT NULL,
  `family_planning_method` int(11) DEFAULT NULL,
  `reason_not_using_family_planning` int(11) DEFAULT NULL,
  `tb_status` int(11) DEFAULT NULL,
  `tb_treatment_no` varchar(50) DEFAULT NULL,
  `ctx_adherence` int(11) DEFAULT NULL,
  `ctx_dispensed` int(11) DEFAULT NULL,
  `dapsone_adherence` int(11) DEFAULT NULL,
  `dapsone_dispensed` int(11) DEFAULT NULL,
  `inh_dispensed` int(11) DEFAULT NULL,
  `arv_adherence` int(11) DEFAULT NULL,
  `poor_arv_adherence_reason` int(11) DEFAULT NULL,
  `poor_arv_adherence_reason_other` varchar(200) DEFAULT NULL,
  `pwp_disclosure` int(11) DEFAULT NULL,
  `pwp_partner_tested` int(11) DEFAULT NULL,
  `condom_provided` int(11) DEFAULT NULL,
  `screened_for_sti` int(11) DEFAULT NULL,
  `cacx_screening` int(11) DEFAULT NULL,
  `sti_partner_notification` int(11) DEFAULT NULL,
  `at_risk_population` int(11) DEFAULT NULL,
  `system_review_finding` int(11) DEFAULT NULL,
  `next_appointment_date` date DEFAULT NULL,
  `next_appointment_reason` int(11) DEFAULT NULL,
  `stability` int(11) DEFAULT NULL,
  `differentiated_care` int(11) DEFAULT NULL,
  `voided` int(11) DEFAULT NULL,
  PRIMARY KEY (`encounter_id`),
  UNIQUE KEY `unique_uuid` (`uuid`),
  KEY `visit_date` (`visit_date`),
  KEY `encounter_id` (`encounter_id`),
  KEY `patient_id` (`patient_id`),
  KEY `patient_id_2` (`patient_id`,`visit_date`),
  KEY `who_stage` (`who_stage`),
  KEY `pregnancy_status` (`pregnancy_status`),
  KEY `pregnancy_outcome` (`pregnancy_outcome`),
  KEY `family_planning_status` (`family_planning_status`),
  KEY `family_planning_method` (`family_planning_method`),
  KEY `tb_status` (`tb_status`),
  KEY `condom_provided` (`condom_provided`),
  KEY `ctx_dispensed` (`ctx_dispensed`),
  KEY `inh_dispensed` (`inh_dispensed`),
  KEY `at_risk_population` (`at_risk_population`),
  KEY `population_type` (`population_type`),
  KEY `key_population_type` (`key_population_type`),
  KEY `on_anti_tb_drugs` (`on_anti_tb_drugs`),
  KEY `on_ipt` (`on_ipt`),
  KEY `ever_on_ipt` (`ever_on_ipt`),
  KEY `differentiated_care` (`differentiated_care`),
  KEY `visit_date_2` (`visit_date`,`patient_id`),
  KEY `visit_date_3` (`visit_date`,`condom_provided`),
  KEY `visit_date_4` (`visit_date`,`family_planning_method`),
  CONSTRAINT `etl_patient_hiv_followup_ibfk_1` FOREIGN KEY (`patient_id`) REFERENCES `etl_patient_demographics` (`patient_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `etl_patient_hiv_followup` */

/*Table structure for table `etl_patient_program` */

DROP TABLE IF EXISTS `etl_patient_program`;

CREATE TABLE `etl_patient_program` (
  `uuid` char(38) NOT NULL,
  `patient_id` int(11) NOT NULL,
  `location_id` int(11) DEFAULT NULL,
  `program` varchar(100) NOT NULL,
  `date_enrolled` date NOT NULL,
  `date_completed` date DEFAULT NULL,
  `outcome` int(11) DEFAULT NULL,
  `date_created` date DEFAULT NULL,
  `voided` int(11) DEFAULT NULL,
  PRIMARY KEY (`uuid`),
  UNIQUE KEY `unique_uuid` (`uuid`),
  KEY `date_enrolled` (`date_enrolled`),
  KEY `date_completed` (`date_completed`),
  KEY `patient_id` (`patient_id`),
  KEY `outcome` (`outcome`),
  CONSTRAINT `etl_patient_program_ibfk_1` FOREIGN KEY (`patient_id`) REFERENCES `etl_patient_demographics` (`patient_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `etl_patient_program` */

/*Table structure for table `etl_patient_program_discontinuation` */

DROP TABLE IF EXISTS `etl_patient_program_discontinuation`;

CREATE TABLE `etl_patient_program_discontinuation` (
  `uuid` char(38) DEFAULT NULL,
  `patient_id` int(11) NOT NULL,
  `visit_id` int(11) DEFAULT NULL,
  `visit_date` datetime DEFAULT NULL,
  `location_id` int(11) DEFAULT NULL,
  `program_uuid` char(38) DEFAULT NULL,
  `program_name` varchar(50) DEFAULT NULL,
  `encounter_id` int(11) NOT NULL,
  `discontinuation_reason` int(11) DEFAULT NULL,
  `date_died` date DEFAULT NULL,
  `transfer_facility` varchar(100) DEFAULT NULL,
  `transfer_date` date DEFAULT NULL,
  PRIMARY KEY (`encounter_id`),
  UNIQUE KEY `unique_uuid` (`uuid`),
  KEY `visit_date` (`visit_date`),
  KEY `visit_date_2` (`visit_date`,`program_name`,`patient_id`),
  KEY `visit_date_3` (`visit_date`,`patient_id`),
  KEY `encounter_id` (`encounter_id`),
  KEY `patient_id` (`patient_id`),
  KEY `discontinuation_reason` (`discontinuation_reason`),
  KEY `date_died` (`date_died`),
  KEY `transfer_date` (`transfer_date`),
  CONSTRAINT `etl_patient_program_discontinuation_ibfk_1` FOREIGN KEY (`patient_id`) REFERENCES `etl_patient_demographics` (`patient_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `etl_patient_program_discontinuation` */

/*Table structure for table `etl_patient_triage` */

DROP TABLE IF EXISTS `etl_patient_triage`;

CREATE TABLE `etl_patient_triage` (
  `uuid` char(38) DEFAULT NULL,
  `encounter_id` int(11) NOT NULL,
  `patient_id` int(11) NOT NULL,
  `location_id` int(11) DEFAULT NULL,
  `visit_date` date DEFAULT NULL,
  `visit_id` int(11) DEFAULT NULL,
  `encounter_provider` int(11) DEFAULT NULL,
  `date_created` date DEFAULT NULL,
  `visit_reason` varchar(255) DEFAULT NULL,
  `weight` double DEFAULT NULL,
  `height` double DEFAULT NULL,
  `systolic_pressure` double DEFAULT NULL,
  `diastolic_pressure` double DEFAULT NULL,
  `temperature` double DEFAULT NULL,
  `pulse_rate` double DEFAULT NULL,
  `respiratory_rate` double DEFAULT NULL,
  `oxygen_saturation` double DEFAULT NULL,
  `muac` double DEFAULT NULL,
  `nutritional_status` int(11) DEFAULT NULL,
  `last_menstrual_period` date DEFAULT NULL,
  `voided` int(11) DEFAULT NULL,
  PRIMARY KEY (`encounter_id`),
  UNIQUE KEY `unique_uuid` (`uuid`),
  KEY `visit_date` (`visit_date`),
  KEY `encounter_id` (`encounter_id`),
  KEY `patient_id` (`patient_id`),
  KEY `patient_id_2` (`patient_id`,`visit_date`),
  CONSTRAINT `etl_patient_triage_ibfk_1` FOREIGN KEY (`patient_id`) REFERENCES `etl_patient_demographics` (`patient_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `etl_patient_triage` */

/*Table structure for table `etl_patients_booked_today` */

DROP TABLE IF EXISTS `etl_patients_booked_today`;

CREATE TABLE `etl_patients_booked_today` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `patient_id` int(11) NOT NULL,
  `last_visit_date` date DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `patient_id` (`patient_id`),
  CONSTRAINT `etl_patients_booked_today_ibfk_1` FOREIGN KEY (`patient_id`) REFERENCES `etl_patient_demographics` (`patient_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `etl_patients_booked_today` */

/*Table structure for table `etl_person_address` */

DROP TABLE IF EXISTS `etl_person_address`;

CREATE TABLE `etl_person_address` (
  `uuid` char(38) NOT NULL,
  `patient_id` int(11) NOT NULL,
  `county` varchar(100) DEFAULT NULL,
  `sub_county` varchar(100) DEFAULT NULL,
  `location` varchar(100) DEFAULT NULL,
  `ward` varchar(100) DEFAULT NULL,
  `sub_location` varchar(100) DEFAULT NULL,
  `village` varchar(100) DEFAULT NULL,
  `postal_address` varchar(100) DEFAULT NULL,
  `land_mark` varchar(100) DEFAULT NULL,
  `voided` int(11) DEFAULT NULL,
  PRIMARY KEY (`uuid`),
  UNIQUE KEY `unique_uuid` (`uuid`),
  KEY `patient_id` (`patient_id`),
  CONSTRAINT `etl_person_address_ibfk_1` FOREIGN KEY (`patient_id`) REFERENCES `etl_patient_demographics` (`patient_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `etl_person_address` */

insert  into `etl_person_address`(`uuid`,`patient_id`,`county`,`sub_county`,`location`,`ward`,`sub_location`,`village`,`postal_address`,`land_mark`,`voided`) values ('0435f295-0bad-4526-8a7f-f48e15be05a1',18,NULL,'Dagoretti',NULL,NULL,NULL,NULL,NULL,'Dagoretti Health Centre',0),('054583d9-3292-4125-8996-40a4c9039ed7',11,'Kilifi','Malindi',NULL,'Msambweni',NULL,NULL,NULL,NULL,0),('0dcec2a0-356a-4239-95b7-44bd40afef16',29,NULL,'Kilifi North',NULL,NULL,NULL,NULL,NULL,'Kilif CRH',0),('1bfaa20e-11f0-4eba-9881-95d18d51b405',6,'Nyandarua','Kinangop',NULL,NULL,NULL,NULL,NULL,NULL,0),('48b95536-563a-4a3d-a1fd-623653becf2e',13,'Nairobi','Kibra','Soweto','Mugumoini',NULL,NULL,NULL,NULL,0),('68b66d74-106e-4f8c-b585-b12112b96a2c',5,'Nairobi','Makadara',NULL,'Makongeni',NULL,'Unknown',NULL,'Landi Mawe',0),('6dda8866-8862-4fd2-9843-a64e74572a21',28,NULL,'Ruaka',NULL,NULL,NULL,NULL,NULL,'Kiambi SCH',0),('73fd76ee-4bc4-48d6-ac3f-9c8d6fde7259',15,'Nairobi','Embakasi','Mihango','Embakasi East',NULL,NULL,NULL,NULL,0),('7b0fb3ec-2ba3-4651-904f-dfa3186c7efb',17,'Kisumu','Kisumu East','Konalejo','Kondele',NULL,NULL,NULL,NULL,0),('7bdb7645-e93c-497b-9cc5-3851b4c38cbf',10,'Nairobi','Westlands',NULL,'Kilimani',NULL,NULL,NULL,NULL,0),('894941c1-1861-4667-8c1a-79435cfd6703',21,'Nairobi','Embakasi East','Daraja Mbili','Mihango',NULL,NULL,NULL,'Mihango Dispensary',0),('8c599550-11c2-49e6-a920-1b005ef411c3',22,'Kisumu','Gita','Gita-B','Kibos',NULL,NULL,NULL,'Gita SCH',0),('9758447b-7d0a-4a3e-8c00-7e3404359e6e',24,'Kisumu','Gita','Gita A','Kibos',NULL,NULL,NULL,'Gita SCH',0),('9e12401a-67fd-4531-8502-7e2b46c1f85b',26,NULL,'Westlands',NULL,NULL,NULL,NULL,NULL,'Yaya centre',0),('a4fc6e2e-38a6-4c03-ae42-14e203bdf605',20,'Busia','Matayos','Central','Central',NULL,NULL,NULL,'BCRH',0),('a7823e72-1724-459e-9284-e1d392f1fdac',7,'Murang\'a','maragua',NULL,NULL,NULL,NULL,NULL,NULL,0),('b111dd35-aa01-4127-9297-2b5e5ab20398',9,'Nairobi','Westlands',NULL,'Kilimani',NULL,NULL,NULL,NULL,0),('b6c84234-6054-488b-8935-9d8e361a13fa',8,'Migori','Sirare',NULL,NULL,NULL,NULL,NULL,NULL,0),('be9d0396-b7da-4376-93cc-a213910234c3',25,NULL,'Vihiga south',NULL,NULL,NULL,NULL,NULL,'Vihiga',0),('cc1c9f44-f017-4c79-9ee7-072a00b7849a',14,'Nairobi','Embakasi','Mihango','Embakasi East',NULL,NULL,NULL,NULL,0),('d55d3686-2e47-48dd-80b8-3fcb560946bd',19,NULL,'Webuye',NULL,NULL,NULL,'Chebini','177-00100','Chebini Primary School',0),('d67e6e19-d38f-4891-90a5-fd55a0d1dbff',12,'Kisumu','Gita','Kolwa','Kibos',NULL,NULL,NULL,NULL,0),('e28cb179-74f1-45ea-90c8-9958653e3a89',16,'Nairobi','Embakasi','Mihango','Embakasi East',NULL,NULL,NULL,NULL,0),('f2114afd-ed61-438d-ba32-4d7a6fbdf716',27,NULL,'Kamukunji',NULL,NULL,NULL,NULL,NULL,'Inama Market',0),('fcdf9070-4d5f-4469-9081-75789812eae1',23,'Siaya','Ugunja','Uhuyi','Wangotong',NULL,NULL,NULL,NULL,0);

/*Table structure for table `etl_pharmacy_extract` */

DROP TABLE IF EXISTS `etl_pharmacy_extract`;

CREATE TABLE `etl_pharmacy_extract` (
  `obs_group_id` int(11) NOT NULL,
  `uuid` char(38) DEFAULT NULL,
  `patient_id` int(11) NOT NULL,
  `location_id` int(11) DEFAULT NULL,
  `visit_date` date DEFAULT NULL,
  `visit_id` int(11) DEFAULT NULL,
  `encounter_id` int(11) DEFAULT NULL,
  `encounter_name` varchar(100) DEFAULT NULL,
  `drug` int(11) DEFAULT NULL,
  `is_arv` int(11) DEFAULT NULL,
  `is_ctx` int(11) DEFAULT NULL,
  `is_dapsone` int(11) DEFAULT NULL,
  `drug_name` varchar(255) DEFAULT NULL,
  `dose` int(11) DEFAULT NULL,
  `unit` int(11) DEFAULT NULL,
  `frequency` int(11) DEFAULT NULL,
  `duration` int(11) DEFAULT NULL,
  `duration_units` varchar(20) DEFAULT NULL,
  `duration_in_days` int(11) DEFAULT NULL,
  `prescription_provider` varchar(50) DEFAULT NULL,
  `dispensing_provider` varchar(50) DEFAULT NULL,
  `regimen` mediumtext,
  `adverse_effects` varchar(100) DEFAULT NULL,
  `date_of_refill` date DEFAULT NULL,
  `date_created` date DEFAULT NULL,
  `voided` int(11) DEFAULT NULL,
  `date_voided` date DEFAULT NULL,
  PRIMARY KEY (`obs_group_id`),
  UNIQUE KEY `unique_uuid` (`uuid`),
  KEY `visit_date` (`visit_date`),
  KEY `encounter_id` (`encounter_id`),
  KEY `patient_id` (`patient_id`),
  KEY `drug` (`drug`),
  KEY `is_arv` (`is_arv`),
  CONSTRAINT `etl_pharmacy_extract_ibfk_1` FOREIGN KEY (`patient_id`) REFERENCES `etl_patient_demographics` (`patient_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `etl_pharmacy_extract` */

/*Table structure for table `etl_prep_behaviour_risk_assessment` */

DROP TABLE IF EXISTS `etl_prep_behaviour_risk_assessment`;

CREATE TABLE `etl_prep_behaviour_risk_assessment` (
  `uuid` char(38) DEFAULT NULL,
  `provider` int(11) DEFAULT NULL,
  `patient_id` int(11) NOT NULL,
  `visit_id` int(11) DEFAULT NULL,
  `visit_date` date DEFAULT NULL,
  `location_id` int(11) DEFAULT NULL,
  `encounter_id` int(11) NOT NULL,
  `date_created` date DEFAULT NULL,
  `sexual_partner_hiv_status` varchar(255) DEFAULT NULL,
  `sexual_partner_on_art` varchar(10) DEFAULT NULL,
  `risk` varchar(255) DEFAULT NULL,
  `high_risk_partner` varchar(10) DEFAULT NULL,
  `sex_with_multiple_partners` varchar(10) DEFAULT NULL,
  `ipv_gbv` varchar(10) DEFAULT NULL,
  `transactional_sex` varchar(10) DEFAULT NULL,
  `recent_sti_infected` varchar(10) DEFAULT NULL,
  `recurrent_pep_use` varchar(10) DEFAULT NULL,
  `recurrent_sex_under_influence` varchar(10) DEFAULT NULL,
  `inconsistent_no_condom_use` varchar(10) DEFAULT NULL,
  `sharing_drug_needles` varchar(255) DEFAULT NULL,
  `assessment_outcome` varchar(255) DEFAULT NULL,
  `risk_education_offered` varchar(10) DEFAULT NULL,
  `risk_reduction` varchar(10) DEFAULT NULL,
  `willing_to_take_prep` varchar(10) DEFAULT NULL,
  `reason_not_willing` varchar(255) DEFAULT NULL,
  `risk_edu_offered` varchar(10) DEFAULT NULL,
  `risk_education` varchar(255) DEFAULT NULL,
  `referral_for_prevention_services` varchar(255) DEFAULT NULL,
  `referral_facility` varchar(255) DEFAULT NULL,
  `time_partner_hiv_positive_known` varchar(255) DEFAULT NULL,
  `partner_enrolled_ccc` varchar(255) DEFAULT NULL,
  `partner_ccc_number` varchar(255) DEFAULT NULL,
  `partner_art_start_date` date DEFAULT NULL,
  `serodiscordant_confirmation_date` date DEFAULT NULL,
  `recent_unprotected_sex_with_positive_partner` varchar(10) DEFAULT NULL,
  `children_with_hiv_positive_partner` varchar(255) DEFAULT NULL,
  `voided` int(11) DEFAULT NULL,
  PRIMARY KEY (`encounter_id`),
  UNIQUE KEY `unique_uuid` (`uuid`),
  KEY `patient_id` (`patient_id`),
  KEY `visit_date` (`visit_date`),
  KEY `encounter_id` (`encounter_id`),
  CONSTRAINT `etl_prep_behaviour_risk_assessment_ibfk_1` FOREIGN KEY (`patient_id`) REFERENCES `etl_patient_demographics` (`patient_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `etl_prep_behaviour_risk_assessment` */

/*Table structure for table `etl_prep_discontinuation` */

DROP TABLE IF EXISTS `etl_prep_discontinuation`;

CREATE TABLE `etl_prep_discontinuation` (
  `uuid` char(38) DEFAULT NULL,
  `provider` int(11) DEFAULT NULL,
  `patient_id` int(11) NOT NULL,
  `visit_id` int(11) DEFAULT NULL,
  `visit_date` date DEFAULT NULL,
  `location_id` int(11) DEFAULT NULL,
  `encounter_id` int(11) NOT NULL,
  `date_created` date DEFAULT NULL,
  `discontinue_reason` varchar(255) DEFAULT NULL,
  `care_end_date` date DEFAULT NULL,
  `voided` int(11) DEFAULT NULL,
  PRIMARY KEY (`encounter_id`),
  UNIQUE KEY `unique_uuid` (`uuid`),
  KEY `patient_id` (`patient_id`),
  KEY `visit_date` (`visit_date`),
  KEY `encounter_id` (`encounter_id`),
  KEY `discontinue_reason` (`discontinue_reason`),
  KEY `care_end_date` (`care_end_date`),
  CONSTRAINT `etl_prep_discontinuation_ibfk_1` FOREIGN KEY (`patient_id`) REFERENCES `etl_patient_demographics` (`patient_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `etl_prep_discontinuation` */

/*Table structure for table `etl_prep_enrolment` */

DROP TABLE IF EXISTS `etl_prep_enrolment`;

CREATE TABLE `etl_prep_enrolment` (
  `uuid` char(38) DEFAULT NULL,
  `provider` int(11) DEFAULT NULL,
  `patient_id` int(11) NOT NULL,
  `visit_id` int(11) DEFAULT NULL,
  `visit_date` date DEFAULT NULL,
  `location_id` int(11) DEFAULT NULL,
  `encounter_id` int(11) NOT NULL,
  `date_created` date DEFAULT NULL,
  `patient_type` varchar(255) DEFAULT NULL,
  `transfer_in_entry_point` varchar(255) DEFAULT NULL,
  `referred_from` varchar(255) DEFAULT NULL,
  `transit_from` varchar(255) DEFAULT NULL,
  `transfer_in_date` date DEFAULT NULL,
  `transfer_from` varchar(255) DEFAULT NULL,
  `initial_enrolment_date` date DEFAULT NULL,
  `date_started_prep_trf_facility` date DEFAULT NULL,
  `previously_on_prep` varchar(10) DEFAULT NULL,
  `regimen` varchar(255) DEFAULT NULL,
  `prep_last_date` date DEFAULT NULL,
  `in_school` varchar(10) DEFAULT NULL,
  `buddy_name` varchar(255) DEFAULT NULL,
  `buddy_alias` varchar(255) DEFAULT NULL,
  `buddy_relationship` varchar(255) DEFAULT NULL,
  `buddy_phone` varchar(255) DEFAULT NULL,
  `buddy_alt_phone` varchar(255) DEFAULT NULL,
  `voided` int(11) DEFAULT NULL,
  PRIMARY KEY (`encounter_id`),
  UNIQUE KEY `unique_uuid` (`uuid`),
  KEY `patient_id` (`patient_id`),
  KEY `visit_date` (`visit_date`),
  KEY `encounter_id` (`encounter_id`),
  CONSTRAINT `etl_prep_enrolment_ibfk_1` FOREIGN KEY (`patient_id`) REFERENCES `etl_patient_demographics` (`patient_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `etl_prep_enrolment` */

/*Table structure for table `etl_prep_followup` */

DROP TABLE IF EXISTS `etl_prep_followup`;

CREATE TABLE `etl_prep_followup` (
  `uuid` char(38) DEFAULT NULL,
  `provider` int(11) DEFAULT NULL,
  `patient_id` int(11) NOT NULL,
  `visit_id` int(11) DEFAULT NULL,
  `visit_date` date DEFAULT NULL,
  `location_id` int(11) DEFAULT NULL,
  `encounter_id` int(11) NOT NULL,
  `date_created` date DEFAULT NULL,
  `sti_screened` varchar(10) DEFAULT NULL,
  `genital_ulcer_desease` varchar(255) DEFAULT NULL,
  `vaginal_discharge` varchar(255) DEFAULT NULL,
  `cervical_discharge` varchar(255) DEFAULT NULL,
  `pid` varchar(255) DEFAULT NULL,
  `urethral_discharge` varchar(255) DEFAULT NULL,
  `anal_discharge` varchar(255) DEFAULT NULL,
  `other_sti_symptoms` varchar(255) DEFAULT NULL,
  `sti_treated` varchar(10) DEFAULT NULL,
  `vmmc_screened` varchar(10) DEFAULT NULL,
  `vmmc_status` varchar(255) DEFAULT NULL,
  `vmmc_referred` varchar(255) DEFAULT NULL,
  `lmp` date DEFAULT NULL,
  `pregnant` varchar(10) DEFAULT NULL,
  `edd` date DEFAULT NULL,
  `planned_pregnancy` varchar(10) DEFAULT NULL,
  `wanted_pregnancy` varchar(10) DEFAULT NULL,
  `breastfeeding` varchar(10) DEFAULT NULL,
  `fp_status` varchar(255) DEFAULT NULL,
  `fp_method` varchar(255) DEFAULT NULL,
  `ended_pregnancy` varchar(255) DEFAULT NULL,
  `pregnancy_outcome` varchar(10) DEFAULT NULL,
  `outcome_date` date DEFAULT NULL,
  `defects` varchar(10) DEFAULT NULL,
  `has_chronic_illness` varchar(10) DEFAULT NULL,
  `chronic_illness` varchar(255) DEFAULT NULL,
  `chronic_illness_onset_date` date DEFAULT NULL,
  `chronic_illness_drug` varchar(255) DEFAULT NULL,
  `chronic_illness_dose` varchar(255) DEFAULT NULL,
  `chronic_illness_units` varchar(255) DEFAULT NULL,
  `chronic_illness_frequency` varchar(255) DEFAULT NULL,
  `chronic_illness_duration` varchar(255) DEFAULT NULL,
  `chronic_illness_duration_units` varchar(255) DEFAULT NULL,
  `adverse_reactions` varchar(255) DEFAULT NULL,
  `medicine_reactions` varchar(255) DEFAULT NULL,
  `reaction` varchar(255) DEFAULT NULL,
  `severity` varchar(255) DEFAULT NULL,
  `action_taken` varchar(255) DEFAULT NULL,
  `known_allergies` varchar(10) DEFAULT NULL,
  `allergen` varchar(255) DEFAULT NULL,
  `allergy_reaction` varchar(255) DEFAULT NULL,
  `allergy_severity` varchar(255) DEFAULT NULL,
  `allergy_date` date DEFAULT NULL,
  `hiv_signs` varchar(10) DEFAULT NULL,
  `adherence_counselled` varchar(10) DEFAULT NULL,
  `prep_contraindicatios` varchar(255) DEFAULT NULL,
  `treatment_plan` varchar(255) DEFAULT NULL,
  `condoms_issued` varchar(10) DEFAULT NULL,
  `number_of_condoms` varchar(10) DEFAULT NULL,
  `appointment_given` varchar(10) DEFAULT NULL,
  `appointment_date` date DEFAULT NULL,
  `reason_no_appointment` varchar(255) DEFAULT NULL,
  `clinical_notes` varchar(255) DEFAULT NULL,
  `voided` int(11) DEFAULT NULL,
  PRIMARY KEY (`encounter_id`),
  UNIQUE KEY `unique_uuid` (`uuid`),
  KEY `patient_id` (`patient_id`),
  KEY `visit_date` (`visit_date`),
  KEY `encounter_id` (`encounter_id`),
  CONSTRAINT `etl_prep_followup_ibfk_1` FOREIGN KEY (`patient_id`) REFERENCES `etl_patient_demographics` (`patient_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `etl_prep_followup` */

/*Table structure for table `etl_prep_monthly_refill` */

DROP TABLE IF EXISTS `etl_prep_monthly_refill`;

CREATE TABLE `etl_prep_monthly_refill` (
  `uuid` char(38) DEFAULT NULL,
  `provider` int(11) DEFAULT NULL,
  `patient_id` int(11) NOT NULL,
  `visit_id` int(11) DEFAULT NULL,
  `visit_date` date DEFAULT NULL,
  `location_id` int(11) DEFAULT NULL,
  `encounter_id` int(11) NOT NULL,
  `date_created` date DEFAULT NULL,
  `risk_for_hiv_positive_partner` varchar(255) DEFAULT NULL,
  `client_assessment` varchar(255) DEFAULT NULL,
  `adherence_assessment` varchar(255) DEFAULT NULL,
  `poor_adherence_reasons` varchar(255) DEFAULT NULL,
  `other_poor_adherence_reasons` varchar(255) DEFAULT NULL,
  `adherence_counselling_done` varchar(10) DEFAULT NULL,
  `prep_status` varchar(255) DEFAULT NULL,
  `prescribed_prep_today` varchar(10) DEFAULT NULL,
  `prescribed_regimen` varchar(10) DEFAULT NULL,
  `prescribed_regimen_months` varchar(10) DEFAULT NULL,
  `prep_discontinue_reasons` varchar(255) DEFAULT NULL,
  `prep_discontinue_other_reasons` varchar(255) DEFAULT NULL,
  `appointment_given` varchar(10) DEFAULT NULL,
  `next_appointment` date DEFAULT NULL,
  `remarks` varchar(255) DEFAULT NULL,
  `voided` int(11) DEFAULT NULL,
  PRIMARY KEY (`encounter_id`),
  UNIQUE KEY `unique_uuid` (`uuid`),
  KEY `patient_id` (`patient_id`),
  KEY `visit_date` (`visit_date`),
  KEY `encounter_id` (`encounter_id`),
  CONSTRAINT `etl_prep_monthly_refill_ibfk_1` FOREIGN KEY (`patient_id`) REFERENCES `etl_patient_demographics` (`patient_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `etl_prep_monthly_refill` */

/*Table structure for table `etl_progress_note` */

DROP TABLE IF EXISTS `etl_progress_note`;

CREATE TABLE `etl_progress_note` (
  `uuid` char(38) DEFAULT NULL,
  `provider` int(11) DEFAULT NULL,
  `patient_id` int(11) NOT NULL,
  `visit_id` int(11) DEFAULT NULL,
  `visit_date` date DEFAULT NULL,
  `location_id` int(11) DEFAULT NULL,
  `encounter_id` int(11) NOT NULL,
  `date_created` date DEFAULT NULL,
  `notes` varchar(255) DEFAULT NULL,
  `voided` int(11) DEFAULT NULL,
  PRIMARY KEY (`encounter_id`),
  UNIQUE KEY `unique_uuid` (`uuid`),
  KEY `patient_id` (`patient_id`),
  KEY `visit_date` (`visit_date`),
  KEY `encounter_id` (`encounter_id`),
  CONSTRAINT `etl_progress_note_ibfk_1` FOREIGN KEY (`patient_id`) REFERENCES `etl_patient_demographics` (`patient_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `etl_progress_note` */

/*Table structure for table `etl_script_status` */

DROP TABLE IF EXISTS `etl_script_status`;

CREATE TABLE `etl_script_status` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `script_name` varchar(50) DEFAULT NULL,
  `start_time` datetime DEFAULT NULL,
  `stop_time` datetime DEFAULT NULL,
  `error` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

/*Data for the table `etl_script_status` */

insert  into `etl_script_status`(`id`,`script_name`,`start_time`,`stop_time`,`error`) values (1,'initial_creation_of_tables','2020-07-28 01:49:40','2020-07-28 01:49:43',NULL),(2,'initial_population_of_tables','2020-07-28 01:49:43','2020-07-28 01:49:44',NULL),(3,'KenyaEMR_Data_Tool','2020-07-28 01:49:44','2020-07-28 01:49:49',NULL);

/*Table structure for table `etl_tb_enrollment` */

DROP TABLE IF EXISTS `etl_tb_enrollment`;

CREATE TABLE `etl_tb_enrollment` (
  `uuid` char(38) DEFAULT NULL,
  `patient_id` int(11) NOT NULL,
  `visit_id` int(11) DEFAULT NULL,
  `visit_date` date DEFAULT NULL,
  `location_id` int(11) DEFAULT NULL,
  `encounter_id` int(11) NOT NULL,
  `provider` int(11) DEFAULT NULL,
  `date_treatment_started` date DEFAULT NULL,
  `district` varchar(50) DEFAULT NULL,
  `district_registration_number` varchar(20) DEFAULT NULL,
  `referred_by` int(11) DEFAULT NULL,
  `referral_date` date DEFAULT NULL,
  `date_transferred_in` date DEFAULT NULL,
  `facility_transferred_from` varchar(100) DEFAULT NULL,
  `district_transferred_from` varchar(100) DEFAULT NULL,
  `date_first_enrolled_in_tb_care` date DEFAULT NULL,
  `weight` double DEFAULT NULL,
  `height` double DEFAULT NULL,
  `treatment_supporter` varchar(100) DEFAULT NULL,
  `relation_to_patient` int(11) DEFAULT NULL,
  `treatment_supporter_address` varchar(100) DEFAULT NULL,
  `treatment_supporter_phone_contact` varchar(100) DEFAULT NULL,
  `disease_classification` int(11) DEFAULT NULL,
  `patient_classification` int(11) DEFAULT NULL,
  `pulmonary_smear_result` int(11) DEFAULT NULL,
  `has_extra_pulmonary_pleurial_effusion` int(11) DEFAULT NULL,
  `has_extra_pulmonary_milliary` int(11) DEFAULT NULL,
  `has_extra_pulmonary_lymph_node` int(11) DEFAULT NULL,
  `has_extra_pulmonary_menengitis` int(11) DEFAULT NULL,
  `has_extra_pulmonary_skeleton` int(11) DEFAULT NULL,
  `has_extra_pulmonary_abdominal` int(11) DEFAULT NULL,
  `has_extra_pulmonary_other` varchar(100) DEFAULT NULL,
  `treatment_outcome` int(11) DEFAULT NULL,
  `treatment_outcome_date` date DEFAULT NULL,
  `date_of_discontinuation` datetime DEFAULT NULL,
  `discontinuation_reason` int(11) DEFAULT NULL,
  PRIMARY KEY (`encounter_id`),
  UNIQUE KEY `unique_uuid` (`uuid`),
  KEY `visit_date` (`visit_date`),
  KEY `encounter_id` (`encounter_id`),
  KEY `patient_id` (`patient_id`),
  KEY `disease_classification` (`disease_classification`),
  KEY `patient_classification` (`patient_classification`),
  KEY `pulmonary_smear_result` (`pulmonary_smear_result`),
  KEY `date_first_enrolled_in_tb_care` (`date_first_enrolled_in_tb_care`),
  CONSTRAINT `etl_tb_enrollment_ibfk_1` FOREIGN KEY (`patient_id`) REFERENCES `etl_patient_demographics` (`patient_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `etl_tb_enrollment` */

/*Table structure for table `etl_tb_follow_up_visit` */

DROP TABLE IF EXISTS `etl_tb_follow_up_visit`;

CREATE TABLE `etl_tb_follow_up_visit` (
  `uuid` char(38) DEFAULT NULL,
  `provider` int(11) DEFAULT NULL,
  `patient_id` int(11) NOT NULL,
  `visit_id` int(11) DEFAULT NULL,
  `visit_date` date DEFAULT NULL,
  `location_id` int(11) DEFAULT NULL,
  `encounter_id` int(11) NOT NULL,
  `spatum_test` int(11) DEFAULT NULL,
  `spatum_result` int(11) DEFAULT NULL,
  `result_serial_number` varchar(20) DEFAULT NULL,
  `quantity` double DEFAULT NULL,
  `date_test_done` date DEFAULT NULL,
  `bacterial_colonie_growth` int(11) DEFAULT NULL,
  `number_of_colonies` double DEFAULT NULL,
  `resistant_s` int(11) DEFAULT NULL,
  `resistant_r` int(11) DEFAULT NULL,
  `resistant_inh` int(11) DEFAULT NULL,
  `resistant_e` int(11) DEFAULT NULL,
  `sensitive_s` int(11) DEFAULT NULL,
  `sensitive_r` int(11) DEFAULT NULL,
  `sensitive_inh` int(11) DEFAULT NULL,
  `sensitive_e` int(11) DEFAULT NULL,
  `test_date` date DEFAULT NULL,
  `hiv_status` int(11) DEFAULT NULL,
  `next_appointment_date` date DEFAULT NULL,
  PRIMARY KEY (`encounter_id`),
  UNIQUE KEY `unique_uuid` (`uuid`),
  KEY `visit_date` (`visit_date`),
  KEY `encounter_id` (`encounter_id`),
  KEY `patient_id` (`patient_id`),
  KEY `hiv_status` (`hiv_status`),
  CONSTRAINT `etl_tb_follow_up_visit_ibfk_1` FOREIGN KEY (`patient_id`) REFERENCES `etl_patient_demographics` (`patient_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `etl_tb_follow_up_visit` */

/*Table structure for table `etl_tb_screening` */

DROP TABLE IF EXISTS `etl_tb_screening`;

CREATE TABLE `etl_tb_screening` (
  `uuid` char(38) DEFAULT NULL,
  `provider` int(11) DEFAULT NULL,
  `patient_id` int(11) NOT NULL,
  `visit_id` int(11) DEFAULT NULL,
  `visit_date` date DEFAULT NULL,
  `location_id` int(11) DEFAULT NULL,
  `encounter_id` int(11) NOT NULL,
  `cough_for_2wks_or_more` int(11) DEFAULT NULL,
  `confirmed_tb_contact` int(11) DEFAULT NULL,
  `fever_for_2wks_or_more` int(11) DEFAULT NULL,
  `noticeable_weight_loss` int(11) DEFAULT NULL,
  `night_sweat_for_2wks_or_more` int(11) DEFAULT NULL,
  `resulting_tb_status` int(11) DEFAULT NULL,
  `tb_treatment_start_date` date DEFAULT NULL,
  `notes` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`encounter_id`),
  UNIQUE KEY `unique_uuid` (`uuid`),
  KEY `visit_date` (`visit_date`),
  KEY `encounter_id` (`encounter_id`),
  KEY `patient_id` (`patient_id`),
  KEY `cough_for_2wks_or_more` (`cough_for_2wks_or_more`),
  KEY `confirmed_tb_contact` (`confirmed_tb_contact`),
  KEY `noticeable_weight_loss` (`noticeable_weight_loss`),
  KEY `night_sweat_for_2wks_or_more` (`night_sweat_for_2wks_or_more`),
  KEY `resulting_tb_status` (`resulting_tb_status`),
  CONSTRAINT `etl_tb_screening_ibfk_1` FOREIGN KEY (`patient_id`) REFERENCES `etl_patient_demographics` (`patient_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `etl_tb_screening` */

/*Table structure for table `etl_viral_load` */

DROP TABLE IF EXISTS `etl_viral_load`;

CREATE TABLE `etl_viral_load` (
  `uuid` char(38) DEFAULT NULL,
  `encounter_id` int(11) NOT NULL,
  `patient_id` int(11) NOT NULL,
  `location_id` int(11) DEFAULT NULL,
  `visit_date` date DEFAULT NULL,
  `order_date` date DEFAULT NULL,
  `date_of_result` date DEFAULT NULL,
  `order_reason` varchar(255) DEFAULT NULL,
  `previous_vl_result` varchar(50) DEFAULT NULL,
  `current_vl_result` varchar(50) DEFAULT NULL,
  `previous_vl_date` date DEFAULT NULL,
  `previous_vl_reason` varchar(255) DEFAULT NULL,
  `vl_months_since_hiv_enrollment` int(11) DEFAULT NULL,
  `vl_months_since_otz_enrollment` int(11) DEFAULT NULL,
  `eligibility` varchar(50) DEFAULT NULL,
  `date_created` date DEFAULT NULL,
  `voided` int(11) DEFAULT NULL,
  PRIMARY KEY (`encounter_id`),
  UNIQUE KEY `unique_uuid` (`uuid`),
  KEY `visit_date` (`visit_date`),
  KEY `encounter_id` (`encounter_id`),
  KEY `patient_id` (`patient_id`),
  KEY `patient_id_2` (`patient_id`,`visit_date`),
  CONSTRAINT `etl_viral_load_ibfk_1` FOREIGN KEY (`patient_id`) REFERENCES `etl_patient_demographics` (`patient_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `etl_viral_load` */

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;
