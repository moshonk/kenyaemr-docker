/*
SQLyog Community v11.2 (64 bit)
MySQL - 5.6.45-log : Database - kenyaemr_datatools
*********************************************************************
*/

/*!40101 SET NAMES utf8 */;

/*!40101 SET SQL_MODE=''*/;

/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
/*Table structure for table `art_preparation` */

DROP TABLE IF EXISTS `art_preparation`;

CREATE TABLE `art_preparation` (
  `uuid` char(38) DEFAULT NULL,
  `patient_id` int(11) NOT NULL,
  `visit_id` int(11) DEFAULT NULL,
  `visit_date` date DEFAULT NULL,
  `location_id` int(11) DEFAULT NULL,
  `encounter_id` int(11) NOT NULL,
  `provider` int(11) DEFAULT NULL,
  `understands_hiv_art_benefits` varchar(10) DEFAULT NULL,
  `screened_negative_substance_abuse` varchar(10) DEFAULT NULL,
  `screened_negative_psychiatric_illness` varchar(10) DEFAULT NULL,
  `HIV_status_disclosure` varchar(10) DEFAULT NULL,
  `trained_drug_admin` varchar(10) DEFAULT NULL,
  `caregiver_committed` varchar(10) DEFAULT NULL,
  `adherance_barriers_identified` varchar(10) DEFAULT NULL,
  `caregiver_location_contacts_known` varchar(10) DEFAULT NULL,
  `ready_to_start_art` varchar(10) DEFAULT NULL,
  `identified_drug_time` varchar(10) DEFAULT NULL,
  `treatment_supporter_engaged` varchar(10) DEFAULT NULL,
  `support_grp_meeting_awareness` varchar(10) DEFAULT NULL,
  `enrolled_in_reminder_system` varchar(10) DEFAULT NULL,
  KEY `patient_id` (`patient_id`),
  KEY `visit_date` (`visit_date`),
  KEY `ready_to_start_art` (`ready_to_start_art`),
  CONSTRAINT `art_preparation_ibfk_1` FOREIGN KEY (`patient_id`) REFERENCES `patient_demographics` (`patient_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `art_preparation` */

/*Table structure for table `client_trace` */

DROP TABLE IF EXISTS `client_trace`;

CREATE TABLE `client_trace` (
  `id` int(11) DEFAULT NULL,
  `uuid` char(38) DEFAULT NULL,
  `date_created` date DEFAULT NULL,
  `encounter_date` datetime DEFAULT NULL,
  `client_id` int(11) DEFAULT NULL,
  `contact_type` varchar(255) DEFAULT NULL,
  `status` varchar(255) DEFAULT NULL,
  `unique_patient_no` varchar(255) DEFAULT NULL,
  `facility_linked_to` varchar(255) DEFAULT NULL,
  `health_worker_handed_to` varchar(255) DEFAULT NULL,
  `remarks` varchar(255) DEFAULT NULL,
  `appointment_date` datetime DEFAULT NULL,
  `voided` int(11) DEFAULT NULL,
  KEY `client_id` (`client_id`),
  KEY `date_created` (`date_created`),
  CONSTRAINT `client_trace_ibfk_1` FOREIGN KEY (`client_id`) REFERENCES `patient_contact` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `client_trace` */

/*Table structure for table `current_in_care` */

DROP TABLE IF EXISTS `current_in_care`;

CREATE TABLE `current_in_care` (
  `visit_date` date DEFAULT NULL,
  `patient_id` int(11) NOT NULL,
  `dob` date DEFAULT NULL,
  `Gender` varchar(10) DEFAULT NULL,
  `enroll_date` date DEFAULT NULL,
  `latest_vis_date` date DEFAULT NULL,
  `latest_tca` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `unique_patient_no` varchar(50) DEFAULT NULL,
  `date_discontinued` datetime DEFAULT NULL,
  `disc_patient` int(11),
  `started_on_drugs` int(11),
  KEY `patient_id` (`patient_id`),
  CONSTRAINT `current_in_care_ibfk_1` FOREIGN KEY (`patient_id`) REFERENCES `patient_demographics` (`patient_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `current_in_care` */

/*Table structure for table `default_facility_info` */

DROP TABLE IF EXISTS `default_facility_info`;

CREATE TABLE `default_facility_info` (
  `siteCode` mediumtext CHARACTER SET utf8,
  `FacilityName` varchar(255) CHARACTER SET utf8 DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `default_facility_info` */

insert  into `default_facility_info`(`siteCode`,`FacilityName`) values ('16157','Vihiga District Hosptial');

/*Table structure for table `drug_event` */

DROP TABLE IF EXISTS `drug_event`;

CREATE TABLE `drug_event` (
  `uuid` char(38) NOT NULL,
  `patient_id` int(11) NOT NULL,
  `date_started` date DEFAULT NULL,
  `visit_date` date DEFAULT NULL,
  `provider` int(11) DEFAULT NULL,
  `encounter_id` int(11) NOT NULL,
  `program` varchar(50) DEFAULT NULL,
  `regimen` mediumtext,
  `regimen_name` varchar(100) DEFAULT NULL,
  `regimen_line` varchar(50) DEFAULT NULL,
  `discontinued` int(11) DEFAULT NULL,
  `regimen_discontinued` varchar(255) DEFAULT NULL,
  `date_discontinued` date DEFAULT NULL,
  `reason_discontinued` varchar(40) CHARACTER SET utf8 DEFAULT NULL,
  `reason_discontinued_other` varchar(100) DEFAULT NULL,
  KEY `patient_id` (`patient_id`),
  CONSTRAINT `drug_event_ibfk_1` FOREIGN KEY (`patient_id`) REFERENCES `patient_demographics` (`patient_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `drug_event` */

/*Table structure for table `enhanced_adherence` */

DROP TABLE IF EXISTS `enhanced_adherence`;

CREATE TABLE `enhanced_adherence` (
  `uuid` char(38) DEFAULT NULL,
  `patient_id` int(11) NOT NULL,
  `visit_id` int(11) DEFAULT NULL,
  `visit_date` date DEFAULT NULL,
  `location_id` int(11) DEFAULT NULL,
  `encounter_id` int(11) NOT NULL,
  `provider` int(11) DEFAULT NULL,
  `session_number` int(11) DEFAULT NULL,
  `first_session_date` date DEFAULT NULL,
  `pill_count` int(11) DEFAULT NULL,
  `arv_adherence` varchar(50) DEFAULT NULL,
  `has_vl_results` varchar(10) DEFAULT NULL,
  `vl_results_suppressed` varchar(10) DEFAULT NULL,
  `vl_results_feeling` varchar(255) DEFAULT NULL,
  `cause_of_high_vl` varchar(255) DEFAULT NULL,
  `way_forward` varchar(255) DEFAULT NULL,
  `patient_hiv_knowledge` varchar(255) DEFAULT NULL,
  `patient_drugs_uptake` varchar(255) DEFAULT NULL,
  `patient_drugs_reminder_tools` varchar(255) DEFAULT NULL,
  `patient_drugs_uptake_during_travels` varchar(255) DEFAULT NULL,
  `patient_drugs_side_effects_response` varchar(255) DEFAULT NULL,
  `patient_drugs_uptake_most_difficult_times` varchar(255) DEFAULT NULL,
  `patient_drugs_daily_uptake_feeling` varchar(255) DEFAULT NULL,
  `patient_ambitions` varchar(255) DEFAULT NULL,
  `patient_has_people_to_talk` varchar(10) DEFAULT NULL,
  `patient_enlisting_social_support` varchar(255) DEFAULT NULL,
  `patient_income_sources` varchar(255) DEFAULT NULL,
  `patient_challenges_reaching_clinic` varchar(10) DEFAULT NULL,
  `patient_worried_of_accidental_disclosure` varchar(10) DEFAULT NULL,
  `patient_treated_differently` varchar(10) DEFAULT NULL,
  `stigma_hinders_adherence` varchar(10) DEFAULT NULL,
  `patient_tried_faith_healing` varchar(10) DEFAULT NULL,
  `patient_adherence_improved` varchar(10) DEFAULT NULL,
  `patient_doses_missed` varchar(10) DEFAULT NULL,
  `review_and_barriers_to_adherence` varchar(255) DEFAULT NULL,
  `other_referrals` varchar(10) DEFAULT NULL,
  `appointments_honoured` varchar(10) DEFAULT NULL,
  `referral_experience` varchar(255) DEFAULT NULL,
  `home_visit_benefit` varchar(10) DEFAULT NULL,
  `adherence_plan` varchar(255) DEFAULT NULL,
  `next_appointment_date` date DEFAULT NULL,
  KEY `patient_id` (`patient_id`),
  KEY `visit_date` (`visit_date`),
  CONSTRAINT `enhanced_adherence_ibfk_1` FOREIGN KEY (`patient_id`) REFERENCES `patient_demographics` (`patient_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `enhanced_adherence` */

/*Table structure for table `hei_enrollment` */

DROP TABLE IF EXISTS `hei_enrollment`;

CREATE TABLE `hei_enrollment` (
  `serial_no` int(11) NOT NULL DEFAULT '0',
  `patient_id` int(11) NOT NULL,
  `uuid` char(38) DEFAULT NULL,
  `provider` int(11) DEFAULT NULL,
  `visit_id` int(11) DEFAULT NULL,
  `visit_date` date DEFAULT NULL,
  `location_id` int(11) DEFAULT NULL,
  `encounter_id` int(11) NOT NULL,
  `child_exposed` varchar(7) CHARACTER SET utf8 DEFAULT NULL,
  `spd_number` varchar(50) DEFAULT NULL,
  `birth_weight` double DEFAULT NULL,
  `gestation_at_birth` double DEFAULT NULL,
  `date_first_seen` date DEFAULT NULL,
  `birth_notification_number` varchar(50) DEFAULT NULL,
  `birth_certificate_number` varchar(50) DEFAULT NULL,
  `need_for_special_care` varchar(3) CHARACTER SET utf8 DEFAULT NULL,
  `reason_for_special_care` varchar(40) CHARACTER SET utf8 DEFAULT NULL,
  `referral_source` varchar(10) CHARACTER SET utf8 DEFAULT NULL,
  `transfer_in` varchar(3) CHARACTER SET utf8 DEFAULT NULL,
  `transfer_in_date` date DEFAULT NULL,
  `facility_transferred_from` varchar(50) DEFAULT NULL,
  `district_transferred_from` varchar(50) DEFAULT NULL,
  `date_first_enrolled_in_hei_care` date DEFAULT NULL,
  `mother_breastfeeding` varchar(7) CHARACTER SET utf8 DEFAULT NULL,
  `TB_contact_history_in_household` varchar(3) CHARACTER SET utf8 DEFAULT NULL,
  `mother_alive` varchar(3) CHARACTER SET utf8 DEFAULT NULL,
  `mother_on_pmtct_drugs` varchar(3) CHARACTER SET utf8 DEFAULT NULL,
  `mother_on_drug` varchar(11) CHARACTER SET utf8 DEFAULT NULL,
  `mother_on_art_at_infant_enrollment` varchar(3) CHARACTER SET utf8 DEFAULT NULL,
  `mother_drug_regimen` varchar(13) CHARACTER SET utf8 DEFAULT NULL,
  `infant_prophylaxis` varchar(32) CHARACTER SET utf8 DEFAULT NULL,
  `parent_ccc_number` varchar(50) DEFAULT NULL,
  `mode_of_delivery` varchar(9) CHARACTER SET utf8 DEFAULT NULL,
  `place_of_delivery` varchar(8) CHARACTER SET utf8 DEFAULT NULL,
  `birth_length` int(11) DEFAULT NULL,
  `birth_order` int(11) DEFAULT NULL,
  `health_facility_name` varchar(50) DEFAULT NULL,
  `date_of_birth_notification` date DEFAULT NULL,
  `date_of_birth_registration` date DEFAULT NULL,
  `birth_registration_place` varchar(50) DEFAULT NULL,
  `permanent_registration_serial` varchar(50) DEFAULT NULL,
  `mother_facility_registered` varchar(50) DEFAULT NULL,
  `exit_date` date DEFAULT NULL,
  `exit_reason` varchar(29) CHARACTER SET utf8 DEFAULT NULL,
  `hiv_status_at_exit` varchar(50) DEFAULT NULL,
  KEY `patient_id` (`patient_id`),
  KEY `visit_date` (`visit_date`),
  CONSTRAINT `hei_enrollment_ibfk_1` FOREIGN KEY (`patient_id`) REFERENCES `patient_demographics` (`patient_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `hei_enrollment` */

/*Table structure for table `hei_follow_up_visit` */

DROP TABLE IF EXISTS `hei_follow_up_visit`;

CREATE TABLE `hei_follow_up_visit` (
  `patient_id` int(11) NOT NULL,
  `uuid` char(38) DEFAULT NULL,
  `provider` int(11) DEFAULT NULL,
  `visit_id` int(11) DEFAULT NULL,
  `visit_date` date DEFAULT NULL,
  `location_id` int(11) DEFAULT NULL,
  `encounter_id` int(11) NOT NULL,
  `weight` double DEFAULT NULL,
  `height` double DEFAULT NULL,
  `primary_caregiver` varchar(8) CHARACTER SET utf8 DEFAULT NULL,
  `infant_feeding` varchar(28) CHARACTER SET utf8 DEFAULT NULL,
  `tb_assessment_outcome` varchar(21) CHARACTER SET utf8 DEFAULT NULL,
  `social_smile_milestone` varchar(12) CHARACTER SET utf8 DEFAULT NULL,
  `head_control_milestone` varchar(20) CHARACTER SET utf8 DEFAULT NULL,
  `response_to_sound_milestone` varchar(33) CHARACTER SET utf8 DEFAULT NULL,
  `hand_extension_milestone` varchar(27) CHARACTER SET utf8 DEFAULT NULL,
  `sitting_milestone` varchar(7) CHARACTER SET utf8 DEFAULT NULL,
  `walking_milestone` varchar(7) CHARACTER SET utf8 DEFAULT NULL,
  `standing_milestone` varchar(8) CHARACTER SET utf8 DEFAULT NULL,
  `talking_milestone` varchar(7) CHARACTER SET utf8 DEFAULT NULL,
  `review_of_systems_developmental` varchar(12) CHARACTER SET utf8 DEFAULT NULL,
  `dna_pcr_sample_date` date DEFAULT NULL,
  `dna_pcr_contextual_status` varchar(36) CHARACTER SET utf8 DEFAULT NULL,
  `dna_pcr_result` varchar(19) CHARACTER SET utf8 DEFAULT NULL,
  `azt_given` varchar(3) CHARACTER SET utf8 DEFAULT NULL,
  `nvp_given` varchar(3) CHARACTER SET utf8 DEFAULT NULL,
  `ctx_given` varchar(3) CHARACTER SET utf8 DEFAULT NULL,
  `first_antibody_result` varchar(19) CHARACTER SET utf8 DEFAULT NULL,
  `final_antibody_result` varchar(19) CHARACTER SET utf8 DEFAULT NULL,
  `tetracycline_ointment_given` varchar(3) CHARACTER SET utf8 DEFAULT NULL,
  `pupil_examination` varchar(5) CHARACTER SET utf8 DEFAULT NULL,
  `sight_examination` varchar(21) CHARACTER SET utf8 DEFAULT NULL,
  `squint` varchar(9) CHARACTER SET utf8 DEFAULT NULL,
  `deworming_drug` varchar(11) CHARACTER SET utf8 DEFAULT NULL,
  `dosage` int(11) DEFAULT NULL,
  `unit` varchar(100) DEFAULT NULL,
  `comments` varchar(100) DEFAULT NULL,
  `next_appointment_date` date DEFAULT NULL,
  KEY `patient_id` (`patient_id`),
  KEY `visit_date` (`visit_date`),
  KEY `infant_feeding` (`infant_feeding`),
  CONSTRAINT `hei_follow_up_visit_ibfk_1` FOREIGN KEY (`patient_id`) REFERENCES `patient_demographics` (`patient_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `hei_follow_up_visit` */

/*Table structure for table `hei_immunization` */

DROP TABLE IF EXISTS `hei_immunization`;

CREATE TABLE `hei_immunization` (
  `patient_id` int(11) NOT NULL,
  `visit_date` date DEFAULT NULL,
  `created_by` int(11) DEFAULT NULL,
  `date_created` date DEFAULT NULL,
  `encounter_id` int(11) NOT NULL,
  `BCG` varchar(50) DEFAULT NULL,
  `OPV_birth` varchar(50) DEFAULT NULL,
  `OPV_1` varchar(50) DEFAULT NULL,
  `OPV_2` varchar(50) DEFAULT NULL,
  `OPV_3` varchar(50) DEFAULT NULL,
  `IPV` varchar(50) DEFAULT NULL,
  `DPT_Hep_B_Hib_1` varchar(50) DEFAULT NULL,
  `DPT_Hep_B_Hib_2` varchar(50) DEFAULT NULL,
  `DPT_Hep_B_Hib_3` varchar(50) DEFAULT NULL,
  `PCV_10_1` varchar(50) DEFAULT NULL,
  `PCV_10_2` varchar(50) DEFAULT NULL,
  `PCV_10_3` varchar(50) DEFAULT NULL,
  `ROTA_1` varchar(50) DEFAULT NULL,
  `ROTA_2` varchar(50) DEFAULT NULL,
  `Measles_rubella_1` varchar(50) DEFAULT NULL,
  `Measles_rubella_2` varchar(50) DEFAULT NULL,
  `Yellow_fever` varchar(50) DEFAULT NULL,
  `Measles_6_months` varchar(50) DEFAULT NULL,
  `VitaminA_6_months` varchar(50) DEFAULT NULL,
  `VitaminA_1_yr` varchar(50) DEFAULT NULL,
  `VitaminA_1_and_half_yr` varchar(50) DEFAULT NULL,
  `VitaminA_2_yr` varchar(50) DEFAULT NULL,
  `VitaminA_2_to_5_yr` varchar(50) DEFAULT NULL,
  `fully_immunized` date DEFAULT NULL,
  KEY `patient_id` (`patient_id`),
  CONSTRAINT `hei_immunization_ibfk_1` FOREIGN KEY (`patient_id`) REFERENCES `patient_demographics` (`patient_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `hei_immunization` */

/*Table structure for table `hiv_enrollment` */

DROP TABLE IF EXISTS `hiv_enrollment`;

CREATE TABLE `hiv_enrollment` (
  `patient_id` int(11) NOT NULL,
  `uuid` char(38) DEFAULT NULL,
  `visit_id` int(11) DEFAULT NULL,
  `visit_date` date DEFAULT NULL,
  `location_id` int(11) DEFAULT NULL,
  `encounter_id` int(11) NOT NULL,
  `encounter_provider` int(11) DEFAULT NULL,
  `date_created` date DEFAULT NULL,
  `patient_type` int(11) DEFAULT NULL,
  `date_first_enrolled_in_care` date DEFAULT NULL,
  `entry_point` varchar(13) CHARACTER SET utf8 DEFAULT NULL,
  `transfer_in_date` date DEFAULT NULL,
  `facility_transferred_from` varchar(255) DEFAULT NULL,
  `district_transferred_from` varchar(255) DEFAULT NULL,
  `date_started_art_at_transferring_facility` date DEFAULT NULL,
  `date_confirmed_hiv_positive` date DEFAULT NULL,
  `facility_confirmed_hiv_positive` varchar(255) DEFAULT NULL,
  `arv_status` varchar(3) CHARACTER SET utf8 DEFAULT NULL,
  `name_of_treatment_supporter` varchar(255) DEFAULT NULL,
  `relationship_of_treatment_supporter` varchar(11) CHARACTER SET utf8 DEFAULT NULL,
  `treatment_supporter_telephone` varchar(100) DEFAULT NULL,
  `treatment_supporter_address` varchar(100) DEFAULT NULL,
  KEY `patient_id` (`patient_id`),
  KEY `visit_date` (`visit_date`),
  KEY `arv_status` (`arv_status`),
  KEY `date_confirmed_hiv_positive` (`date_confirmed_hiv_positive`),
  KEY `entry_point` (`entry_point`),
  CONSTRAINT `hiv_enrollment_ibfk_1` FOREIGN KEY (`patient_id`) REFERENCES `patient_demographics` (`patient_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `hiv_enrollment` */

/*Table structure for table `hiv_followup` */

DROP TABLE IF EXISTS `hiv_followup`;

CREATE TABLE `hiv_followup` (
  `patient_id` int(11) NOT NULL,
  `visit_id` int(11) DEFAULT NULL,
  `visit_date` date DEFAULT NULL,
  `location_id` int(11) DEFAULT NULL,
  `encounter_id` int(11) NOT NULL,
  `encounter_provider` int(11) DEFAULT NULL,
  `date_created` date DEFAULT NULL,
  `visit_scheduled` varchar(15) CHARACTER SET utf8 DEFAULT NULL,
  `person_present` varchar(24) CHARACTER SET utf8 DEFAULT NULL,
  `weight` double DEFAULT NULL,
  `systolic_pressure` double DEFAULT NULL,
  `diastolic_pressure` double DEFAULT NULL,
  `height` double DEFAULT NULL,
  `temperature` double DEFAULT NULL,
  `pulse_rate` double DEFAULT NULL,
  `respiratory_rate` double DEFAULT NULL,
  `oxygen_saturation` double DEFAULT NULL,
  `muac` double DEFAULT NULL,
  `nutritional_status` varchar(27) CHARACTER SET utf8 DEFAULT NULL,
  `population_type` varchar(18) CHARACTER SET utf8 DEFAULT NULL,
  `key_population_type` varchar(25) CHARACTER SET utf8 DEFAULT NULL,
  `who_stage` varchar(10) CHARACTER SET utf8 NOT NULL DEFAULT '',
  `presenting_complaints` varchar(3) CHARACTER SET utf8 DEFAULT NULL,
  `clinical_notes` varchar(600) DEFAULT NULL,
  `on_anti_tb_drugs` varchar(3) CHARACTER SET utf8 DEFAULT NULL,
  `on_ipt` varchar(3) CHARACTER SET utf8 DEFAULT NULL,
  `ever_on_ipt` varchar(3) CHARACTER SET utf8 DEFAULT NULL,
  `spatum_smear_ordered` varchar(3) CHARACTER SET utf8 DEFAULT NULL,
  `chest_xray_ordered` varchar(3) CHARACTER SET utf8 DEFAULT NULL,
  `genexpert_ordered` varchar(3) CHARACTER SET utf8 DEFAULT NULL,
  `spatum_smear_result` varchar(8) CHARACTER SET utf8 DEFAULT NULL,
  `chest_xray_result` varchar(8) CHARACTER SET utf8 DEFAULT NULL,
  `genexpert_result` varchar(74) CHARACTER SET utf8 DEFAULT NULL,
  `referral` varchar(3) CHARACTER SET utf8 DEFAULT NULL,
  `clinical_tb_diagnosis` varchar(8) CHARACTER SET utf8 DEFAULT NULL,
  `contact_invitation` varchar(3) CHARACTER SET utf8 DEFAULT NULL,
  `evaluated_for_ipt` varchar(3) CHARACTER SET utf8 DEFAULT NULL,
  `has_known_allergies` varchar(3) CHARACTER SET utf8 DEFAULT NULL,
  `has_chronic_illnesses_cormobidities` varchar(3) CHARACTER SET utf8 DEFAULT NULL,
  `has_adverse_drug_reaction` varchar(3) CHARACTER SET utf8 DEFAULT NULL,
  `pregnancy_status` varchar(3) CHARACTER SET utf8 DEFAULT NULL,
  `wants_pregnancy` varchar(3) CHARACTER SET utf8 DEFAULT NULL,
  `pregnancy_outcome` varchar(55) CHARACTER SET utf8 DEFAULT NULL,
  `anc_number` varchar(50) DEFAULT NULL,
  `expected_delivery_date` date DEFAULT NULL,
  `last_menstrual_period` date DEFAULT NULL,
  `gravida` int(11) DEFAULT NULL,
  `parity` int(11) DEFAULT NULL,
  `full_term_pregnancies` int(11) DEFAULT NULL,
  `abortion_miscarriages` int(11) DEFAULT NULL,
  `family_planning_status` varchar(25) CHARACTER SET utf8 DEFAULT NULL,
  `family_planning_method` varchar(29) CHARACTER SET utf8 DEFAULT NULL,
  `reason_not_using_family_planning` varchar(25) CHARACTER SET utf8 DEFAULT NULL,
  `tb_status` varchar(21) CHARACTER SET utf8 DEFAULT NULL,
  `tb_treatment_no` varchar(50) DEFAULT NULL,
  `ctx_adherence` varchar(10) CHARACTER SET utf8 DEFAULT NULL,
  `ctx_dispensed` varchar(14) CHARACTER SET utf8 DEFAULT NULL,
  `dapsone_adherence` varchar(10) CHARACTER SET utf8 DEFAULT NULL,
  `dapsone_dispensed` varchar(14) CHARACTER SET utf8 DEFAULT NULL,
  `inh_dispensed` varchar(14) CHARACTER SET utf8 DEFAULT NULL,
  `arv_adherence` varchar(10) CHARACTER SET utf8 DEFAULT NULL,
  `poor_arv_adherence_reason` varchar(66) CHARACTER SET utf8 DEFAULT NULL,
  `poor_arv_adherence_reason_other` varchar(200) DEFAULT NULL,
  `pwp_disclosure` varchar(7) CHARACTER SET utf8 DEFAULT NULL,
  `pwp_partner_tested` varchar(7) CHARACTER SET utf8 DEFAULT NULL,
  `condom_provided` varchar(7) CHARACTER SET utf8 DEFAULT NULL,
  `screened_for_sti` varchar(8) CHARACTER SET utf8 DEFAULT NULL,
  `cacx_screening` varchar(8) CHARACTER SET utf8 DEFAULT NULL,
  `sti_partner_notification` varchar(3) CHARACTER SET utf8 DEFAULT NULL,
  `at_risk_population` varchar(25) CHARACTER SET utf8 DEFAULT NULL,
  `system_review_finding` varchar(8) CHARACTER SET utf8 DEFAULT NULL,
  `next_appointment_date` date DEFAULT NULL,
  `next_appointment_reason` varchar(15) CHARACTER SET utf8 DEFAULT NULL,
  `stability` varchar(14) CHARACTER SET utf8 DEFAULT NULL,
  `differentiated_care` varchar(37) CHARACTER SET utf8 DEFAULT NULL,
  KEY `patient_id` (`patient_id`),
  KEY `visit_date` (`visit_date`),
  KEY `pregnancy_status` (`pregnancy_status`),
  KEY `family_planning_status` (`family_planning_status`),
  KEY `tb_status` (`tb_status`),
  KEY `ctx_dispensed` (`ctx_dispensed`),
  KEY `population_type` (`population_type`),
  KEY `on_anti_tb_drugs` (`on_anti_tb_drugs`),
  KEY `stability` (`stability`),
  KEY `differentiated_care` (`differentiated_care`),
  CONSTRAINT `hiv_followup_ibfk_1` FOREIGN KEY (`patient_id`) REFERENCES `patient_demographics` (`patient_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `hiv_followup` */

/*Table structure for table `hts_referral` */

DROP TABLE IF EXISTS `hts_referral`;

CREATE TABLE `hts_referral` (
  `patient_id` int(11) NOT NULL,
  `visit_id` int(11) DEFAULT NULL,
  `encounter_id` int(11) NOT NULL,
  `encounter_uuid` char(38) NOT NULL,
  `encounter_location` int(11) NOT NULL,
  `creator` int(11) NOT NULL,
  `date_created` date NOT NULL,
  `visit_date` date DEFAULT NULL,
  `facility_referred_to` varchar(50) DEFAULT NULL,
  `date_to_enrol` date DEFAULT NULL,
  `remarks` varchar(100) DEFAULT NULL,
  `voided` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `hts_referral` */

/*Table structure for table `hts_referral_and_linkage` */

DROP TABLE IF EXISTS `hts_referral_and_linkage`;

CREATE TABLE `hts_referral_and_linkage` (
  `patient_id` int(11) NOT NULL,
  `visit_id` int(11) DEFAULT NULL,
  `encounter_id` int(11) NOT NULL,
  `encounter_uuid` char(38) NOT NULL,
  `encounter_location` int(11) NOT NULL,
  `creator` int(11) NOT NULL,
  `date_created` date NOT NULL,
  `visit_date` date DEFAULT NULL,
  `tracing_type` varchar(50) DEFAULT NULL,
  `tracing_status` varchar(100) DEFAULT NULL,
  `ccc_number` varchar(100) DEFAULT NULL,
  `facility_linked_to` varchar(100) DEFAULT NULL,
  `enrollment_date` date DEFAULT NULL,
  `art_start_date` date DEFAULT NULL,
  `provider_handed_to` varchar(100) DEFAULT NULL,
  `voided` int(11) DEFAULT NULL,
  KEY `patient_id` (`patient_id`),
  KEY `visit_date` (`visit_date`),
  CONSTRAINT `hts_referral_and_linkage_ibfk_1` FOREIGN KEY (`patient_id`) REFERENCES `patient_demographics` (`patient_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `hts_referral_and_linkage` */

/*Table structure for table `hts_test` */

DROP TABLE IF EXISTS `hts_test`;

CREATE TABLE `hts_test` (
  `patient_id` int(11) NOT NULL,
  `visit_id` int(11) DEFAULT NULL,
  `encounter_id` int(11) NOT NULL,
  `encounter_uuid` char(38) NOT NULL,
  `encounter_location` int(11) NOT NULL,
  `creator` int(11) NOT NULL,
  `date_created` date NOT NULL,
  `visit_date` date DEFAULT NULL,
  `test_type` int(11) DEFAULT NULL,
  `population_type` varchar(50) DEFAULT NULL,
  `key_population_type` varchar(50) DEFAULT NULL,
  `ever_tested_for_hiv` varchar(10) DEFAULT NULL,
  `months_since_last_test` int(11) DEFAULT NULL,
  `patient_disabled` varchar(50) DEFAULT NULL,
  `disability_type` varchar(50) DEFAULT NULL,
  `patient_consented` varchar(50) DEFAULT NULL,
  `client_tested_as` varchar(50) DEFAULT NULL,
  `test_strategy` varchar(50) DEFAULT NULL,
  `hts_entry_point` varchar(50) DEFAULT NULL,
  `test_1_kit_name` varchar(50) DEFAULT NULL,
  `test_1_kit_lot_no` varchar(50) DEFAULT NULL,
  `test_1_kit_expiry` date DEFAULT NULL,
  `test_1_result` varchar(50) DEFAULT NULL,
  `test_2_kit_name` varchar(50) DEFAULT NULL,
  `test_2_kit_lot_no` varchar(50) DEFAULT NULL,
  `test_2_kit_expiry` date DEFAULT NULL,
  `test_2_result` varchar(50) DEFAULT NULL,
  `final_test_result` varchar(50) DEFAULT NULL,
  `patient_given_result` varchar(50) DEFAULT NULL,
  `couple_discordant` varchar(100) DEFAULT NULL,
  `tb_screening` varchar(20) DEFAULT NULL,
  `patient_had_hiv_self_test` varchar(50) DEFAULT NULL,
  `remarks` varchar(255) DEFAULT NULL,
  `voided` int(11) DEFAULT NULL,
  KEY `patient_id` (`patient_id`),
  KEY `visit_date` (`visit_date`),
  KEY `population_type` (`population_type`),
  KEY `final_test_result` (`final_test_result`),
  CONSTRAINT `hts_test_ibfk_1` FOREIGN KEY (`patient_id`) REFERENCES `patient_demographics` (`patient_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `hts_test` */

/*Table structure for table `ipt_followup` */

DROP TABLE IF EXISTS `ipt_followup`;

CREATE TABLE `ipt_followup` (
  `uuid` char(38) DEFAULT NULL,
  `patient_id` int(11) NOT NULL,
  `visit_id` int(11) DEFAULT NULL,
  `visit_date` date DEFAULT NULL,
  `location_id` int(11) DEFAULT NULL,
  `encounter_id` int(11) NOT NULL,
  `provider` int(11) DEFAULT NULL,
  `date_created` date NOT NULL,
  `ipt_due_date` date DEFAULT NULL,
  `date_collected_ipt` date DEFAULT NULL,
  `weight` double DEFAULT NULL,
  `hepatotoxity` varchar(100) DEFAULT NULL,
  `peripheral_neuropathy` varchar(100) DEFAULT NULL,
  `rash` varchar(100) DEFAULT NULL,
  `adherence` varchar(100) DEFAULT NULL,
  `action_taken` varchar(100) DEFAULT NULL,
  `voided` int(11) DEFAULT NULL,
  KEY `patient_id` (`patient_id`),
  CONSTRAINT `ipt_followup_ibfk_1` FOREIGN KEY (`patient_id`) REFERENCES `patient_demographics` (`patient_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `ipt_followup` */

/*Table structure for table `laboratory_extract` */

DROP TABLE IF EXISTS `laboratory_extract`;

CREATE TABLE `laboratory_extract` (
  `uuid` char(38) NOT NULL,
  `encounter_id` int(11) DEFAULT NULL,
  `patient_id` int(11) NOT NULL,
  `location_id` int(11) DEFAULT NULL,
  `visit_date` date DEFAULT NULL,
  `visit_id` int(11) DEFAULT NULL,
  `lab_test` varchar(25) CHARACTER SET utf8 DEFAULT NULL,
  `urgency` varchar(50) DEFAULT NULL,
  `test_result` varchar(180) DEFAULT NULL,
  `date_created` date DEFAULT NULL,
  `created_by` int(11) DEFAULT NULL,
  KEY `patient_id` (`patient_id`),
  KEY `visit_date` (`visit_date`),
  KEY `lab_test` (`lab_test`),
  KEY `test_result` (`test_result`),
  CONSTRAINT `laboratory_extract_ibfk_1` FOREIGN KEY (`patient_id`) REFERENCES `patient_demographics` (`patient_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `laboratory_extract` */

/*Table structure for table `mch_antenatal_visit` */

DROP TABLE IF EXISTS `mch_antenatal_visit`;

CREATE TABLE `mch_antenatal_visit` (
  `patient_id` int(11) NOT NULL,
  `uuid` char(38) DEFAULT NULL,
  `visit_id` int(11) DEFAULT NULL,
  `visit_date` date DEFAULT NULL,
  `location_id` int(11) DEFAULT NULL,
  `encounter_id` int(11) NOT NULL,
  `provider` int(11) DEFAULT NULL,
  `anc_visit_number` int(11) DEFAULT NULL,
  `temperature` double DEFAULT NULL,
  `pulse_rate` double DEFAULT NULL,
  `systolic_bp` double DEFAULT NULL,
  `diastolic_bp` double DEFAULT NULL,
  `respiratory_rate` double DEFAULT NULL,
  `oxygen_saturation` int(11) DEFAULT NULL,
  `weight` double DEFAULT NULL,
  `height` double DEFAULT NULL,
  `muac` double DEFAULT NULL,
  `hemoglobin` double DEFAULT NULL,
  `breast_exam_done` varchar(3) CHARACTER SET utf8 DEFAULT NULL,
  `pallor` varchar(3) CHARACTER SET utf8 DEFAULT NULL,
  `maturity` int(11) DEFAULT NULL,
  `fundal_height` double DEFAULT NULL,
  `fetal_presentation` varchar(40) CHARACTER SET utf8 DEFAULT NULL,
  `lie` varchar(16) CHARACTER SET utf8 DEFAULT NULL,
  `fetal_heart_rate` int(11) DEFAULT NULL,
  `fetal_movement` varchar(25) CHARACTER SET utf8 DEFAULT NULL,
  `who_stage` varchar(10) CHARACTER SET utf8 DEFAULT NULL,
  `cd4` int(11) DEFAULT NULL,
  `viral_load` int(11) DEFAULT NULL,
  `ldl` varchar(3) CHARACTER SET utf8 DEFAULT NULL,
  `arv_status` varchar(15) CHARACTER SET utf8 DEFAULT NULL,
  `final_test_result` varchar(50) DEFAULT NULL,
  `patient_given_result` varchar(50) DEFAULT NULL,
  `partner_hiv_tested` varchar(3) CHARACTER SET utf8 DEFAULT NULL,
  `partner_hiv_status` varchar(12) CHARACTER SET utf8 DEFAULT NULL,
  `prophylaxis_given` varchar(13) CHARACTER SET utf8 DEFAULT NULL,
  `baby_azt_dispensed` varchar(3) CHARACTER SET utf8 DEFAULT NULL,
  `baby_nvp_dispensed` varchar(3) CHARACTER SET utf8 DEFAULT NULL,
  `TTT` varchar(50) DEFAULT NULL,
  `IPT_malaria` varchar(50) DEFAULT NULL,
  `iron_supplement` varchar(50) DEFAULT NULL,
  `deworming` varchar(50) DEFAULT NULL,
  `bed_nets` varchar(50) DEFAULT NULL,
  `urine_microscopy` varchar(100) DEFAULT NULL,
  `urinary_albumin` varchar(22) CHARACTER SET utf8 DEFAULT NULL,
  `glucose_measurement` varchar(15) CHARACTER SET utf8 DEFAULT NULL,
  `urine_ph` int(11) DEFAULT NULL,
  `urine_gravity` int(11) DEFAULT NULL,
  `urine_nitrite_test` varchar(12) CHARACTER SET utf8 DEFAULT NULL,
  `urine_leukocyte_esterace_test` varchar(15) CHARACTER SET utf8 DEFAULT NULL,
  `urinary_ketone` varchar(21) CHARACTER SET utf8 DEFAULT NULL,
  `urine_bile_salt_test` varchar(20) CHARACTER SET utf8 DEFAULT NULL,
  `urine_bile_pigment_test` varchar(15) CHARACTER SET utf8 DEFAULT NULL,
  `urine_colour` varchar(19) CHARACTER SET utf8 DEFAULT NULL,
  `urine_turbidity` varchar(20) CHARACTER SET utf8 DEFAULT NULL,
  `urine_dipstick_for_blood` varchar(15) CHARACTER SET utf8 DEFAULT NULL,
  `syphilis_test_status` varchar(19) CHARACTER SET utf8 DEFAULT NULL,
  `syphilis_treated_status` varchar(3) CHARACTER SET utf8 DEFAULT NULL,
  `bs_mps` varchar(13) CHARACTER SET utf8 DEFAULT NULL,
  `anc_exercises` varchar(7) CHARACTER SET utf8 DEFAULT NULL,
  `tb_screening` varchar(27) CHARACTER SET utf8 DEFAULT NULL,
  `cacx_screening` varchar(8) CHARACTER SET utf8 DEFAULT NULL,
  `cacx_screening_method` varchar(9) CHARACTER SET utf8 DEFAULT NULL,
  `has_other_illnes` varchar(3) CHARACTER SET utf8 DEFAULT NULL,
  `counselled` varchar(3) CHARACTER SET utf8 DEFAULT NULL,
  `referred_from` varchar(23) CHARACTER SET utf8 DEFAULT NULL,
  `referred_to` varchar(23) CHARACTER SET utf8 DEFAULT NULL,
  `next_appointment_date` date DEFAULT NULL,
  `clinical_notes` varchar(200) DEFAULT NULL,
  KEY `patient_id` (`patient_id`),
  KEY `visit_date` (`visit_date`),
  CONSTRAINT `mch_antenatal_visit_ibfk_1` FOREIGN KEY (`patient_id`) REFERENCES `patient_demographics` (`patient_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `mch_antenatal_visit` */

/*Table structure for table `mch_delivery` */

DROP TABLE IF EXISTS `mch_delivery`;

CREATE TABLE `mch_delivery` (
  `patient_id` int(11) NOT NULL,
  `uuid` char(38) DEFAULT NULL,
  `provider` int(11) DEFAULT NULL,
  `visit_id` int(11) DEFAULT NULL,
  `visit_date` date DEFAULT NULL,
  `location_id` int(11) DEFAULT NULL,
  `encounter_id` int(11) NOT NULL,
  `date_created` date DEFAULT NULL,
  `admission_number` varchar(50) DEFAULT NULL,
  `duration_of_pregnancy` double DEFAULT NULL,
  `mode_of_delivery` varchar(36) CHARACTER SET utf8 DEFAULT NULL,
  `date_of_delivery` datetime DEFAULT NULL,
  `blood_loss` varchar(8) CHARACTER SET utf8 DEFAULT NULL,
  `condition_of_mother` varchar(5) CHARACTER SET utf8 DEFAULT NULL,
  `apgar_score_1min` double DEFAULT NULL,
  `apgar_score_5min` double DEFAULT NULL,
  `apgar_score_10min` double DEFAULT NULL,
  `resuscitation_done` varchar(7) CHARACTER SET utf8 DEFAULT NULL,
  `place_of_delivery` varchar(27) CHARACTER SET utf8 DEFAULT NULL,
  `delivery_assistant` varchar(100) DEFAULT NULL,
  `counseling_on_infant_feeding` varchar(41) CHARACTER SET utf8 DEFAULT NULL,
  `counseling_on_exclusive_breastfeeding` varchar(38) CHARACTER SET utf8 DEFAULT NULL,
  `counseling_on_infant_feeding_for_hiv_infected` varchar(54) CHARACTER SET utf8 DEFAULT NULL,
  `mother_decision` varchar(23) CHARACTER SET utf8 DEFAULT NULL,
  `placenta_complete` varchar(31) CHARACTER SET utf8 DEFAULT NULL,
  `maternal_death_audited` varchar(3) CHARACTER SET utf8 DEFAULT NULL,
  `cadre` varchar(29) CHARACTER SET utf8 DEFAULT NULL,
  `delivery_complications` varchar(3) CHARACTER SET utf8 DEFAULT NULL,
  `coded_delivery_complications` varchar(16) CHARACTER SET utf8 DEFAULT NULL,
  `other_delivery_complications` varchar(100) DEFAULT NULL,
  `duration_of_labor` int(11) DEFAULT NULL,
  `baby_sex` varchar(13) CHARACTER SET utf8 DEFAULT NULL,
  `baby_condition` varchar(54) CHARACTER SET utf8 DEFAULT NULL,
  `teo_given` varchar(14) CHARACTER SET utf8 DEFAULT NULL,
  `birth_weight` int(11) DEFAULT NULL,
  `bf_within_one_hour` varchar(3) CHARACTER SET utf8 DEFAULT NULL,
  `birth_with_deformity` varchar(14) CHARACTER SET utf8 DEFAULT NULL,
  `final_test_result` varchar(50) DEFAULT NULL,
  `patient_given_result` varchar(50) DEFAULT NULL,
  `partner_hiv_tested` varchar(3) CHARACTER SET utf8 DEFAULT NULL,
  `partner_hiv_status` varchar(12) CHARACTER SET utf8 DEFAULT NULL,
  `prophylaxis_given` varchar(31) CHARACTER SET utf8 DEFAULT NULL,
  `baby_azt_dispensed` varchar(20) CHARACTER SET utf8 DEFAULT NULL,
  `baby_nvp_dispensed` varchar(14) CHARACTER SET utf8 DEFAULT NULL,
  `clinical_notes` varchar(200) DEFAULT NULL,
  KEY `patient_id` (`patient_id`),
  KEY `visit_date` (`visit_date`),
  CONSTRAINT `mch_delivery_ibfk_1` FOREIGN KEY (`patient_id`) REFERENCES `patient_demographics` (`patient_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `mch_delivery` */

/*Table structure for table `mch_discharge` */

DROP TABLE IF EXISTS `mch_discharge`;

CREATE TABLE `mch_discharge` (
  `patient_id` int(11) NOT NULL,
  `uuid` char(38) DEFAULT NULL,
  `provider` int(11) DEFAULT NULL,
  `visit_id` int(11) DEFAULT NULL,
  `visit_date` date DEFAULT NULL,
  `location_id` int(11) DEFAULT NULL,
  `encounter_id` int(11) NOT NULL,
  `date_created` date DEFAULT NULL,
  `counselled_on_feeding` varchar(3) CHARACTER SET utf8 DEFAULT NULL,
  `baby_status` varchar(5) CHARACTER SET utf8 DEFAULT NULL,
  `vitamin_A_dispensed` varchar(7) CHARACTER SET utf8 DEFAULT NULL,
  `birth_notification_number` int(50) DEFAULT NULL,
  `condition_of_mother` varchar(100) DEFAULT NULL,
  `discharge_date` date DEFAULT NULL,
  `referred_from` varchar(23) CHARACTER SET utf8 DEFAULT NULL,
  `referred_to` varchar(23) CHARACTER SET utf8 DEFAULT NULL,
  `clinical_notes` varchar(200) DEFAULT NULL,
  KEY `patient_id` (`patient_id`),
  KEY `visit_date` (`visit_date`),
  CONSTRAINT `mch_discharge_ibfk_1` FOREIGN KEY (`patient_id`) REFERENCES `patient_demographics` (`patient_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `mch_discharge` */

/*Table structure for table `mch_enrollment` */

DROP TABLE IF EXISTS `mch_enrollment`;

CREATE TABLE `mch_enrollment` (
  `patient_id` int(11) NOT NULL,
  `uuid` char(38) DEFAULT NULL,
  `visit_id` int(11) DEFAULT NULL,
  `visit_date` date DEFAULT NULL,
  `location_id` int(11) DEFAULT NULL,
  `encounter_id` int(11) NOT NULL,
  `anc_number` varchar(50) DEFAULT NULL,
  `first_anc_visit_date` date DEFAULT NULL,
  `gravida` int(11) DEFAULT NULL,
  `parity` int(11) DEFAULT NULL,
  `parity_abortion` int(11) DEFAULT NULL,
  `age_at_menarche` int(11) DEFAULT NULL,
  `lmp` date DEFAULT NULL,
  `lmp_estimated` int(11) DEFAULT NULL,
  `edd_ultrasound` date DEFAULT NULL,
  `blood_group` varchar(11) CHARACTER SET utf8 DEFAULT NULL,
  `serology` varchar(19) CHARACTER SET utf8 DEFAULT NULL,
  `tb_screening` varchar(8) CHARACTER SET utf8 DEFAULT NULL,
  `bs_for_mps` varchar(13) CHARACTER SET utf8 DEFAULT NULL,
  `hiv_status` varchar(12) CHARACTER SET utf8 DEFAULT NULL,
  `hiv_test_date` date DEFAULT NULL,
  `partner_hiv_status` varchar(12) CHARACTER SET utf8 DEFAULT NULL,
  `partner_hiv_test_date` date DEFAULT NULL,
  `urine_microscopy` varchar(100) DEFAULT NULL,
  `urinary_albumin` varchar(22) CHARACTER SET utf8 DEFAULT NULL,
  `glucose_measurement` varchar(15) CHARACTER SET utf8 DEFAULT NULL,
  `urine_ph` int(11) DEFAULT NULL,
  `urine_gravity` int(11) DEFAULT NULL,
  `urine_nitrite_test` varchar(12) CHARACTER SET utf8 DEFAULT NULL,
  `urine_leukocyte_esterace_test` varchar(15) CHARACTER SET utf8 DEFAULT NULL,
  `urinary_ketone` varchar(21) CHARACTER SET utf8 DEFAULT NULL,
  `urine_bile_salt_test` varchar(20) CHARACTER SET utf8 DEFAULT NULL,
  `urine_bile_pigment_test` varchar(15) CHARACTER SET utf8 DEFAULT NULL,
  `urine_colour` varchar(19) CHARACTER SET utf8 DEFAULT NULL,
  `urine_turbidity` varchar(20) CHARACTER SET utf8 DEFAULT NULL,
  `urine_dipstick_for_blood` varchar(15) CHARACTER SET utf8 DEFAULT NULL,
  `discontinuation_reason` varchar(15) CHARACTER SET utf8 DEFAULT NULL,
  KEY `patient_id` (`patient_id`),
  KEY `visit_date` (`visit_date`),
  CONSTRAINT `mch_enrollment_ibfk_1` FOREIGN KEY (`patient_id`) REFERENCES `patient_demographics` (`patient_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `mch_enrollment` */

/*Table structure for table `mch_postnatal_visit` */

DROP TABLE IF EXISTS `mch_postnatal_visit`;

CREATE TABLE `mch_postnatal_visit` (
  `patient_id` int(11) NOT NULL,
  `uuid` char(38) DEFAULT NULL,
  `visit_id` int(11) DEFAULT NULL,
  `visit_date` date DEFAULT NULL,
  `location_id` int(11) DEFAULT NULL,
  `encounter_id` int(11) NOT NULL,
  `provider` int(11) DEFAULT NULL,
  `pnc_register_no` varchar(50) DEFAULT NULL,
  `pnc_visit_no` int(11) DEFAULT NULL,
  `delivery_date` date DEFAULT NULL,
  `mode_of_delivery` varchar(9) CHARACTER SET utf8 DEFAULT NULL,
  `place_of_delivery` varchar(8) CHARACTER SET utf8 DEFAULT NULL,
  `temperature` double DEFAULT NULL,
  `pulse_rate` double DEFAULT NULL,
  `systolic_bp` double DEFAULT NULL,
  `diastolic_bp` double DEFAULT NULL,
  `respiratory_rate` double DEFAULT NULL,
  `oxygen_saturation` int(11) DEFAULT NULL,
  `weight` double DEFAULT NULL,
  `height` double DEFAULT NULL,
  `muac` double DEFAULT NULL,
  `hemoglobin` double DEFAULT NULL,
  `arv_status` varchar(15) CHARACTER SET utf8 DEFAULT NULL,
  `general_condition` varchar(4) CHARACTER SET utf8 DEFAULT NULL,
  `breast` varchar(4) CHARACTER SET utf8 DEFAULT NULL,
  `cs_scar` varchar(37) CHARACTER SET utf8 DEFAULT NULL,
  `gravid_uterus` varchar(42) CHARACTER SET utf8 DEFAULT NULL,
  `episiotomy` varchar(29) CHARACTER SET utf8 DEFAULT NULL,
  `lochia` varchar(20) CHARACTER SET utf8 DEFAULT NULL,
  `pallor` varchar(14) CHARACTER SET utf8 DEFAULT NULL,
  `pph` varchar(7) CHARACTER SET utf8 DEFAULT NULL,
  `mother_hiv_status` varchar(8) CHARACTER SET utf8 DEFAULT NULL,
  `condition_of_baby` varchar(35) CHARACTER SET utf8 DEFAULT NULL,
  `baby_feeding_method` varchar(21) CHARACTER SET utf8 DEFAULT NULL,
  `umblical_cord` varchar(34) CHARACTER SET utf8 DEFAULT NULL,
  `baby_immunization_started` varchar(7) CHARACTER SET utf8 DEFAULT NULL,
  `family_planning_counseling` varchar(7) CHARACTER SET utf8 DEFAULT NULL,
  `uterus_examination` varchar(100) DEFAULT NULL,
  `uterus_cervix_examination` varchar(100) DEFAULT NULL,
  `vaginal_examination` varchar(100) DEFAULT NULL,
  `parametrial_examination` varchar(100) DEFAULT NULL,
  `external_genitalia_examination` varchar(100) DEFAULT NULL,
  `ovarian_examination` varchar(100) DEFAULT NULL,
  `pelvic_lymph_node_exam` varchar(100) DEFAULT NULL,
  `final_test_result` varchar(50) DEFAULT NULL,
  `patient_given_result` varchar(50) DEFAULT NULL,
  `partner_hiv_tested` varchar(3) CHARACTER SET utf8 DEFAULT NULL,
  `partner_hiv_status` varchar(12) CHARACTER SET utf8 DEFAULT NULL,
  `prophylaxis_given` varchar(13) CHARACTER SET utf8 DEFAULT NULL,
  `baby_azt_dispensed` varchar(3) CHARACTER SET utf8 DEFAULT NULL,
  `baby_nvp_dispensed` varchar(3) CHARACTER SET utf8 DEFAULT NULL,
  `pnc_exercises` varchar(7) CHARACTER SET utf8 DEFAULT NULL,
  `maternal_condition` varchar(35) CHARACTER SET utf8 DEFAULT NULL,
  `iron_supplementation` varchar(3) CHARACTER SET utf8 DEFAULT NULL,
  `fistula_screening` varchar(21) CHARACTER SET utf8 DEFAULT NULL,
  `cacx_screening` varchar(8) CHARACTER SET utf8 DEFAULT NULL,
  `cacx_screening_method` varchar(9) CHARACTER SET utf8 DEFAULT NULL,
  `family_planning_status` varchar(25) CHARACTER SET utf8 DEFAULT NULL,
  `family_planning_method` varchar(29) CHARACTER SET utf8 DEFAULT NULL,
  `referred_from` varchar(23) CHARACTER SET utf8 DEFAULT NULL,
  `referred_to` varchar(23) CHARACTER SET utf8 DEFAULT NULL,
  `clinical_notes` varchar(200) DEFAULT NULL,
  KEY `patient_id` (`patient_id`),
  KEY `visit_date` (`visit_date`),
  CONSTRAINT `mch_postnatal_visit_ibfk_1` FOREIGN KEY (`patient_id`) REFERENCES `patient_demographics` (`patient_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `mch_postnatal_visit` */

/*Table structure for table `patient_contact` */

DROP TABLE IF EXISTS `patient_contact`;

CREATE TABLE `patient_contact` (
  `id` int(11) NOT NULL DEFAULT '0',
  `uuid` char(38) DEFAULT NULL,
  `date_created` date DEFAULT NULL,
  `first_name` varchar(255) DEFAULT NULL,
  `middle_name` varchar(255) DEFAULT NULL,
  `last_name` varchar(255) DEFAULT NULL,
  `sex` varchar(50) DEFAULT NULL,
  `birth_date` datetime DEFAULT NULL,
  `physical_address` varchar(255) DEFAULT NULL,
  `phone_contact` varchar(255) DEFAULT NULL,
  `patient_related_to` int(11) DEFAULT NULL,
  `patient_id` int(11) DEFAULT NULL,
  `relationship_type` varchar(20) CHARACTER SET utf8 DEFAULT NULL,
  `appointment_date` datetime DEFAULT NULL,
  `baseline_hiv_status` varchar(255) DEFAULT NULL,
  `ipv_outcome` varchar(255) DEFAULT NULL,
  `marital_status` varchar(18) CHARACTER SET utf8 DEFAULT NULL,
  `living_with_patient` varchar(18) CHARACTER SET utf8 DEFAULT NULL,
  `pns_approach` varchar(17) CHARACTER SET utf8 DEFAULT NULL,
  `contact_listing_decline_reason` varchar(255) DEFAULT NULL,
  `consented_contact_listing` varchar(7) CHARACTER SET utf8 DEFAULT NULL,
  `voided` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `patient_related_to` (`patient_related_to`),
  KEY `date_created` (`date_created`),
  CONSTRAINT `patient_contact_ibfk_1` FOREIGN KEY (`patient_related_to`) REFERENCES `patient_demographics` (`patient_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `patient_contact` */

/*Table structure for table `patient_demographics` */

DROP TABLE IF EXISTS `patient_demographics`;

CREATE TABLE `patient_demographics` (
  `patient_id` int(11) NOT NULL,
  `given_name` varchar(255) DEFAULT NULL,
  `middle_name` varchar(255) DEFAULT NULL,
  `family_name` varchar(255) DEFAULT NULL,
  `Gender` varchar(10) DEFAULT NULL,
  `DOB` date DEFAULT NULL,
  `national_id_no` varchar(50) DEFAULT NULL,
  `unique_patient_no` varchar(50) DEFAULT NULL,
  `patient_clinic_number` varchar(15) DEFAULT NULL,
  `Tb_no` varchar(50) DEFAULT NULL,
  `district_reg_no` varchar(50) DEFAULT NULL,
  `hei_no` varchar(50) DEFAULT NULL,
  `phone_number` varchar(50) DEFAULT NULL,
  `birth_place` varchar(50) DEFAULT NULL,
  `citizenship` varchar(50) DEFAULT NULL,
  `email_address` varchar(100) DEFAULT NULL,
  `next_of_kin` varchar(255) DEFAULT NULL,
  `next_of_kin_relationship` varchar(100) DEFAULT NULL,
  `marital_status` varchar(50) DEFAULT NULL,
  `education_level` varchar(50) DEFAULT NULL,
  `dead` varchar(3) CHARACTER SET utf8 NOT NULL DEFAULT '',
  `death_date` date DEFAULT NULL,
  `voided` int(11) DEFAULT NULL,
  PRIMARY KEY (`patient_id`),
  KEY `Gender` (`Gender`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `patient_demographics` */

insert  into `patient_demographics`(`patient_id`,`given_name`,`middle_name`,`family_name`,`Gender`,`DOB`,`national_id_no`,`unique_patient_no`,`patient_clinic_number`,`Tb_no`,`district_reg_no`,`hei_no`,`phone_number`,`birth_place`,`citizenship`,`email_address`,`next_of_kin`,`next_of_kin_relationship`,`marital_status`,`education_level`,`dead`,`death_date`,`voided`) values (1,'Super','','User','M',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'NO',NULL,0),(2,'Unknown',NULL,'Provider','F',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'NO',NULL,0),(3,'manager',NULL,'upgrade','F',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'0788111111',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'NO',NULL,0),(4,'John',NULL,'Doe','M','1978-01-01','1615700003',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Never married','None','NO',NULL,0),(5,'Doe',NULL,'Jane','F','1988-06-15',NULL,NULL,'139390001',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Never married','College/university/polytechnic','NO',NULL,0),(6,'Nagwalla','Simiyu','Sam','M','1997-06-15',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Never married','Primary school education','NO',NULL,0),(7,'Mdoe','Juma','Swaleh','M','1968-06-15',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Never married','None','NO',NULL,0),(8,'Jones','Kuloba','jermaine','M','1995-06-15',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Widowed','None','NO',NULL,0),(9,'Bellingham','Majiwa','Jude','M','1998-06-15',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Never married','None','NO',NULL,0),(10,'James','Kamande','Njuguna','M','1998-06-15',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Never married','Secondary school education','NO',NULL,0),(11,'Rashid','Majid','Abdalla','M','1990-06-15','23415665',NULL,'1615700003',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Married','College/university/polytechnic','NO',NULL,0),(12,'Dean','Smith','Robert','M','1968-06-15',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Never married','College/university/polytechnic','NO',NULL,0),(13,'Emmanuel','Musee','Juma','M','1979-06-15','12364758',NULL,'1615700005',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'NO',NULL,0),(14,'Victor','Agape','Ven','M','1975-06-15',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'NO',NULL,0),(15,'Kagwe','Waziri','Mutahi','M','1986-06-15',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Widowed','Primary school education','NO',NULL,0),(16,'Ross','Oju','Dianah','F','1955-06-15','25647890',NULL,'1615700006',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Never married','None','NO',NULL,0),(17,'Frank','Mureithi','Njenga','M','1962-06-15','23452667',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Married','College/university/polytechnic','NO',NULL,0),(18,'Nelson',NULL,'Mandela','M','1990-04-01',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'NO',NULL,0),(19,'Wanyama',NULL,'Kelvin','M','1992-07-02',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'NO',NULL,0),(20,'Janeth','Mwanziah','Nyokabi','F','1985-06-15',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Married','Primary school education','NO',NULL,0),(21,'Lucas','Sossi','Radede','M','1978-01-02','23516326',NULL,'1615700008',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Married','Primary school education','NO',NULL,0),(22,'Mberia','Makobu','Jones','M','1998-03-11',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Married','Secondary school education','NO',NULL,0),(23,'Jones','Makovu','Mberia','M','1997-02-06',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Married','Primary school education','NO',NULL,0),(24,'James','Kimani','Mworia','M','1979-07-01',NULL,NULL,'1615700010',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Married','Secondary school education','NO',NULL,0),(25,'Jane',NULL,'Komu','F','1994-07-13',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'NO',NULL,0),(26,'James',NULL,'Beglin','M','1987-06-01',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'NO',NULL,0),(27,'Jairus',NULL,'Kambua','M','1997-07-01',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'NO',NULL,0),(28,'John',NULL,'Gicheru','M','1990-07-01',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'NO',NULL,0),(29,'Benjamin',NULL,'Mkapa','M','1999-10-02','1615700015',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'NO',NULL,0);

/*Table structure for table `patient_program_discontinuation` */

DROP TABLE IF EXISTS `patient_program_discontinuation`;

CREATE TABLE `patient_program_discontinuation` (
  `patient_id` int(11) NOT NULL,
  `uuid` char(38) DEFAULT NULL,
  `visit_id` int(11) DEFAULT NULL,
  `visit_date` datetime DEFAULT NULL,
  `program_uuid` char(38) DEFAULT NULL,
  `program_name` varchar(50) DEFAULT NULL,
  `encounter_id` int(11) NOT NULL,
  `discontinuation_reason` varchar(23) CHARACTER SET utf8 DEFAULT NULL,
  `date_died` date DEFAULT NULL,
  `transfer_facility` varchar(100) DEFAULT NULL,
  `transfer_date` date DEFAULT NULL,
  KEY `patient_id` (`patient_id`),
  KEY `visit_date` (`visit_date`),
  KEY `discontinuation_reason` (`discontinuation_reason`),
  CONSTRAINT `patient_program_discontinuation_ibfk_1` FOREIGN KEY (`patient_id`) REFERENCES `patient_demographics` (`patient_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `patient_program_discontinuation` */

/*Table structure for table `person_address` */

DROP TABLE IF EXISTS `person_address`;

CREATE TABLE `person_address` (
  `uuid` char(38) NOT NULL,
  `patient_id` int(11) NOT NULL,
  `county` varchar(100) DEFAULT NULL,
  `sub_county` varchar(100) DEFAULT NULL,
  `location` varchar(100) DEFAULT NULL,
  `ward` varchar(100) DEFAULT NULL,
  `sub_location` varchar(100) DEFAULT NULL,
  `village` varchar(100) DEFAULT NULL,
  `postal_address` varchar(100) DEFAULT NULL,
  `land_mark` varchar(100) DEFAULT NULL,
  `voided` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `person_address` */

insert  into `person_address`(`uuid`,`patient_id`,`county`,`sub_county`,`location`,`ward`,`sub_location`,`village`,`postal_address`,`land_mark`,`voided`) values ('0435f295-0bad-4526-8a7f-f48e15be05a1',18,NULL,'Dagoretti',NULL,NULL,NULL,NULL,NULL,'Dagoretti Health Centre',0),('054583d9-3292-4125-8996-40a4c9039ed7',11,'Kilifi','Malindi',NULL,'Msambweni',NULL,NULL,NULL,NULL,0),('0dcec2a0-356a-4239-95b7-44bd40afef16',29,NULL,'Kilifi North',NULL,NULL,NULL,NULL,NULL,'Kilif CRH',0),('1bfaa20e-11f0-4eba-9881-95d18d51b405',6,'Nyandarua','Kinangop',NULL,NULL,NULL,NULL,NULL,NULL,0),('48b95536-563a-4a3d-a1fd-623653becf2e',13,'Nairobi','Kibra','Soweto','Mugumoini',NULL,NULL,NULL,NULL,0),('68b66d74-106e-4f8c-b585-b12112b96a2c',5,'Nairobi','Makadara',NULL,'Makongeni',NULL,'Unknown',NULL,'Landi Mawe',0),('6dda8866-8862-4fd2-9843-a64e74572a21',28,NULL,'Ruaka',NULL,NULL,NULL,NULL,NULL,'Kiambi SCH',0),('73fd76ee-4bc4-48d6-ac3f-9c8d6fde7259',15,'Nairobi','Embakasi','Mihango','Embakasi East',NULL,NULL,NULL,NULL,0),('7b0fb3ec-2ba3-4651-904f-dfa3186c7efb',17,'Kisumu','Kisumu East','Konalejo','Kondele',NULL,NULL,NULL,NULL,0),('7bdb7645-e93c-497b-9cc5-3851b4c38cbf',10,'Nairobi','Westlands',NULL,'Kilimani',NULL,NULL,NULL,NULL,0),('894941c1-1861-4667-8c1a-79435cfd6703',21,'Nairobi','Embakasi East','Daraja Mbili','Mihango',NULL,NULL,NULL,'Mihango Dispensary',0),('8c599550-11c2-49e6-a920-1b005ef411c3',22,'Kisumu','Gita','Gita-B','Kibos',NULL,NULL,NULL,'Gita SCH',0),('9758447b-7d0a-4a3e-8c00-7e3404359e6e',24,'Kisumu','Gita','Gita A','Kibos',NULL,NULL,NULL,'Gita SCH',0),('9e12401a-67fd-4531-8502-7e2b46c1f85b',26,NULL,'Westlands',NULL,NULL,NULL,NULL,NULL,'Yaya centre',0),('a4fc6e2e-38a6-4c03-ae42-14e203bdf605',20,'Busia','Matayos','Central','Central',NULL,NULL,NULL,'BCRH',0),('a7823e72-1724-459e-9284-e1d392f1fdac',7,'Murang\'a','maragua',NULL,NULL,NULL,NULL,NULL,NULL,0),('b111dd35-aa01-4127-9297-2b5e5ab20398',9,'Nairobi','Westlands',NULL,'Kilimani',NULL,NULL,NULL,NULL,0),('b6c84234-6054-488b-8935-9d8e361a13fa',8,'Migori','Sirare',NULL,NULL,NULL,NULL,NULL,NULL,0),('be9d0396-b7da-4376-93cc-a213910234c3',25,NULL,'Vihiga south',NULL,NULL,NULL,NULL,NULL,'Vihiga',0),('cc1c9f44-f017-4c79-9ee7-072a00b7849a',14,'Nairobi','Embakasi','Mihango','Embakasi East',NULL,NULL,NULL,NULL,0),('d55d3686-2e47-48dd-80b8-3fcb560946bd',19,NULL,'Webuye',NULL,NULL,NULL,'Chebini','177-00100','Chebini Primary School',0),('d67e6e19-d38f-4891-90a5-fd55a0d1dbff',12,'Kisumu','Gita','Kolwa','Kibos',NULL,NULL,NULL,NULL,0),('e28cb179-74f1-45ea-90c8-9958653e3a89',16,'Nairobi','Embakasi','Mihango','Embakasi East',NULL,NULL,NULL,NULL,0),('f2114afd-ed61-438d-ba32-4d7a6fbdf716',27,NULL,'Kamukunji',NULL,NULL,NULL,NULL,NULL,'Inama Market',0),('fcdf9070-4d5f-4469-9081-75789812eae1',23,'Siaya','Ugunja','Uhuyi','Wangotong',NULL,NULL,NULL,NULL,0);

/*Table structure for table `pharmacy_extract` */

DROP TABLE IF EXISTS `pharmacy_extract`;

CREATE TABLE `pharmacy_extract` (
  `patient_id` int(11) NOT NULL,
  `uuid` char(38) DEFAULT NULL,
  `visit_date` date DEFAULT NULL,
  `visit_id` int(11) DEFAULT NULL,
  `encounter_id` int(11) DEFAULT NULL,
  `date_created` date DEFAULT NULL,
  `encounter_name` varchar(100) DEFAULT NULL,
  `drug` int(11) DEFAULT NULL,
  `drug_name` varchar(255) DEFAULT NULL,
  `is_arv` varchar(3) CHARACTER SET utf8 DEFAULT NULL,
  `is_ctx` varchar(37) CHARACTER SET utf8 DEFAULT NULL,
  `is_dapsone` varchar(7) CHARACTER SET utf8 DEFAULT NULL,
  `frequency` int(11) DEFAULT NULL,
  `duration` int(11) DEFAULT NULL,
  `duration_units` varchar(20) DEFAULT NULL,
  `voided` int(11) DEFAULT NULL,
  `date_voided` date DEFAULT NULL,
  `dispensing_provider` varchar(50) DEFAULT NULL,
  KEY `patient_id` (`patient_id`),
  CONSTRAINT `pharmacy_extract_ibfk_1` FOREIGN KEY (`patient_id`) REFERENCES `patient_demographics` (`patient_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `pharmacy_extract` */

/*Table structure for table `tb_enrollment` */

DROP TABLE IF EXISTS `tb_enrollment`;

CREATE TABLE `tb_enrollment` (
  `patient_id` int(11) NOT NULL,
  `uuid` char(38) DEFAULT NULL,
  `provider` int(11) DEFAULT NULL,
  `visit_id` int(11) DEFAULT NULL,
  `visit_date` date DEFAULT NULL,
  `location_id` int(11) DEFAULT NULL,
  `encounter_id` int(11) NOT NULL,
  `date_treatment_started` date DEFAULT NULL,
  `district` varchar(50) DEFAULT NULL,
  `referred_by` varchar(28) CHARACTER SET utf8 DEFAULT NULL,
  `referral_date` date DEFAULT NULL,
  `date_transferred_in` date DEFAULT NULL,
  `facility_transferred_from` varchar(100) DEFAULT NULL,
  `district_transferred_from` varchar(100) DEFAULT NULL,
  `date_first_enrolled_in_tb_care` date DEFAULT NULL,
  `weight` double DEFAULT NULL,
  `height` double DEFAULT NULL,
  `treatment_supporter` varchar(100) DEFAULT NULL,
  `relation_to_patient` varchar(17) CHARACTER SET utf8 DEFAULT NULL,
  `treatment_supporter_address` varchar(100) DEFAULT NULL,
  `treatment_supporter_phone_contact` varchar(100) DEFAULT NULL,
  `disease_classification` varchar(18) CHARACTER SET utf8 DEFAULT NULL,
  `patient_classification` varchar(34) CHARACTER SET utf8 DEFAULT NULL,
  `pulmonary_smear_result` varchar(14) CHARACTER SET utf8 DEFAULT NULL,
  `has_extra_pulmonary_pleurial_effusion` varchar(16) CHARACTER SET utf8 DEFAULT NULL,
  `has_extra_pulmonary_milliary` varchar(8) CHARACTER SET utf8 DEFAULT NULL,
  `has_extra_pulmonary_lymph_node` varchar(11) CHARACTER SET utf8 DEFAULT NULL,
  `has_extra_pulmonary_menengitis` varchar(10) CHARACTER SET utf8 DEFAULT NULL,
  `has_extra_pulmonary_skeleton` varchar(8) CHARACTER SET utf8 DEFAULT NULL,
  `has_extra_pulmonary_abdominal` varchar(9) CHARACTER SET utf8 DEFAULT NULL,
  KEY `patient_id` (`patient_id`),
  KEY `visit_date` (`visit_date`),
  CONSTRAINT `tb_enrollment_ibfk_1` FOREIGN KEY (`patient_id`) REFERENCES `patient_demographics` (`patient_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `tb_enrollment` */

/*Table structure for table `tb_follow_up_visit` */

DROP TABLE IF EXISTS `tb_follow_up_visit`;

CREATE TABLE `tb_follow_up_visit` (
  `patient_id` int(11) NOT NULL,
  `uuid` char(38) DEFAULT NULL,
  `provider` int(11) DEFAULT NULL,
  `visit_id` int(11) DEFAULT NULL,
  `visit_date` date DEFAULT NULL,
  `location_id` int(11) DEFAULT NULL,
  `encounter_id` int(11) NOT NULL,
  `spatum_test` varchar(23) CHARACTER SET utf8 DEFAULT NULL,
  `spatum_result` varchar(8) CHARACTER SET utf8 DEFAULT NULL,
  `result_serial_number` varchar(20) DEFAULT NULL,
  `quantity` double DEFAULT NULL,
  `date_test_done` date DEFAULT NULL,
  `bacterial_colonie_growth` varchar(9) CHARACTER SET utf8 DEFAULT NULL,
  `number_of_colonies` double DEFAULT NULL,
  `resistant_s` varchar(1) CHARACTER SET utf8 DEFAULT NULL,
  `resistant_r` varchar(1) CHARACTER SET utf8 DEFAULT NULL,
  `resistant_inh` varchar(3) CHARACTER SET utf8 DEFAULT NULL,
  `resistant_e` varchar(1) CHARACTER SET utf8 DEFAULT NULL,
  `sensitive_s` varchar(1) CHARACTER SET utf8 DEFAULT NULL,
  `sensitive_r` varchar(1) CHARACTER SET utf8 DEFAULT NULL,
  `sensitive_inh` varchar(3) CHARACTER SET utf8 DEFAULT NULL,
  `sensitive_e` varchar(1) CHARACTER SET utf8 DEFAULT NULL,
  `test_date` date DEFAULT NULL,
  `hiv_status` varchar(8) CHARACTER SET utf8 DEFAULT NULL,
  `next_appointment_date` date DEFAULT NULL,
  KEY `patient_id` (`patient_id`),
  KEY `visit_date` (`visit_date`),
  KEY `hiv_status` (`hiv_status`),
  CONSTRAINT `tb_follow_up_visit_ibfk_1` FOREIGN KEY (`patient_id`) REFERENCES `patient_demographics` (`patient_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `tb_follow_up_visit` */

/*Table structure for table `tb_screening` */

DROP TABLE IF EXISTS `tb_screening`;

CREATE TABLE `tb_screening` (
  `patient_id` int(11) NOT NULL,
  `uuid` char(38) DEFAULT NULL,
  `provider` int(11) DEFAULT NULL,
  `visit_id` int(11) DEFAULT NULL,
  `visit_date` date DEFAULT NULL,
  `encounter_id` int(11) NOT NULL,
  `location_id` int(11) DEFAULT NULL,
  `cough_for_2wks_or_more` varchar(3) CHARACTER SET utf8 DEFAULT NULL,
  `confirmed_tb_contact` varchar(3) CHARACTER SET utf8 DEFAULT NULL,
  `fever_for_2wks_or_more` varchar(3) CHARACTER SET utf8 DEFAULT NULL,
  `noticeable_weight_loss` varchar(3) CHARACTER SET utf8 DEFAULT NULL,
  `night_sweat_for_2wks_or_more` varchar(3) CHARACTER SET utf8 DEFAULT NULL,
  `resulting_tb_status` varchar(21) CHARACTER SET utf8 DEFAULT NULL,
  `tb_treatment_start_date` date DEFAULT NULL,
  `notes` varchar(100) DEFAULT NULL,
  KEY `patient_id` (`patient_id`),
  KEY `visit_date` (`visit_date`),
  CONSTRAINT `tb_screening_ibfk_1` FOREIGN KEY (`patient_id`) REFERENCES `patient_demographics` (`patient_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `tb_screening` */

/*Table structure for table `triage` */

DROP TABLE IF EXISTS `triage`;

CREATE TABLE `triage` (
  `uuid` char(38) DEFAULT NULL,
  `patient_id` int(11) NOT NULL,
  `visit_id` int(11) DEFAULT NULL,
  `visit_date` date DEFAULT NULL,
  `location_id` int(11) DEFAULT NULL,
  `encounter_id` int(11) NOT NULL,
  `encounter_provider` int(11) DEFAULT NULL,
  `date_created` date DEFAULT NULL,
  `visit_reason` varchar(255) DEFAULT NULL,
  `weight` double DEFAULT NULL,
  `height` double DEFAULT NULL,
  `systolic_pressure` double DEFAULT NULL,
  `diastolic_pressure` double DEFAULT NULL,
  `temperature` double DEFAULT NULL,
  `pulse_rate` double DEFAULT NULL,
  `respiratory_rate` double DEFAULT NULL,
  `oxygen_saturation` double DEFAULT NULL,
  `muac` double DEFAULT NULL,
  `nutritional_status` varchar(27) CHARACTER SET utf8 DEFAULT NULL,
  `last_menstrual_period` date DEFAULT NULL,
  `voided` int(11) DEFAULT NULL,
  KEY `patient_id` (`patient_id`),
  KEY `visit_date` (`visit_date`),
  CONSTRAINT `triage_ibfk_1` FOREIGN KEY (`patient_id`) REFERENCES `patient_demographics` (`patient_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `triage` */

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;
